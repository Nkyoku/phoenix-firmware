/**
 * @file app.c
 *
 * @brief @{PD application handler source file.@}
 *
 *******************************************************************************
 *
 * Copyright (2014-2019), Cypress Semiconductor Corporation or a subsidiary of
 * Cypress Semiconductor Corporation. All rights reserved.
 *
 * This software, including source code, documentation and related materials
 * (“Software”), is owned by Cypress Semiconductor Corporation or one of its
 * subsidiaries (“Cypress”) and is protected by and subject to worldwide patent
 * protection (United States and foreign), United States copyright laws and
 * international treaty provisions. Therefore, you may use this Software only
 * as provided in the license agreement accompanying the software package from
 * which you obtained this Software (“EULA”).
 *
 * If no EULA applies, Cypress hereby grants you a personal, nonexclusive,
 * non-transferable license to copy, modify, and compile the Software source
 * code solely for use in connection with Cypress’s integrated circuit
 * products. Any reproduction, modification, translation, compilation, or
 * representation of this Software except as specified above is prohibited
 * without the express written permission of Cypress. Disclaimer: THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress reserves the
 * right to make changes to the Software without notice. Cypress does not
 * assume any liability arising out of the application or use of the Software
 * or any product or circuit described in the Software. Cypress does not
 * authorize its products for use in any products where a malfunction or
 * failure of the Cypress product may reasonably be expected to result in
 * significant property damage, injury or death (“High Risk Product”). By
 * including Cypress’s product in a High Risk Product, the manufacturer of such
 * system or application assumes all risk of such use and in doing so agrees to
 * indemnify Cypress against all liability.
 */

#include <config.h>
#include <pd.h>
#include <dpm.h>
#include <psource.h>
#include <psink.h>
#include <pdo.h>
#include <swap.h>
#include <vdm.h>
#include <app.h>
#include <vdm_task_mngr.h>
#include <timer.h>
#if CCG_HPI_ENABLE
#include <hpi.h>
#endif /* CCG_HPI_ENABLE */
#include <alt_mode_hw.h>
#include <alt_modes_mngr.h>
#include <hal_ccgx.h>
#include <gpio.h>
#include <system.h>

#if RIDGE_SLAVE_ENABLE
#include <ridge_slave.h>
#include <intel_ridge.h>
#endif /* RIDGE_SLAVE_ENABLE */
#if DP_UFP_SUPP
#include <dp_sid.h>
#endif /* DP_UFP_SUPP */

#if DP_UFP_SUPP
#include <hpd.h>
#endif /* DP_UFP_SUPP */

#if BATTERY_CHARGING_ENABLE
#include <battery_charging.h>
#endif /* BATTERY_CHARGING_ENABLE */


#if CCG_UCSI_ENABLE
#include <ucsi.h>
#endif /* CCG_UCSI_ENABLE */


ovp_settings_t* pd_get_ptr_ovp_tbl(uint8_t port)
{
    /* Update the OVP settings from the configuration table. */
    return ((ovp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->ovp_tbl_offset));
}

ocp_settings_t* pd_get_ptr_ocp_tbl(uint8_t port)
{
    /* Update the VBus OCP settings from the configuration table */
    return ((ocp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->ocp_tbl_offset));
}

rcp_settings_t* pd_get_ptr_rcp_tbl(uint8_t port)
{
    /* Update the VBus RCP settings from the configuration table */
    return ((rcp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->rcp_tbl_offset));
}

uvp_settings_t* pd_get_ptr_uvp_tbl(uint8_t port)
{
    /* Update the VBus UVP settings from the configuration table */
    return ((uvp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->uvp_tbl_offset));
}

scp_settings_t* pd_get_ptr_scp_tbl(uint8_t port)
{
    /* Update the VBus SCP settings from the configuration table */
    return ((scp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->scp_tbl_offset));
}

vconn_ocp_settings_t* pd_get_ptr_vconn_ocp_tbl(uint8_t port)
{
    /* Update the Vcon OCP settings from the configuration table */
    return ((vconn_ocp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->vconn_ocp_tbl_offset));
}

otp_settings_t* pd_get_ptr_otp_tbl(uint8_t port)
{
    /* Update the OTP settings from the configuration table */
    return ((otp_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->otp_tbl_offset));
}

pwr_params_t* pd_get_ptr_pwr_tbl(uint8_t port)
{
    /* Update the power parameters from the configuration table */
    return ((pwr_params_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->pwr_tbl_offset));
}

chg_cfg_params_t* pd_get_ptr_chg_cfg_tbl(uint8_t port)
{

    /* Update the legacy charging parameters from the configuration table */
    return ((chg_cfg_params_t *)((uint8_t *)(get_pd_config ()) +
        get_pd_port_config(port)->chg_cfg_tbl_offset));
}

bat_chg_params_t* pd_get_ptr_bat_chg_tbl(uint8_t port)
{
    /* Update the battery charging parameterss from the configuration table */
    return ((bat_chg_params_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->bat_chg_tbl_offset));
}

pwr_params_t* pd_get_ptr_type_a_pwr_tbl(uint8_t port)
{
    /* Update the power parameters of Type-A port from the configuration table */
    return ((pwr_params_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->type_a_pwr_tbl_offset));
}

typeA_chg_cfg_params_t* pd_get_ptr_type_a_chg_cfg_tbl(uint8_t port)
{
    /* Update the legacy charging parameters from the configuration table */
    return ((typeA_chg_cfg_params_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->type_a_chg_tbl_offset));
}

bb_settings_t* pd_get_ptr_bb_tbl(uint8_t port)
{
    /* Update the Billboard settings from the configuration table*/
    return ((bb_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->bb_tbl_offset));
}

auto_cfg_settings_t* pd_get_ptr_auto_cfg_tbl(uint8_t port)
{
    /* Update the Automotive charger settings from the configuration table*/
    return ((auto_cfg_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->auto_cfg_tbl_offset));
}

tbthost_cfg_settings_t* pd_get_ptr_tbthost_cfg_tbl(uint8_t port)
{
    /* Retrieve the thunderbolt host config parameters. */
    return ((tbthost_cfg_settings_t *)((uint8_t *)(get_pd_config ()) +
                get_pd_port_config(port)->tbthost_cfg_tbl_offset));
}

app_status_t app_status[NO_OF_TYPEC_PORTS];

/* Flag to indicate that activity timer timed out. */
static volatile bool ccg_activity_timer_timeout = false;



bool app_validate_configtable_offsets()
{
    uint8_t  port;

    for(port = TYPEC_PORT_0_IDX ; port < NO_OF_TYPEC_PORTS; port++)
    {


        /* Initialize the fault-handler variables. */
        if (fault_handler_init_vars (port) == false)
        {
            return false;
        }

#if VCONN_OCP_ENABLE
        if (get_pd_port_config(port)->vconn_ocp_tbl_offset == 0)
        {
            return false;
        }

        /* No retries for VCONN OCP. */
#endif /* VCONN_OCP_ENABLE */

#if OTP_ENABLE
        if (get_pd_port_config(port)->otp_tbl_offset == 0)
        {
            return false;
        }

        /* No retries for OTP. */
#endif /* OTP_ENABLE */

#if BATTERY_CHARGING_ENABLE
        {
            if (get_pd_port_config(port)->chg_cfg_tbl_offset == 0)
            {
                return false;
            }
        }
#endif /* BATTERY_CHARGING_ENABLE */



    }

    return true;
}


#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
static bool app_is_vdm_task_ready(uint8_t port)
{
    /* Assume cable discovery finished when device is UFP. */
    bool retval = true;

#if DFP_ALT_MODE_SUPP

    const dpm_status_t *dpm_stat = dpm_get_info (port);

    /* This check only makes sense for DFP. */
    if (gl_dpm_port_type[port] != PRT_TYPE_UFP)
    {
#if (ROLE_PREFERENCE_ENABLE)
        /* Don't proceed with alternate mode if DR_SWAP is pending. */
        if ((app_status[port].app_pending_swaps & APP_DR_SWAP_PENDING) != 0)
        {
            return false;
        }
#endif /* (ROLE_PREFERENCE_ENABLE) */

        /*
         * Set the cable discovered flag if:
         * 1. Cable discovery is disabled.
         * 2. EMCA present flag in DPM is set.
         */
        if ((dpm_stat->cbl_dsc == false) || (dpm_stat->emca_present != false))
        {
            app_status[port].cbl_disc_id_finished = true;
        }

        /* Return the status of Cable discovered flag. */
        retval = app_status[port].cbl_disc_id_finished;
    }

#endif /* DFP_ALT_MODE_SUPP */

    return retval;
}
#endif /* ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP)) */

ccg_status_t app_disable_pd_port(uint8_t port, dpm_typec_cmd_cbk_t cbk)
{
    ccg_status_t retval = CCG_STAT_SUCCESS;

    if (timer_is_running (port, APP_FAULT_RECOVERY_TIMER))
    {
        /* If the HPI Master is asking us to disable the port, make sure all fault protection state is cleared. */
        app_status[port].fault_status &= ~(
                APP_PORT_VBUS_DROP_WAIT_ACTIVE | APP_PORT_SINK_FAULT_ACTIVE | APP_PORT_DISABLE_IN_PROGRESS |
                APP_PORT_VCONN_FAULT_ACTIVE | APP_PORT_V5V_SUPPLY_LOST);
        timer_stop(port, APP_FAULT_RECOVERY_TIMER);
        pd_typec_dis_rd(port, CC_CHANNEL_1);
        pd_typec_dis_rd(port, CC_CHANNEL_2);
        cbk(port, DPM_RESP_SUCCESS);
    }
    else
    {
        /* Just pass the call on-to the stack. */
        if (dpm_get_info(port)->dpm_enabled)
        {
            retval = dpm_typec_command(port, DPM_CMD_PORT_DISABLE, cbk);
        }
        else
        {
            cbk(port, DPM_RESP_SUCCESS);
        }
    }

    return retval;
}


uint8_t app_task(uint8_t port)
{
    fault_handler_task (port);


#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
    /* If VDM processing is allowed */
    if (app_status[port].vdm_task_en != false)
    {
        /* Wait for cable discovery completion before going on Alt. Modes. */
        if (app_is_vdm_task_ready (port))
        {
            vdm_task_mngr (port);
        }
    }
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */



#if BATTERY_CHARGING_ENABLE
    uint8_t i;
    for (i=0; i < NO_OF_BC_PORTS; i++)
    {
        bc_fsm (i);
    }
#endif /* BATTERY_CHARGING_ENABLE */

#if RIDGE_SLAVE_ENABLE
    ridge_slave_task();
#endif /* RIDGE_SLAVE_ENABLE */


    return true;
}

#define AMUX_CTRL_EA_TOP_REFGEN_SEL7_EN     (0x02u);

void app_type_c_enter_sleep(uint8_t port)
{
}

void app_type_c_wakeup()
{
}

bool app_type_c_sleep_allowed(void)
{
    bool out = true;
    uint8_t i = 0;


    if (out == true)
    {
        for (i = 0; i < NO_OF_TYPEC_PORTS; i++)
        {
            app_type_c_enter_sleep (i);
        }
    }

    return out;
}

bool app_sleep(void)
{
    bool stat = true;
    uint8_t port;

    for (port = 0; port < NO_OF_TYPEC_PORTS; port++)
    {


        /* Don't go to sleep while CC/SBU fault handling is pending. */
        if ((app_status[port].fault_status & APP_PORT_SINK_FAULT_ACTIVE) != 0)
        {
            stat = false;
            break;
        }

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
        if (!is_vdm_task_idle(port))
        {
            stat = false;
            break;
        }
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */

#if (DP_UFP_SUPP) && (CCG_HPD_RX_ENABLE)
        /* CDT 245126 workaround: Check if HPD RX Activity timer is running.
         * If yes, don't enter deep sleep. */
        if (!is_hpd_rx_state_idle (port))
        {
            stat = false;
            break;
        }
#endif /* DP_UFP_SUPP && CCG_HPD_RX_ENABLE */
    }

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
    if (stat)
    {
        for (port = 0; port < NO_OF_TYPEC_PORTS; port++)
        {
            /* Prepare for deep-sleep entry. */
            alt_mode_mngr_sleep(port);
        }
    }
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */

    return stat;
}

void app_wakeup(void)
{
#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
    uint8_t port;

    for (port = 0; port < NO_OF_TYPEC_PORTS; port++)
    {
        alt_mode_mngr_wakeup (port);
    }
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */
}


#if CCG_PD_REV3_ENABLE

void extd_msg_cb(uint8_t port, resp_status_t resp, const pd_packet_t* pkt_ptr)
{
    static pd_ams_type ams_type[NO_OF_TYPEC_PORTS];
    (void)pkt_ptr;
    if(resp == RES_RCVD){
        dpm_set_chunk_transfer_running(port, ams_type[port]);
    }
    if(resp == CMD_SENT){
        ams_type[port] = dpm_get_info(port)->non_intr_response;
    }
}

/* Global variable used as dummy data buffer to send Chunk Request messages. */
static uint32_t gl_extd_dummy_data;

static bool app_extd_msg_handler(uint8_t port, pd_packet_extd_t *pd_pkt_p)
{
    /* If this is a chunked message which is not complete, send another chunk request. */
    if ((pd_pkt_p->hdr.hdr.chunked == true) && (pd_pkt_p->hdr.hdr.data_size >
               ((pd_pkt_p->hdr.hdr.chunk_no + 1) * MAX_EXTD_MSG_LEGACY_LEN)))
    {
        dpm_pd_cmd_buf_t extd_dpm_buf;

        extd_dpm_buf.cmd_sop = pd_pkt_p->sop;
        extd_dpm_buf.extd_type = pd_pkt_p->msg;
        extd_dpm_buf.extd_hdr.val = 0;
        extd_dpm_buf.extd_hdr.extd.chunked = true;
        extd_dpm_buf.extd_hdr.extd.request = true;
        extd_dpm_buf.extd_hdr.extd.chunk_no = pd_pkt_p->hdr.hdr.chunk_no + 1;
        extd_dpm_buf.dat_ptr = (uint8_t*)&gl_extd_dummy_data;
        extd_dpm_buf.timeout = PD_SENDER_RESPONSE_TIMER_PERIOD;

        /* Send next chunk request */
        dpm_pd_command_ec(port, DPM_CMD_SEND_EXTENDED,
                &extd_dpm_buf, extd_msg_cb);
    }
    else
    {
#if CCG_SLN_EXTN_MSG_HANDLER_ENABLE
        /* If macro is enabled - allow handling the requests from solution space. */
        return false;
#else
        /*
         * Don't send any response to response messages. Handling here instead of in the stack so that
         * these messages can be used for PD authentication implementation.
         */
        if ((pd_pkt_p->msg != EXTD_MSG_SECURITY_RESP) && (pd_pkt_p->msg != EXTD_MSG_FW_UPDATE_RESP))
        {
            /* Send Not supported message */
            dpm_pd_command_ec(port, DPM_CMD_SEND_NOT_SUPPORTED, NULL, NULL);
        }
#endif /* CCG_HANDLE_EXT_MSG_IN_SOL */
    }

    return true;
}
#endif /* CCG_PD_REV3_ENABLE */

void app_update_bc_src_support(uint8_t port, uint8_t enable)
{
#if BATTERY_CHARGING_ENABLE
    app_status[port].bc_12_src_disabled = (bool)(!enable);
    if (!enable)
    {
        bc_stop(port);
    }
#endif /* BATTERY_CHARGING_ENABLE && (defined(CCG5C) || defined(CCG5) || defined(CCG6)) */
}

void app_update_sys_pwr_state(uint8_t state)
{
#if BATTERY_CHARGING_ENABLE
    uint8_t i = 0;

    /*
     * If the port is currently functioning as DCP and system is going into S0 state; go through Type-C error
     * recovery. If the port is currently functioning as CDP, we do not change current state of the port.
     * Port will function as DCP on next Type-C connection.
     */
    if (
            (state == 0) && (state != hpi_get_sys_pwr_state()) &&
            (app_status[i].bc_12_src_disabled == 0)
       )
    {
#if CCG_PD_DUALPORT_ENABLE
        for (i = 0; i < NO_OF_TYPEC_PORTS; i++)
#endif /* CCG_PD_DUALPORT_ENABLE */
        {
            if (
                    (dpm_get_info(i)->attach) &&
                    (dpm_get_info(i)->cur_port_role == PRT_ROLE_SOURCE) &&
                    ((alt_mode_get_status(i) & 0x7F) == 0)
               )
            {
                dpm_typec_command (i, DPM_CMD_TYPEC_ERR_RECOVERY, NULL);
            }
        }
    }
#endif /* BATTERY_CHARGING_ENABLE && (defined(CCG5C) || defined(CCG5) || defined(CCG6)) */
}

#if BATTERY_CHARGING_ENABLE

/* Function to start the CCG5 BC 1.2 source state machine. */
void app_bc_12_sm_start(uint8_t port)
{
    /* Enable CDP is system power state is S0, otherwise enable DCP. */
#if CCG_HPI_ENABLE
    if (hpi_get_sys_pwr_state () == 0)
#endif /* CCG_HPI_ENABLE */
    {
        ccg_bc_cdp_en(port);
    }
#if CCG_HPI_ENABLE
    else
    {
        ccg_bc_dcp_en(port);
    }
#endif /* CCG_HPI_ENABLE */
}

#endif /* (BATTERY_CHARGING_ENABLE && (defined(CCG5))) */

uint32_t get_bat_status[NO_OF_TYPEC_PORTS];

#if (ROLE_PREFERENCE_ENABLE)

/* Variable storing current preference for data role. */
volatile uint8_t app_pref_data_role[NO_OF_TYPEC_PORTS];

/* Variable storing current preference for power role. */
volatile uint8_t app_pref_power_role[NO_OF_TYPEC_PORTS];

/* Forward declaration of function to trigger swap operations. */
static void app_initiate_swap (uint8_t port, timer_id_t id);

static void app_role_swap_resp_cb (
        uint8_t            port,
        resp_status_t      resp,
        const pd_packet_t *pkt_ptr)
{
    app_status_t *app_stat = &app_status[port];
    bool next_swap = false;

    if (resp == RES_RCVD)
    {
        if (pkt_ptr->hdr.hdr.msg_type == CTRL_MSG_WAIT)
        {
            app_stat->actv_swap_count++;
            if (app_stat->actv_swap_count < APP_MAX_SWAP_ATTEMPT_COUNT)
            {
                timer_start (port, APP_INITIATE_SWAP_TIMER, app_stat->actv_swap_delay, app_initiate_swap);
            }
            else
            {
                /* Swap attempts timed out. Proceed with next swap. */
                next_swap = true;
            }
        }
        else
        {
            /* Swap succeeded or failed. Proceed with next swap. */
            next_swap = true;
        }
    }
    else if ((resp == CMD_FAILED) || (resp == SEQ_ABORTED) || (resp == RES_TIMEOUT))
    {
        timer_start (port, APP_INITIATE_SWAP_TIMER, app_stat->actv_swap_delay, app_initiate_swap);
    }

    if (next_swap)
    {
        /* Clear the LS bit in the app_pending_swaps flag as it has completed or failed. */
        app_stat->app_pending_swaps &= (app_stat->app_pending_swaps - 1);

        app_stat->actv_swap_type  = 0;
        app_stat->actv_swap_count = 0;
        timer_start (port, APP_INITIATE_SWAP_TIMER, APP_INITIATE_DR_SWAP_TIMER_PERIOD, app_initiate_swap);
    }
}

static void app_initiate_swap (uint8_t port, timer_id_t id)
{
    const dpm_status_t *dpm_stat = dpm_get_info(port);
    dpm_pd_cmd_buf_t pd_cmd_buf;
    uint8_t swaps_pending = app_status[port].app_pending_swaps;
    uint8_t actv_swap = app_status->actv_swap_type;

    /* Stop the timer that triggers swap operation. */
    timer_stop (port, APP_INITIATE_SWAP_TIMER);

    /* Nothing to do if we are not in PD contract. */
    if (!dpm_stat->contract_exist)
        return;

    if (actv_swap == 0)
    {
        /* No ongoing swap operation. Pick the next pending swap from the list. */
        if ((swaps_pending & APP_VCONN_SWAP_PENDING) != 0)
        {
            actv_swap = DPM_CMD_SEND_VCONN_SWAP;
            app_status[port].actv_swap_delay = APP_INITIATE_DR_SWAP_TIMER_PERIOD;
        }
        else
        {
            if ((swaps_pending & APP_DR_SWAP_PENDING) != 0)
            {
                actv_swap = DPM_CMD_SEND_DR_SWAP;
                app_status[port].actv_swap_delay = APP_INITIATE_DR_SWAP_TIMER_PERIOD;
            }
            else
            {
                if (swaps_pending != 0)
                {
                    actv_swap = DPM_CMD_SEND_PR_SWAP;
                    app_status[port].actv_swap_delay = APP_INITIATE_PR_SWAP_TIMER_PERIOD;
                }
            }
        }

        app_status[port].actv_swap_count = 0;
    }

    if (actv_swap != 0)
    {
        /* Check whether the selected swap is still valid. */
        switch (actv_swap)
        {
            case DPM_CMD_SEND_VCONN_SWAP:
                if (dpm_stat->vconn_logical)
                {
                    app_status[port].app_pending_swaps &= ~APP_VCONN_SWAP_PENDING;
                    actv_swap = 0;
                }
                break;

            case DPM_CMD_SEND_DR_SWAP:
                if (dpm_stat->cur_port_type == app_pref_data_role[port])
                {
                    app_status[port].app_pending_swaps &= ~APP_DR_SWAP_PENDING;
                    actv_swap = 0;
                }
                break;

            case DPM_CMD_SEND_PR_SWAP:
                if (dpm_stat->cur_port_role == app_pref_power_role[port])
                {
                    app_status[port].app_pending_swaps &= ~APP_PR_SWAP_PENDING;
                    actv_swap = 0;
                }
                break;

            default:
                actv_swap = 0;
                break;
        }

        if (actv_swap == 0)
        {
            /*
             * Currently selected SWAP is no longer relevant. Re-run function to identify the next swap to be
             * performed.
             */
            if (app_status[port].app_pending_swaps != 0)
            {
                app_status[port].actv_swap_type = 0;
                timer_start (port, APP_INITIATE_SWAP_TIMER, APP_INITIATE_DR_SWAP_TIMER_PERIOD, app_initiate_swap);
            }
        }
        else
        {
            /* Store the swap command for use in the callback. */
            app_status[port].actv_swap_type = actv_swap;

            /* Only packet type needs to be set when initiating swap operations. */
            pd_cmd_buf.cmd_sop = SOP;

            /* Try to trigger the selected swap operation. */
            if (dpm_pd_command(port, actv_swap, &pd_cmd_buf, app_role_swap_resp_cb) != CCG_STAT_SUCCESS)
            {
                /* Retries in case of AMS failure can always be done with a small delay. */
                timer_start (port, APP_INITIATE_SWAP_TIMER, APP_INITIATE_DR_SWAP_TIMER_PERIOD, app_initiate_swap);
            }
        }
    }
}

/* This function is called at the end of a PD contract to check whether any role swaps need to be triggered. */
static void app_contract_handler (uint8_t port)
{
    app_status_t *app_stat = &app_status[port];
    const dpm_status_t *dpm_stat = dpm_get_info(port);
    uint16_t delay_reqd = APP_INITIATE_PR_SWAP_TIMER_PERIOD;

    /* Check if we need to go ahead with PR-SWAP. */
    if (
            (app_pref_power_role[port] == PRT_DUAL) ||
            (dpm_get_info(port)->cur_port_role == app_pref_power_role[port])
       )
    {
        app_stat->app_pending_swaps &= ~APP_PR_SWAP_PENDING;
    }
    else
    {
        /* If we are about to swap to become source, ensure VConn Swap is done as required. */
        if ((app_pref_power_role[port] == PRT_ROLE_SOURCE) && (dpm_stat->vconn_logical == 0))
        {
            app_stat->app_pending_swaps |= APP_VCONN_SWAP_PENDING;

#if (DEFER_VCONN_SRC_ROLE_SWAP)
            /* Keep the VConn SWAP role until we have finished the required tasks. */
            app_stat->keep_vconn_src = true;
#endif /* (DEFER_VCONN_SRC_ROLE_SWAP) */
        }
    }

    /* Check if we need to go ahead with DR-SWAP. */
    if (
            (app_pref_data_role[port] == PRT_TYPE_DRP) ||
            (dpm_get_info(port)->cur_port_type == app_pref_data_role[port])
       )
    {
        app_stat->app_pending_swaps &= ~APP_DR_SWAP_PENDING;
    }
    else
    {
        /* DR-SWAPs need to be initiated as soon as possible. VConn swap will be triggered after DR_SWAP as needed. */
        delay_reqd = APP_INITIATE_DR_SWAP_TIMER_PERIOD;
    }

    /* Start a timer that will kick of the Swap state machine. */
    timer_start (port, APP_INITIATE_SWAP_TIMER, delay_reqd, app_initiate_swap);
}

static void app_connect_change_handler (uint8_t port)
{
    /* Stop all timers used to trigger swap operations. */
    timer_stop (port, APP_INITIATE_SWAP_TIMER);

    /*
     * Assume that PR_SWAP and DR_SWAP are pending. The actual status
     * will be updated on contract completion.
     */
    app_status[port].app_pending_swaps = APP_PR_SWAP_PENDING | APP_DR_SWAP_PENDING;
    app_status[port].actv_swap_type    = 0;
    app_status[port].actv_swap_count   = 0;
}

#endif /* (ROLE_PREFERENCE_ENABLE) */

static uint8_t gl_app_previous_polarity[NO_OF_TYPEC_PORTS];

void app_event_handler(uint8_t port, app_evt_t evt, const void* dat)
{
    const app_req_status_t* result;
    const pd_contract_info_t* contract_status;
    bool  skip_soln_cb = false;
    bool  hardreset_cplt = false;
    bool  typec_only = false;
    const dpm_status_t *dpm_stat = dpm_get_info(port);
#if CCG_PD_REV3_ENABLE
    pd_do_t alert_ado;
#endif /* CCG_PD_REV3_ENABLE */

    switch(evt)
    {
        case APP_EVT_TYPEC_STARTED:

            /* Initialize the MUX to its default settings (isolate). */
            mux_ctrl_init (port);
            app_status[port].vdm_prcs_failed = false;
            break;

        case APP_EVT_TYPEC_ATTACH:
            /* This will also enable the USB (DP/DM) MUX where required. */
            set_mux (port, MUX_CONFIG_SS_ONLY, 0);

            /* Clear all fault counters if we have seen a change in polarity from previous connection. */
            if (dpm_stat->polarity != gl_app_previous_polarity[port])
            {
                fault_handler_clear_counts (port);
            }
            gl_app_previous_polarity[port] = dpm_stat->polarity;
            break;

        case APP_EVT_CONNECT:
            app_status[port].vdm_prcs_failed = false;
            app_status[port].cbl_disc_id_finished = false;


#if (ROLE_PREFERENCE_ENABLE)
            app_connect_change_handler (port);
#endif /* (ROLE_PREFERENCE_ENABLE) */
            break;

        case APP_EVT_HARD_RESET_COMPLETE:
            app_status[port].cbl_disc_id_finished = false;
            hardreset_cplt = true;
            /* Intentional fall-through. */

        case APP_EVT_HARD_RESET_SENT:
        case APP_EVT_PE_DISABLED:
            typec_only = ((dpm_stat->pd_connected == false) || (evt == APP_EVT_PE_DISABLED));
            /* Intentional fall-through. */

        case APP_EVT_HARD_RESET_RCVD:
        case APP_EVT_VBUS_PORT_DISABLE:
        case APP_EVT_DISCONNECT:
        case APP_EVT_TYPE_C_ERROR_RECOVERY:

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
            vdm_task_mngr_deinit (port);

            timer_stop (port, APP_CBL_DISC_TRIGGER_TIMER);

#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */

            /*
             * Re-enable MUX in USB mode if hard reset has been completed.
             */
            if (hardreset_cplt)
            {
                set_mux (port, MUX_CONFIG_SS_ONLY, 0);
            }
            else
            {
                /*
                 * Isolate the data lines if this is a PD connection.
                 */
                if (!typec_only)
                {
                    set_mux (port, MUX_CONFIG_ISOLATE, 0);
                    timer_stop (port, APP_AME_TIMEOUT_TIMER);
                }
            }

            if ((evt == APP_EVT_DISCONNECT) || (evt == APP_EVT_VBUS_PORT_DISABLE))
            {

                /* Cleanup the PD block states on disconnect. */
                pd_hal_cleanup(port);

        #if VCONN_OCP_ENABLE
                /* Clear the VConn fault status. */
                app_status[port].fault_status &= ~APP_PORT_VCONN_FAULT_ACTIVE;
        #endif /* VCONN_OCP_ENABLE */

            }

#if (ROLE_PREFERENCE_ENABLE)
            if (
                    (evt == APP_EVT_HARD_RESET_COMPLETE) ||
                    (evt == APP_EVT_TYPE_C_ERROR_RECOVERY) ||
                    (evt == APP_EVT_DISCONNECT)
               )
            {
                /* Stop the DR-Swap and PR-Swap trigger timers.  Assume that
                 * PR_SWAP and DR_SWAP are pending. The actual status will be
                 * updated on contract completion.
                 */
                app_connect_change_handler (port);
            }
#endif /* (ROLE_PREFERENCE_ENABLE) */

            break;

        case APP_EVT_EMCA_DETECTED:
        case APP_EVT_EMCA_NOT_DETECTED:
            app_status[port].cbl_disc_id_finished = true;
            app_status[port].vdm_prcs_failed = false;

#if DFP_ALT_MODE_SUPP
            /* If alt. mode state machine is inactive or idle, we can allow VConn swaps to proceed. */
            if (is_vdm_task_idle(port))
            {
#if (DEFER_VCONN_SRC_ROLE_SWAP)
                app_status[port].keep_vconn_src = false;
#endif /* (DEFER_VCONN_SRC_ROLE_SWAP) */
            }
#endif /* DFP_ALT_MODE_SUPP */

            /*
               Update the MUX settings with new cable information once EMCA detection is completed, only
               if we are still in USB mode.
             */
            if (get_mux_state(port) == MUX_CONFIG_SS_ONLY)
            {
                set_mux (port, MUX_CONFIG_SS_ONLY, 0);
            }
            break;

        case APP_EVT_DR_SWAP_COMPLETE:
            result = (const app_req_status_t*)dat ;
            if(*result == REQ_ACCEPT)
            {
#if (ROLE_PREFERENCE_ENABLE)
                app_status[port].app_pending_swaps &= ~APP_DR_SWAP_PENDING;
                if (app_status[port].actv_swap_type == DPM_CMD_SEND_DR_SWAP)
                {
                    timer_stop (port, APP_INITIATE_SWAP_TIMER);
                    app_contract_handler (port);
                }
#endif /* (ROLE_PREFERENCE_ENABLE) */

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
                /* Device data role changed. Reset alternate mode layer. */
                alt_mode_layer_reset(port);
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */

            }
            break;

        case APP_EVT_VENDOR_RESPONSE_TIMEOUT:
            /* If the APP layer is going to retry the VDM, do not send the event. */
            if (app_status[port].vdm_retry_pending)
                skip_soln_cb = true;
            break;

        case APP_EVT_PD_CONTRACT_NEGOTIATION_COMPLETE:
            contract_status = (pd_contract_info_t*)dat;

            /* Set VDM version based on active PD revision. */
#if CCG_PD_REV3_ENABLE
            if (dpm_stat->spec_rev_sop_live >= PD_REV3)
            {
                app_status[port].vdm_version = STD_VDM_VERSION_REV3;
            }
            else
#endif /* CCG_PD_REV3_ENABLE */
            {
                app_status[port].vdm_version = STD_VDM_VERSION_REV2;
            }

            if ((contract_status->status == PD_CONTRACT_NEGOTIATION_SUCCESSFUL) ||
                    (contract_status->status == PD_CONTRACT_CAP_MISMATCH_DETECTED))
            {
#if (ROLE_PREFERENCE_ENABLE)
                app_contract_handler (port);
#endif /* (ROLE_PREFERENCE_ENABLE) */

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
                /*
                 * Contract established.  Enable VDM task manager for Alt. Mode support.
                 * This function will have no effect if the Alt. Modes are already running.
                 */
                if (
                        (gl_dpm_port_type[port] == PRT_TYPE_UFP) ||
                        (app_status[port].vdm_prcs_failed == false)
                   )
                {
                    enable_vdm_task_mngr(port);
                }
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */
            }



            /* If we are not DFP, we can now allow the port partner to become VConn Source. */
            if (
                    (gl_dpm_port_type[port] == PRT_TYPE_UFP)
#if ROLE_PREFERENCE_ENABLE
                    &&
                    (app_pref_data_role[port] != PRT_TYPE_DFP)
#endif /* ROLE_PREFERENCE_ENABLE */
               )
            {
#if (DEFER_VCONN_SRC_ROLE_SWAP)
                app_status[port].keep_vconn_src = false;
#endif /* (DEFER_VCONN_SRC_ROLE_SWAP) */
            }
            break;

        case APP_EVT_VCONN_OCP_FAULT:
#if VCONN_OCP_ENABLE
            /* Store the VConn fault status. */
            app_status[port].fault_status |= APP_PORT_VCONN_FAULT_ACTIVE;

#if (DFP_ALT_MODE_SUPP)
            /* Exit any active alternate modes. */
            if (gl_dpm_port_type[port] == PRT_TYPE_DFP)
            {
                vdm_task_mngr_deinit(port);
            }
#endif /* (DFP_ALT_MODE_SUPP) */
#endif /* VCONN_OCP_ENABLE */
            break;

#if CCG_PD_REV3_ENABLE
        case APP_EVT_HANDLE_EXTENDED_MSG:
#if (CCG_HPI_PD_ENABLE)
            /* Handle the extended message locally if forwarding to EC is not enabled. */
            if (hpi_is_extd_msg_ec_ctrl_enabled (port) == false)
#endif
            {
                if(!(app_extd_msg_handler(port, (pd_packet_extd_t *)dat)))
                {
                    skip_soln_cb  = false;
                }
                else
                {
                    skip_soln_cb  = true;
                }
            }
            break;

        case APP_EVT_ALERT_RECEIVED:
            /* Respond to ALERT message only if there is the number of object is one. */
            if (((pd_packet_t*)dat)->len == 1)
            {
                alert_ado = ((pd_packet_t*)dat)->dat[0];
                if(alert_ado.ado_alert.bat_status_change == false)
                {
                    dpm_pd_command(port, DPM_CMD_GET_STATUS, NULL, NULL);
                }
                else
                {
                    uint8_t i = alert_ado.ado_alert.fixed_bats |
                        (alert_ado.ado_alert.hot_swap_bats << 4);
                    dpm_pd_cmd_buf_t cmd;

                    /* Identify the first battery for which the change is intended. */
                    get_bat_status[port] = 0;
                    while ((i != 0) && ((i & 0x01) == 0))
                    {
                        get_bat_status[port]++;
                        i >>= 1;
                    }

                    cmd.cmd_sop = SOP;
                    cmd.extd_hdr.val = 0x1;
                    cmd.timeout = PD_SENDER_RESPONSE_TIMER_PERIOD;
                    cmd.extd_type = EXTD_MSG_GET_BAT_STATUS;
                    cmd.dat_ptr = (uint8_t*)&get_bat_status[port];
                    dpm_pd_command(port, DPM_CMD_SEND_EXTENDED, &cmd, NULL);
                }
            }
            break;
#endif /* CCG_PD_REV3_ENABLE */


#if (ROLE_PREFERENCE_ENABLE)
        case APP_EVT_PR_SWAP_COMPLETE:
            app_status[port].app_pending_swaps &= ~APP_PR_SWAP_PENDING;
            if (app_status[port].actv_swap_type == DPM_CMD_SEND_PR_SWAP)
            {
                timer_stop (port, APP_INITIATE_SWAP_TIMER);
                app_contract_handler (port);
            }
            break;
#endif /* (ROLE_PREFERENCE_ENABLE) */

        case APP_EVT_ALT_MODE:
#if DFP_ALT_MODE_SUPP
            /* We can clear the keep VConn source flag once the alternate mode state machine has become idle. */
            if (is_vdm_task_idle (port))
            {
#if (DEFER_VCONN_SRC_ROLE_SWAP)
                app_status[port].keep_vconn_src = false;
#endif /* (DEFER_VCONN_SRC_ROLE_SWAP) */
            }
#endif /* DFP_ALT_MODE_SUPP */

#if (ROLE_PREFERENCE_ENABLE)
            /* Stop trying to initiate DR_SWAP once any alt. mode has been entered. */
            if (app_status[port].alt_mode_entered)
            {
                app_status[port].app_pending_swaps &= ~APP_DR_SWAP_PENDING;
                if (app_status[port].actv_swap_type == DPM_CMD_SEND_DR_SWAP)
                {
                    timer_stop (port, APP_INITIATE_SWAP_TIMER);
                    app_contract_handler (port);
                }
            }
#endif /* (ROLE_PREFERENCE_ENABLE) */
            break;

#if 0
        /* Default handlers are sufficient for these cases. */
        case APP_EVT_UNEXPECTED_VOLTAGE_ON_VBUS:
        case APP_EVT_RP_CHANGE:
        case APP_EVT_PKT_RCVD:
        case APP_EVT_VCONN_SWAP_COMPLETE:
        case APP_EVT_SENDER_RESPONSE_TIMEOUT:
        case APP_EVT_SOFT_RESET_SENT:
        case APP_EVT_CBL_RESET_SENT:
#endif

        default:
            /* Nothing to do. */
            break;
    }

    /* Pass the event notification to the fault handler module. */
    if (fault_event_handler (port, evt, dat))
    {
        skip_soln_cb = true;
    }

#if BATTERY_CHARGING_ENABLE
    bc_pd_event_handler (port, evt);
#endif /* BATTERY_CHARGING_ENABLE */


    if (!skip_soln_cb)
    {
        /* Send notifications to the solution */
        sln_pd_event_handler(port, evt, dat);
    }
}

app_resp_t* app_get_resp_buf(uint8_t port)
{
    return &app_status[port].app_resp;
}

app_status_t* app_get_status(uint8_t port)
{
    return &app_status[port];
}

bool app_is_port_enabled(uint8_t port)
{
    bool ret = true;

    if (port > NO_OF_TYPEC_PORTS)
        ret = false;

#if CCG_HPI_ENABLE
    /* Check if the port has been disabled through HPI. */
    if ((hpi_get_port_enable() & (1 << port)) == 0)
        ret = false;
#endif /* CCG_HPI_ENABLE */

    return ret;
}

#if CCGX_V5V_CHANGE_DETECT

static void app_cbl_dsc_timer_cb (uint8_t port, timer_id_t id);

static void app_cbl_dsc_callback (uint8_t port, resp_status_t resp, const pd_packet_t *pkt_ptr)
{
    /* Keep repeating the DPM command until we succeed. */
    if (resp == SEQ_ABORTED)
    {
        timer_start (port, APP_CBL_DISC_TRIGGER_TIMER, APP_CBL_DISC_TIMER_PERIOD, app_cbl_dsc_timer_cb);
    }
}

static void app_cbl_dsc_timer_cb (uint8_t port, timer_id_t id)
{
    if (dpm_pd_command (port, DPM_CMD_INITIATE_CBL_DISCOVERY, NULL, app_cbl_dsc_callback) != CCG_STAT_SUCCESS)
    {
        timer_start (port, APP_CBL_DISC_TRIGGER_TIMER, APP_CBL_DISC_TIMER_PERIOD, app_cbl_dsc_timer_cb);
    }
}

#if DP_UFP_SUPP
static void app_ufp_5v_recov_cb(uint8_t port, timer_id_t id)
{
    (void)id;

    /* Create app alt mode command to initiate DP related Vconn Swap procedure */
    uint8_t dp_cmd[4]  = {0xA, 0x00, 0x01, 0xFF};
    uint8_t dp_data[4] = {0x00, 0x00, 0x00, DP_APP_VCONN_SWAP_CFG_CMD};

    if (eval_app_alt_mode_cmd(port, dp_cmd, dp_data) == false)
    {
        /* Init Hard reset if DP alt mode not entered */
        dpm_pd_command (port, DPM_CMD_SEND_HARD_RESET, NULL, NULL);
    }
}
#endif /* #if DP_UFP_SUPP */
#endif /* CCGX_V5V_CHANGE_DETECT */

/* Callback that will be called when there is any change to the V5V or VSYS supplies. */
void app_ccg5_supply_change_cb(uint8_t port, ccg_supply_t supply_id, bool present)
{
#if CCGX_V5V_CHANGE_DETECT
    const dpm_status_t *dpm_stat = dpm_get_info(port);

    /*
     * Currently we only handle V5V changes:
     * If V5V is removed, we exit active alternate modes if there is a cable which requires VConn.
     * If V5V is re-applied after being removed, we restart the alternate mode state machine.
     */
    if (supply_id == CCG_SUPPLY_V5V)
    {
        if (!present)
        {
            app_status[port].fault_status |= APP_PORT_V5V_SUPPLY_LOST;

            if (vconn_is_present (port))
            {
                /* Ensure that the VConn switch is turned off. */
                vconn_disable (port, dpm_stat->rev_pol);

#if (DFP_ALT_MODE_SUPP)
                /* If we are the DFP, the cable requires VConn and Alt. Modes are Active, exit alt. modes. */
                if (
                        (gl_dpm_port_type[port] == PRT_TYPE_DFP) &&
                        (dpm_stat->cbl_vdo.std_cbl_vdo.cbl_term != CBL_TERM_BOTH_PAS_VCONN_NOT_REQ) &&
                        (app_status[port].alt_mode_entered != 0)
                   )
                {
                    vdm_task_mngr_deinit(port);
                }
#endif /* (DFP_ALT_MODE_SUPP) */
            }
        }
        else
        {
            if ((app_status[port].fault_status & APP_PORT_V5V_SUPPLY_LOST) != 0)
            {
                app_status[port].fault_status &= ~APP_PORT_V5V_SUPPLY_LOST;

#if (DFP_ALT_MODE_SUPP)
                /*
                 * Alt. Mode operation was previously suspended due to V5V not being present.
                 * We can restart the alt. mode state machine so that mode discovery and operation
                 * can take place.
                 */
                if ((dpm_stat->contract_exist) && (gl_dpm_port_type[port] == PRT_TYPE_DFP))
                {
                    /* Ask PD stack to trigger cable discovery. */
                    if (dpm_pd_command(port, DPM_CMD_INITIATE_CBL_DISCOVERY,
                                NULL, app_cbl_dsc_callback) != CCG_STAT_SUCCESS)
                    {
                        timer_start(port, APP_CBL_DISC_TRIGGER_TIMER, APP_CBL_DISC_TIMER_PERIOD, app_cbl_dsc_timer_cb);
                    }

                    /*
                     * Reset the alternate mode state machine. The cable discovery complete flag is also cleared so
                     * that alternate mode state machine can be started at the end of cable discovery.
                     */
                    alt_mode_layer_reset(port);
                    app_status[port].cbl_disc_id_finished = false;
                }
#endif /* (DFP_ALT_MODE_SUPP) */
#if DP_UFP_SUPP
                if ((dpm_stat->contract_exist) && (gl_dpm_port_type[port] == PRT_TYPE_UFP))
                {
                    timer_start(port, APP_UFP_RECOV_VCONN_SWAP_TIMER, APP_UFP_RECOV_VCONN_SWAP_TIMER_PERIOD, app_ufp_5v_recov_cb);
                }
#endif /* DP_UFP_SUPP */
            }
        }
    }
#endif /* CCGX_V5V_CHANGE_DETECT */
}

/* Callback used to receive fault notification from the HAL and to pass it on to the event handler. */
static void app_cc_sbu_fault_handler(uint8_t port, bool fault_type)
{
    app_event_handler(port, (fault_type ? APP_EVT_SBU_OVP : APP_EVT_CC_OVP), 0);
}


void app_init(void)
{
    uint8_t port;

    /* For now, only the VDM handlers require an init call. */
    for (port = 0; port < NO_OF_TYPEC_PORTS; port++)
    {
        /* Initialize the VDM responses from the configuration table. */
        vdm_data_init(port);

        /* Set alt mode trigger based on config */
        app_get_status(port)->alt_mode_trig_mask = get_pd_port_config(port)->alt_mode_trigger;



#if BATTERY_CHARGING_ENABLE
        bc_init(port);
#endif /* BATTERY_CHARGING_ENABLE */

#if (ROLE_PREFERENCE_ENABLE)
        if (get_pd_port_config(port)->tbthost_cfg_tbl_offset != 0)
        {
            app_pref_power_role[port] = (pd_get_ptr_tbthost_cfg_tbl(port)->pref_pwr_role);
            app_pref_data_role[port] = (pd_get_ptr_tbthost_cfg_tbl(port)->pref_data_role);
        }
        else
        {
            /* Initialize with no preference by default. */
            app_pref_power_role[port] = PRT_DUAL;
            app_pref_data_role[port] = PRT_TYPE_DRP;
        }
#endif /* (ROLE_PREFERENCE_ENABLE) */
    }



#if (CCG_CC_SBU_OVP_RETRY_LIMIT != 0)
    /* Set the retry limit where it is non-zero. */
    gl_app_fault_retry_limit[0][FAULT_TYPE_CC_OVP]  = CCG_CC_SBU_OVP_RETRY_LIMIT;
    gl_app_fault_retry_limit[0][FAULT_TYPE_SBU_OVP] = CCG_CC_SBU_OVP_RETRY_LIMIT;

#if CCG_PD_DUALPORT_ENABLE
    gl_app_fault_retry_limit[1][FAULT_TYPE_CC_OVP]  = CCG_CC_SBU_OVP_RETRY_LIMIT;
    gl_app_fault_retry_limit[1][FAULT_TYPE_SBU_OVP] = CCG_CC_SBU_OVP_RETRY_LIMIT;
#endif /* CCG_PD_DUALPORT_ENABLE */
#endif /* (CCG_CC_SBU_OVP_RETRY_LIMIT != 0) */

    /* Register a callback for notification of CC/SBU faults. */
    ccg_set_fault_cb(app_cc_sbu_fault_handler);

    /* Register a handler that will be notified when there is any change in V5V or VSYS state. */
    pd_hal_set_supply_change_evt_cb(app_ccg5_supply_change_cb);

}

/* Implements CCG deep sleep functionality for power saving. */
bool system_sleep(void)
{
    uint8_t intr_state;
    bool dpm_slept = false;
    bool app_slept = false;
    bool app_type_c_slept = false;
    bool retval = false;
#if BATTERY_CHARGING_ENABLE
    bool bc_slept = false;
#endif /* BATTERY_CHARGING_ENABLE */

    intr_state = CyEnterCriticalSection();

    /*
     * We have to check the application layer, HPI and the Device Policy
     * Manager (DPM) to see if all of these modules are ready for sleep.
     * CCG can only enter deep sleep if all of these blocks are in an idle
     * state.
     *
     * Note: The respective sleep functions might be performing some
     * state updates as part of the idle check function; and therefore
     * the corresponding wakeup function needs to be called if they have
     * returned true to indicate that sleep is allowed.
     */
    if (app_sleep())
    {
        app_slept = true;

#if BATTERY_CHARGING_ENABLE
        if(bc_sleep() == true)
        {
            bc_slept = true;
#endif /* BATTERY_CHARGING_ENABLE */

            if (
#if CCG_HPI_ENABLE
                    (hpi_sleep_allowed()) &&
#endif /* CCG_HPI_ENABLE */

#if CCG_UCSI_ENABLE
                    (ucsi_sleep_allowed()) &&
#endif /* CCG_UCSI_ENABLE */


                    (dpm_deepsleep())
               )
            {
                dpm_slept = true;
                /*
                 * Check connection status of TYPE-A and TYPE-C ports to determine if deepsleep
                 * entry is allowed. If not,enter sleep mode to save power.
                 */
                if (
                    (app_type_c_sleep_allowed() == true)
                    )
                {
                    app_type_c_slept = true;
                    timer_enter_sleep();

                    /*
                     * CDT 224642: The I2C IDLE check needs to be done as the last step
                     * before device enters into sleep. Otherwise, the device may fail
                     * to wake up when there is an address match on the I2C interface.
                     */
#if ((CCG_HPI_ENABLE) || (RIDGE_SLAVE_ENABLE))
                    if (
    #if CCG_HPI_ENABLE
                            (hpi_sleep())
    #else
                            (1)
    #endif /* CCG_HPI_ENABLE */
                            &&
    #if RIDGE_SLAVE_ENABLE
                            (ridge_slave_sleep())
    #else
                            (1)
    #endif /* RIDGE_SLAVE_ENABLE */
                       )
#endif /* ((CCG_HPI_ENABLE) || (RIDGE_SLAVE_ENABLE)) */
                    {
                        /* Device sleep entry. */
                        CySysPmDeepSleep();
                        retval = true;
                    }
                }
                else
                {
                }
            }
#if BATTERY_CHARGING_ENABLE
        }
#endif /* BATTERY_CHARGING_ENABLE */
    }

    CyExitCriticalSection(intr_state);

    if (app_type_c_slept)
    {
        app_type_c_wakeup();
    }

    /* Call dpm_wakeup() if dpm_sleep() had returned true. */
    if(dpm_slept)
    {
        dpm_wakeup();
    }

    /* Call app_wakeup() if app_sleep() had returned true. */
    if(app_slept)
    {
        app_wakeup();
    }

#if BATTERY_CHARGING_ENABLE
    if(bc_slept)
    {
        bc_wakeup();
    }
#endif /* BATTERY_CHARGING_ENABLE */

    return retval;
}

#if VCONN_OCP_ENABLE
void app_vconn_ocp_cbk(uint8_t port, bool comp_out)
{
    /* Disable VConn since we hit a fault. */
    vconn_disable(port, dpm_get_info(port)->rev_pol);

    /* Notify application layer about fault. */
    app_event_handler(port, APP_EVT_VCONN_OCP_FAULT, NULL);
}
#endif /* VCONN_OCP_ENABLE */

bool vconn_enable(uint8_t port, uint8_t channel)
{
#if VCONN_OCP_ENABLE

    /* Do not attempt to enable VConn if fault was detected in present connection. */
    if ((app_status[port].fault_status & APP_PORT_VCONN_FAULT_ACTIVE) != 0)
    {
        return false;
    }


    system_vconn_ocp_en(port, app_vconn_ocp_cbk);
#endif /* VCONN_OCP_ENABLE */

    /* Reset RX Protocol for cable */
    dpm_prot_reset_rx(port, SOP_PRIME);
    dpm_prot_reset_rx(port, SOP_DPRIME);

    if (pd_vconn_enable(port, channel) != CCG_STAT_SUCCESS)
    {
        app_status[port].fault_status |= APP_PORT_V5V_SUPPLY_LOST;
        return false;
    }
    return true;
}

void vconn_disable(uint8_t port, uint8_t channel)
{
    pd_vconn_disable(port, channel);

#if VCONN_OCP_ENABLE
    system_vconn_ocp_dis(port);
#endif /* VCONN_OCP_ENABLE */
}

bool vconn_is_present(uint8_t port)
{
    return pd_is_vconn_present( port, dpm_get_info(port)->rev_pol);
}

bool vbus_is_present(uint8_t port, uint16_t volt, int8 per)
{
    uint8_t level;
    uint8_t retVal;


    /*
     * Re-run calibration every time to ensure that VDDD or the measurement
     * does not break.
     */
    pd_adc_calibrate (port, APP_VBUS_POLL_ADC_ID);
    level = pd_get_vbus_adc_level(port, APP_VBUS_POLL_ADC_ID, volt, per);
    retVal = pd_adc_comparator_sample (port, APP_VBUS_POLL_ADC_ID, APP_VBUS_POLL_ADC_INPUT, level);


    return retVal;
}

uint16_t vbus_get_value(uint8_t port)
{
    uint16_t retVal;


    /* Measure the actual VBUS voltage. */
    retVal = pd_hal_measure_vbus(port);


    return retVal;
}

#if VCONN_OCP_ENABLE
bool system_vconn_ocp_en(uint8_t port, PD_ADC_CB_T cbk)
{
    if (cbk == NULL)
    {
        return false;
    }


    /* Request the HAL to enable OCP detection with the appropriate debounce period. */
    pd_hal_vconn_ocp_enable(port, pd_get_ptr_vconn_ocp_tbl(port)->debounce, cbk);

    return true;
}

void system_vconn_ocp_dis(uint8_t port)
{

    /* Disable VConn OCP detection in the HAL. */
    pd_hal_vconn_ocp_disable(port);

}

#endif /* VCONN_OCP_ENABLE */

/* End of File */
