/**
 * @file pdo.c
 *
 * @brief @{PDO evaluation and handling functions.@}
 *
 *******************************************************************************
 *
 * Copyright (2014-2019), Cypress Semiconductor Corporation or a subsidiary of
 * Cypress Semiconductor Corporation. All rights reserved.
 *
 * This software, including source code, documentation and related materials
 * (“Software”), is owned by Cypress Semiconductor Corporation or one of its
 * subsidiaries (“Cypress”) and is protected by and subject to worldwide patent
 * protection (United States and foreign), United States copyright laws and
 * international treaty provisions. Therefore, you may use this Software only
 * as provided in the license agreement accompanying the software package from
 * which you obtained this Software (“EULA”).
 *
 * If no EULA applies, Cypress hereby grants you a personal, nonexclusive,
 * non-transferable license to copy, modify, and compile the Software source
 * code solely for use in connection with Cypress’s integrated circuit
 * products. Any reproduction, modification, translation, compilation, or
 * representation of this Software except as specified above is prohibited
 * without the express written permission of Cypress. Disclaimer: THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress reserves the
 * right to make changes to the Software without notice. Cypress does not
 * assume any liability arising out of the application or use of the Software
 * or any product or circuit described in the Software. Cypress does not
 * authorize its products for use in any products where a malfunction or
 * failure of the Cypress product may reasonably be expected to result in
 * significant property damage, injury or death (“High Risk Product”). By
 * including Cypress’s product in a High Risk Product, the manufacturer of such
 * system or application assumes all risk of such use and in doing so agrees to
 * indemnify Cypress against all liability.
 */

#include <config.h>
#include <pd.h>
#include <dpm.h>
#include <pdo.h>
#include <app.h>
#include <timer.h>
#if CCG_HPI_ENABLE
#include <hpi.h>
#endif /* CCG_HPI_ENABLE */
#include "srom_vars.h"



#if (!(CCG_SOURCE_ONLY))

/* PDO Variables. */
uint32_t gl_max_min_cur_pwr[NO_OF_TYPEC_PORTS];
uint32_t gl_contract_power[NO_OF_TYPEC_PORTS];
uint32_t gl_contract_voltage[NO_OF_TYPEC_PORTS];
uint32_t gl_op_cur_power[NO_OF_TYPEC_PORTS];

ATTRIBUTES static uint32_t calc_power(uint32_t voltage, uint32_t current)
{
    /*
       Voltage is expressed in 50 mV units.
       Current is expressed in 10 mA units.
       Power should be expressed in 250 mW units.
     */
    return (CALL_OUT_FUNCTION(div_round_up)(voltage * current, 500));
}

#if !DISABLE_PDO_BATTERY
ATTRIBUTES static uint32_t calc_current(uint32_t power, uint32_t voltage)
{
    /*
       Power is expressed in 250 mW units.
       Voltage is expressed in 50 mV units.
       Current should be expressed in 10 mA units.
     */
    return (CALL_OUT_FUNCTION(div_round_up)(power * 500, voltage));
}
#endif /* DISABLE_PDO_BATTERY */

#if CCG_UCSI_ENABLE
#if UCSI_SET_PWR_LEVEL_ENABLE    
#define PWR_LVL_4P5W                    (9)         /* 4.5W in 0.5W units */
#define PWR_LVL_4P0W                    (8)         /* 4W in 0.5W units */    
#define MIN_CURRENT                     (90)        /* 900mA in 10mA units */

/**
 * @brief Edit the advertised PDOs to match the OS's requirements
 *
 * @param port The port whose PDOs need editing
 * @param power Final power level that the OS wants CCG to get to
 * @param is_src Set to '1' if the Source Caps need editing. For Sink Caps, its set to '0'
 * @param &out_mask An output variable indicating a bitmask of enabled PDOs
 *
 * @return 
 *    NULL If CCG should fail the command by setting the Error Indicator
 *    pd_do_t[7] A 7-element PD data object array of edited PDOs
 */
pd_do_t* ucsi_change_pdo_power(uint8_t port, uint8_t power, uint8_t is_src, uint8_t *out_mask)
{
    uint8_t i, pdo_cnt;
    uint32_t cur_power;
    const pd_do_t* cur_pdo;
    static pd_do_t pdos[MAX_NO_OF_PDO];

    /* This is a source-only application. Sink PDOs are not expected to be edited */
    if(is_src == 0)
        return NULL;
    
    /* Always enable 5V */
    *out_mask = 1;

    /* Take the number of PDOs and the list from the configuration table */
    pdo_cnt = get_pd_port_config(port)->src_pdo_cnt;
    cur_pdo = (pd_do_t*)get_pd_port_config(port)->src_pdo_list;
    
    for(i = 0; i < pdo_cnt; i++)
    {
        pdos[i].val = cur_pdo[i].val;
        
        /* If the OPM sets PD power level to 0 or 255, we revert to the default configuration */
        if((power == 0) || (power == 0xFF))
            *out_mask |= (1 << i);
        else
        {
            switch(pdos[i].fixed_src.supply_type)
            {
                case PDO_FIXED_SUPPLY:
                    cur_power = calc_power(pdos[i].fixed_src.voltage, pdos[i].fixed_src.max_current);
                    /* Force the max current to be within 900mA and 3A */
                    pdos[i].fixed_src.max_current = GET_MAX(MIN_CURRENT, GET_MIN((2 * power * pdos[i].fixed_src.max_current) / cur_power, CBL_CAP_3A));

                    /* Enable other PDOs only if requested power is >4.5W */
                    if(power > PWR_LVL_4P5W)
                        *out_mask |= (1 << i);
                    break;
                    
                case PDO_VARIABLE_SUPPLY:
                    cur_power = calc_power(pdos[i].var_src.max_voltage, pdos[i].var_src.max_current);
                    pdos[i].var_src.max_current = GET_MAX(MIN_CURRENT, GET_MIN((2 * power * pdos[i].var_src.max_current) / cur_power, CBL_CAP_3A));
                    *out_mask |= (1 << i);
                    break;
                    
                case PDO_BATTERY:
                    pdos[i].bat_src.max_power = power * 2;
                    *out_mask |= (1 << i);
                    break;
            }
        }
    }

    return pdos;
}
#endif /*UCSI_SET_PWR_LEVEL_ENABLE*/
#endif /* CCG_UCSI_ENABLE */

/**
 * Checks if SRC pdo is acceptable for SNK pdo.
 * @param pdo_src pointer to current SRC PDO
 * @param pdo_snk pointer to current SNK PDO
 * @return True if current src pdo is acceptable for current snk pdo
 */
ATTRIBUTES static bool is_src_acceptable_snk(uint8_t port, pd_do_t* pdo_src, uint8_t snk_pdo_idx)
{
    const dpm_status_t* dpm = CALL_OUT_FUNCTION(dpm_get_info)(port);
    pd_do_t* pdo_snk = (pd_do_t*)&dpm->cur_snk_pdo[snk_pdo_idx];
    uint32_t snk_supply_type = pdo_snk->fixed_snk.supply_type;
    uint32_t fix_volt;
    uint32_t max_volt;
    uint32_t min_volt;
    uint32_t out = false;
    uint32_t max_min_temp, compare_temp;
#if !DISABLE_PDO_BATTERY    
    uint32_t oper_cur_pwr;
#endif /* DISABLE_PDO_BATTERY */

    max_min_temp = dpm->cur_snk_max_min[snk_pdo_idx] & SNK_MIN_MAX_MASK;

    switch(pdo_src->fixed_src.supply_type)
    {
        case PDO_FIXED_SUPPLY:  /* Fixed supply PDO */
            fix_volt = pdo_src->fixed_src.voltage;
            max_volt = CALL_OUT_FUNCTION(div_round_up)(fix_volt, 20);
            min_volt = fix_volt - max_volt;
            max_volt = fix_volt + max_volt;

            switch(snk_supply_type)  /* Checking sink PDO type */
            {
                case PDO_FIXED_SUPPLY:
                    if(fix_volt == pdo_snk->fixed_snk.voltage)
                    {
                        compare_temp = GET_MAX (max_min_temp, pdo_snk->fixed_snk.op_current);
                        if (pdo_src->fixed_src.max_current >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_op_cur_power)[port] = pdo_snk->fixed_snk.op_current;
                            out = true;
                        }
                    }
                    break;

                case PDO_VARIABLE_SUPPLY:
                    if ((min_volt >= pdo_snk->var_snk.min_voltage) && (max_volt <= pdo_snk->var_snk.max_voltage))
                    {
                        compare_temp = GET_MAX (max_min_temp, pdo_snk->var_snk.op_current);
                        if (pdo_src->fixed_src.max_current >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_op_cur_power)[port] = pdo_snk->var_snk.op_current;
                            out = true;
                        }
                    }
                    break;
#if !DISABLE_PDO_BATTERY
                case PDO_BATTERY:
                    if ((min_volt >= pdo_snk->bat_snk.min_voltage) && (max_volt <= pdo_snk->bat_snk.max_voltage))
                    {
                        fix_volt = min_volt;

                        /* Calculate the operating current and min/max current values. */
                        oper_cur_pwr = calc_current(pdo_snk->bat_snk.op_power, min_volt);
                        max_min_temp = calc_current(max_min_temp, min_volt);

                        /* Make sure the source can supply the maximum current that may be required. */
                        compare_temp = GET_MAX(max_min_temp, oper_cur_pwr);
                        if (pdo_src->fixed_src.max_current >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_op_cur_power)[port] = oper_cur_pwr;
                            out = true;
                        }
                    }
                    break;
#endif /* DISABLE_PDO_BATTERY */
                default:
                    break;
            }

            if (out)
            {
                GET_IN_VARIABLE(gl_contract_voltage)[port] = fix_volt;
                GET_IN_VARIABLE(gl_contract_power)[port]   = calc_power (fix_volt, GET_IN_VARIABLE(gl_op_cur_power)[port]);
                GET_IN_VARIABLE(gl_max_min_cur_pwr)[port]  = max_min_temp;
            }
            break;

#if !DISABLE_PDO_BATTERY
        case PDO_BATTERY:   /* SRC is a battery */
            max_volt = pdo_src->bat_src.max_voltage;
            min_volt = pdo_src->bat_src.min_voltage;

            switch(snk_supply_type)
            {
                case PDO_FIXED_SUPPLY:
                    /* Battery cannot supply fixed voltage
                     * Battery voltage changes with time
                     * This contract if permitted can be un-reliable */
                    break;

                case PDO_VARIABLE_SUPPLY:
                    if((min_volt >= pdo_snk->var_snk.min_voltage) && (max_volt <= pdo_snk->var_snk.max_voltage))
                    {
                        /* Calculate the expected operating power and maximum power requirement. */
                        oper_cur_pwr = calc_power(max_volt, pdo_snk->var_snk.op_current);
                        max_min_temp = calc_power(max_volt, max_min_temp);

                        compare_temp = GET_MAX (max_min_temp, oper_cur_pwr);
                        if (pdo_src->bat_src.max_power >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_op_cur_power)[port] = oper_cur_pwr;
                            out = true;
                        }
                    }
                    break;

                case PDO_BATTERY:
                    /* Battery connected directly to a battery
                     * This combination is unreliable */
                    if((min_volt >= pdo_snk->bat_snk.min_voltage) && (max_volt <= pdo_snk->bat_snk.max_voltage))
                    {
                        compare_temp = GET_MAX (max_min_temp, pdo_snk->bat_snk.op_power);
                        if (pdo_src->bat_src.max_power >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_op_cur_power)[port] = pdo_snk->bat_snk.op_power;
                            out = true;
                        }
                    }
                    break;

                default:
                    break;
            }

            if (out)
            {
                GET_IN_VARIABLE(gl_contract_voltage)[port] = max_volt;
                GET_IN_VARIABLE(gl_max_min_cur_pwr)[port]  = max_min_temp;
                GET_IN_VARIABLE(gl_contract_power)[port]   = GET_IN_VARIABLE(gl_op_cur_power)[port];
            }
            break;
#endif /* DISABLE_PDO_BATTERY */

        case PDO_VARIABLE_SUPPLY:   /* Variable supply PDO */
            max_volt = pdo_src->var_src.max_voltage;
            min_volt = pdo_src->var_src.min_voltage;

            switch (snk_supply_type) /* Checking sink PDO type */
            {
                case PDO_FIXED_SUPPLY:
                    /* This connection is not feasible
                     * A variable source cannot provide a fixed voltage */
                    break;

                case PDO_VARIABLE_SUPPLY:
                    if((min_volt >= pdo_snk->var_snk.min_voltage) && (max_volt <= pdo_snk->var_snk.max_voltage))
                    {
                        compare_temp = GET_MAX (pdo_snk->var_snk.op_current, max_min_temp);
                        if (pdo_src->var_src.max_current >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_contract_power)[port] = calc_power(min_volt, pdo_snk->var_snk.op_current);
                            GET_IN_VARIABLE(gl_op_cur_power)[port]   = pdo_snk->var_snk.op_current;
                            out = true;
                        }
                    }
                    break;
#if !DISABLE_PDO_BATTERY
                case PDO_BATTERY:
                    if((min_volt >= pdo_snk->bat_snk.min_voltage) && (max_volt <= pdo_snk->bat_snk.max_voltage))
                    {
                        /* Convert from power to current. */
                        oper_cur_pwr = calc_current(pdo_snk->bat_snk.op_power, min_volt);
                        max_min_temp = calc_current(max_min_temp, min_volt);

                        compare_temp = GET_MAX (oper_cur_pwr, max_min_temp);
                        if (pdo_src->var_src.max_current >= compare_temp)
                        {
                            GET_IN_VARIABLE(gl_contract_power)[port] = pdo_snk->bat_snk.op_power;
                            GET_IN_VARIABLE(gl_op_cur_power)[port]   = oper_cur_pwr;
                            out = true;
                        }
                    }
                    break;
#endif /* DISABLE_PDO_BATTERY */
                default:
                    break;
            }

            if (out)
            {
                GET_IN_VARIABLE(gl_contract_voltage)[port] = max_volt;
                GET_IN_VARIABLE(gl_max_min_cur_pwr)[port]  = max_min_temp;
            }
            break;

        default:
            break;
    }

    return out;
}

ATTRIBUTES static pd_do_t form_rdo(uint8_t port, uint8_t pdo_no, bool capMisMatch, bool giveBack)
{
    const dpm_status_t* dpm = CALL_OUT_FUNCTION(dpm_get_info)(port);
    pd_do_t snk_rdo;

    snk_rdo.val = 0u;
    snk_rdo.rdo_gen.no_usb_suspend = dpm->snk_usb_susp_en;
    snk_rdo.rdo_gen.usb_comm_cap = dpm->snk_usb_comm_en;
    snk_rdo.rdo_gen.cap_mismatch = capMisMatch;
    snk_rdo.rdo_gen.obj_pos = pdo_no;
    snk_rdo.rdo_gen.give_back_flag = (capMisMatch) ? false : giveBack;
    snk_rdo.rdo_gen.op_power_cur = GET_IN_VARIABLE(gl_op_cur_power)[port];
    snk_rdo.rdo_gen.min_max_power_cur = GET_IN_VARIABLE(gl_max_min_cur_pwr)[port];

    if( (snk_rdo.rdo_gen.give_back_flag == false) &&
            (snk_rdo.rdo_gen.op_power_cur > snk_rdo.rdo_gen.min_max_power_cur))
    {
        snk_rdo.rdo_gen.min_max_power_cur = snk_rdo.rdo_gen.op_power_cur;
    }

#if CCG_PD_REV3_ENABLE
    if(dpm->spec_rev_sop_live >= PD_REV3)
    {
        snk_rdo.rdo_gen.unchunk_sup = true;
    }
#endif /* (CCG_SROM_CODE_ENABLE | CCG_PD_REV3_ENABLE) */

    return snk_rdo;
}


/*
 * This function can be used to ask EC to evaluate a src cap message
 * For now evaluating here and executing the callback in this function itself
 */
ATTRIBUTES void eval_src_cap(uint8_t port, const pd_packet_t* src_cap, app_resp_cbk_t app_resp_handler)
{
    const dpm_status_t* dpm = CALL_OUT_FUNCTION(dpm_get_info)(port);
    uint8_t src_pdo_index, snk_pdo_index;
    uint8_t num_src_pdo = src_cap->len;
    pd_do_t* snk_pdo = (pd_do_t*)&dpm->cur_snk_pdo[0];
    uint16_t src_vsafe5_cur = src_cap->dat[0].fixed_src.max_current; /* Source max current for first PDO */
    pd_do_t snk_rdo;
    uint32_t highest_gl_contract_power = 0u;

    bool match = false;
    bool high_cap = snk_pdo[0].fixed_snk.high_cap;

    for(snk_pdo_index = 0u; snk_pdo_index < dpm->cur_snk_pdo_count; snk_pdo_index++)
    {
        for(src_pdo_index = 0u; src_pdo_index < num_src_pdo; src_pdo_index++)
        {
            if(is_src_acceptable_snk(port, (pd_do_t*)(&src_cap->dat[src_pdo_index]), snk_pdo_index))
            {
                /* Contract_power is calculated in is_src_acceptable_snk() */
                if (GET_IN_VARIABLE(gl_contract_power)[port] >= highest_gl_contract_power)
                {
                    /* Check if sink needs higher capability */
                    if ((high_cap) && (GET_IN_VARIABLE(gl_contract_voltage)[port] == (VSAFE_5V/PD_VOLT_PER_UNIT)))
                    {
                        /* 5V contract isn't acceptable with high_cap = 1 */
                        continue;
                    }

                    highest_gl_contract_power = GET_IN_VARIABLE(gl_contract_power)[port];
                    snk_rdo = form_rdo(port, (src_pdo_index + 1u), false,
                            (dpm->cur_snk_max_min[snk_pdo_index] & GIVE_BACK_MASK));
                    match = true;

                }
            }
        }
    }

    if(match == false)
    {
        /* Capability mismatch: Ask for vsafe5v PDO with CapMismatch */
        GET_IN_VARIABLE(gl_contract_voltage)[port] = snk_pdo[0].fixed_snk.voltage;
        GET_IN_VARIABLE(gl_op_cur_power)[port] = snk_pdo[0].fixed_snk.op_current;
        GET_IN_VARIABLE(gl_contract_power)[port] = CALL_OUT_FUNCTION(div_round_up)(
                GET_IN_VARIABLE(gl_contract_voltage)[port] * GET_IN_VARIABLE(gl_op_cur_power)[port], 500u);

        if(src_vsafe5_cur < GET_IN_VARIABLE(gl_op_cur_power)[port])
        {
            /* SNK operation current can't be bigger than SRC max_current */
            GET_IN_VARIABLE(gl_op_cur_power)[port] = src_vsafe5_cur;
        }

        GET_IN_VARIABLE(gl_max_min_cur_pwr)[port] = dpm->cur_snk_max_min[0];
        snk_rdo = form_rdo(port, 1u, true, false);
    }

    (CALL_OUT_FUNCTION(app_get_resp_buf)(port))->resp_do = snk_rdo;
    app_resp_handler(port, CALL_OUT_FUNCTION(app_get_resp_buf)(port));
}
#endif /* (!(CCG_SOURCE_ONLY)) */

/*
 * This function can be used to ask EC to evaluate a request message
 * For now evaluating here and executing the callback in this function itself
 */
ATTRIBUTES void eval_rdo(uint8_t port, pd_do_t rdo, app_resp_cbk_t app_resp_handler)
{
    if (CALL_OUT_FUNCTION(dpm_is_rdo_valid)(port, rdo) == CCG_STAT_SUCCESS)
    {
        CALL_OUT_FUNCTION(app_get_resp_buf)(port)->req_status = REQ_ACCEPT;
    }
    else
    {
        CALL_OUT_FUNCTION(app_get_resp_buf)(port)->req_status = REQ_REJECT;
    }

    app_resp_handler(port, CALL_OUT_FUNCTION(app_get_resp_buf)(port));
}



/* End of File */

