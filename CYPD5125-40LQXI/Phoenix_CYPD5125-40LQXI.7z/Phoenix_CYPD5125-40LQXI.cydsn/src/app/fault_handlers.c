/**
 * @file fault_handlers.c
 *
 * @brief @{PD power related fault handling source file.@}
 *
 *******************************************************************************
 *
 * Copyright (2014-2019), Cypress Semiconductor Corporation or a subsidiary of
 * Cypress Semiconductor Corporation. All rights reserved.
 *
 * This software, including source code, documentation and related materials
 * (“Software”), is owned by Cypress Semiconductor Corporation or one of its
 * subsidiaries (“Cypress”) and is protected by and subject to worldwide patent
 * protection (United States and foreign), United States copyright laws and
 * international treaty provisions. Therefore, you may use this Software only
 * as provided in the license agreement accompanying the software package from
 * which you obtained this Software (“EULA”).
 *
 * If no EULA applies, Cypress hereby grants you a personal, nonexclusive,
 * non-transferable license to copy, modify, and compile the Software source
 * code solely for use in connection with Cypress’s integrated circuit
 * products. Any reproduction, modification, translation, compilation, or
 * representation of this Software except as specified above is prohibited
 * without the express written permission of Cypress. Disclaimer: THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress reserves the
 * right to make changes to the Software without notice. Cypress does not
 * assume any liability arising out of the application or use of the Software
 * or any product or circuit described in the Software. Cypress does not
 * authorize its products for use in any products where a malfunction or
 * failure of the Cypress product may reasonably be expected to result in
 * significant property damage, injury or death (“High Risk Product”). By
 * including Cypress’s product in a High Risk Product, the manufacturer of such
 * system or application assumes all risk of such use and in doing so agrees to
 * indemnify Cypress against all liability.
 */

#include <config.h>
#include <pd.h>
#include <dpm.h>
#include <psource.h>
#include <psink.h>
#include <pdo.h>
#include <swap.h>
#include <vdm.h>
#include <app.h>
#include <vdm_task_mngr.h>
#include <timer.h>
#include <alt_mode_hw.h>
#include <alt_modes_mngr.h>
#include <hal_ccgx.h>
#include <gpio.h>
#include <system.h>
#include <utils.h>

#if CCG_HPI_ENABLE
#include <hpi.h>
#endif /* CCG_HPI_ENABLE */




#if RIDGE_SLAVE_ENABLE
#include <ridge_slave.h>
#include <intel_ridge.h>
#endif /* RIDGE_SLAVE_ENABLE */

enum {
    FAULT_TYPE_VBUS_OVP = 0,    /* 0 */
    FAULT_TYPE_VBUS_UVP,        /* 1 */
    FAULT_TYPE_VBUS_OCP,        /* 2 */
    FAULT_TYPE_VBUS_SCP,        /* 3 */
    FAULT_TYPE_CC_OVP,          /* 4 */
    FAULT_TYPE_VCONN_OCP,       /* 5 */
    FAULT_TYPE_SBU_OVP,         /* 6 */
    FAULT_TYPE_OTP,             /* 7 */
    FAULT_TYPE_VBUS_RCP,        /* 8 */
    FAULT_TYPE_COUNT            /* 9 */
};

/* Variable defined in app.c */
extern app_status_t app_status[];

#if (VBUS_OCP_ENABLE | VBUS_SCP_ENABLE | VBUS_OVP_ENABLE | VBUS_UVP_ENABLE | VBUS_RCP_ENABLE)
#define FAULT_HANDLER_ENABLE            (1)             /* Shorthand for any faults enabled. */
#endif /* (VBUS_OCP_ENABLE | VBUS_SCP_ENABLE | VBUS_OVP_ENABLE| VBUS_UVP_ENABLE | VBUS_RCP_ENABLE) */

#if FAULT_HANDLER_ENABLE

/* Number of retries defined by user for each fault type. */
static uint8_t gl_app_fault_retry_limit[NO_OF_TYPEC_PORTS][FAULT_TYPE_COUNT] = {
    {0}
};

/* Number of times each fault condition has been detected during current connection. */
static volatile uint8_t gl_app_fault_count[NO_OF_TYPEC_PORTS][FAULT_TYPE_COUNT] = {
    {0}
};


/* Check whether any fault count has exceeded limit for the specified PD port. */
static bool app_port_fault_count_exceeded(uint8_t port)
{
    uint32_t i;
    bool     retval = false;

    /*
     * Check whether the count for any fault type has exceeded the limit specified.
     */
    for (i = 0; i < FAULT_TYPE_COUNT; i++)
    {
        if (gl_app_fault_count[port][i] > gl_app_fault_retry_limit[port][i])
        {
            retval = true;
            break;
        }
    }

    return (retval);
}

/* This function stops PD operation and configures Type-C to look for detach of faulty device. */
void app_conf_for_faulty_dev_removal(uint8_t port)
{
    const dpm_status_t *dpm_stat = dpm_get_info(port);

    if ((!dpm_stat->attach) || (dpm_stat->cur_port_role == PRT_ROLE_SINK))
    {
        /* Set flag to trigger port disable sequence. */
        app_status[port].fault_status |= APP_PORT_SINK_FAULT_ACTIVE;
    }

    /* Stop PE */
    dpm_pe_stop(port);

#if ((DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP))
    /* Make sure any alternate mode related state is cleared. */
    vdm_task_mngr_deinit (port);
#endif /* (DFP_ALT_MODE_SUPP) || (UFP_ALT_MODE_SUPP) */
}

/* Generic routine that notifies the stack about recovery actions for a fault. */
static void app_handle_fault(uint8_t port, uint32_t fault_type)
{
    uint8_t reason = PD_HARDRES_REASON_VBUS_OVP;

    if (fault_type == FAULT_TYPE_VBUS_OCP)
    {
        reason = PD_HARDRES_REASON_VBUS_OCP;
    }

    /* Not checking for validity of port or fault_type as all calls to this function are internal. */
    dpm_set_fault_active(port);


    {
        /* Update the fault count. */
        gl_app_fault_count[port][fault_type]++;
    }

    if (gl_app_fault_count[port][fault_type] < (gl_app_fault_retry_limit[port][fault_type] + 1))
    {
        dpm_clear_hard_reset_count(port);

        /*
         * Try a Hard Reset to recover from fault.
         * If not successful (not in PD contract), try Type-C error recovery.
         */
        if (dpm_send_hard_reset (port, reason) != CCG_STAT_SUCCESS)
        {
            dpm_typec_command(port, DPM_CMD_TYPEC_ERR_RECOVERY, NULL);
        }
    }
    else
    {
        app_conf_for_faulty_dev_removal(port);
    }
}

/* Timer used to re-enable the PD port after a fault. */
static void fault_recovery_timer_cb(uint8_t port, timer_id_t id)
{
    uint16_t period = APP_FAULT_RECOVERY_TIMER_PERIOD;

    if (
            (vbus_is_present(port, VSAFE_0V, 0) == false)
       )
    {
        if ((app_status[port].fault_status & APP_PORT_VBUS_DROP_WAIT_ACTIVE) != 0)
        {
            app_status[port].fault_status &= ~APP_PORT_VBUS_DROP_WAIT_ACTIVE;

            /* VBus has already been removed. Enable the Rd termination to check for physical detach. */
            pd_typec_rd_enable (port);
            period = APP_FAULT_RECOVERY_MAX_WAIT;
        }
        else
        {
            /*
             * If VBus is not detected, we can re-enable the PD port.
             */
            app_status[port].fault_status &= ~APP_PORT_DISABLE_IN_PROGRESS;
            dpm_clear_fault_active(port);

            pd_typec_dis_rd(port, CC_CHANNEL_1);
            pd_typec_dis_rd(port, CC_CHANNEL_2);
            dpm_start(port);

            /* Return without restarting the timer. */
            return;
        }
    }

    /* Restart the timer to check VBus and Rp status again. */
    timer_start (port, APP_FAULT_RECOVERY_TIMER, period, fault_recovery_timer_cb);
}

/* Callback used to get notification that PD port disable has been completed. */
static void app_port_disable_cb(uint8_t port, dpm_typec_cmd_resp_t resp)
{
    uint16_t period = APP_FAULT_RECOVERY_TIMER_PERIOD;

    if (
            (vbus_is_present(port, VSAFE_0V, 0) == false)
       )
    {
        /* VBus has already been removed. Enable the Rd termination to check for physical detach. */
        pd_typec_rd_enable (port);
        period = APP_FAULT_RECOVERY_MAX_WAIT;
    }
    else
    {
        /* VBus has not been removed. Start a task which waits for VBus removal. */
        app_status[port].fault_status |= APP_PORT_VBUS_DROP_WAIT_ACTIVE;
    }

    /* Provide a delay to allow VBus turn-on by port partner and then enable the port. */
    timer_start (port, APP_FAULT_RECOVERY_TIMER, period, fault_recovery_timer_cb);
}

static void src_disable_cbk(uint8_t port)
{
    /* Dummy callback used to ensure VBus discharge happens on CC/SBU OVP. */
}

#endif /* FAULT_HANDLER_ENABLE */

/* Clear all fault counters associated with the specified port. */
void fault_handler_clear_counts (uint8_t port)
{
#if FAULT_HANDLER_ENABLE
    /* Clear all fault counters on disconnect. */
    memset ((uint8_t *)gl_app_fault_count[port], 0, FAULT_TYPE_COUNT);
#endif /* FAULT_HANDLER_ENABLE */
}

/* Fault-handling specific actions to be performed for various event callbacks. */
bool fault_event_handler(uint8_t port, app_evt_t evt, const void *dat)
{
    bool skip_soln_cb = false;

#if FAULT_HANDLER_ENABLE
    const dpm_status_t *dpm_stat = dpm_get_info(port);

    switch (evt)
    {
        case APP_EVT_TYPE_C_ERROR_RECOVERY:
            if (app_port_fault_count_exceeded(port))
            {
                break;
            }
            /* Fall-through to below case when fault counts are within limits. */

        case APP_EVT_DISCONNECT:
        case APP_EVT_VBUS_PORT_DISABLE:
        case APP_EVT_HARD_RESET_SENT:
            /* Clear the port-in-fault status. */
            if ((app_status[port].fault_status & APP_PORT_DISABLE_IN_PROGRESS) == 0)
            {
                dpm_clear_fault_active(port);
            }

            if ((evt == APP_EVT_DISCONNECT) || (evt == APP_EVT_VBUS_PORT_DISABLE))
            {
                /* Clear fault counters in cases where an actual disconnect has been detected. */
                fault_handler_clear_counts (port);

#if RIDGE_SLAVE_ENABLE
                /* Clear the error status. */
                ridge_slave_update_ocp_status(port, false);
#endif /* RIDGE_SLAVE_ENABLE */
            }

            break;

        case APP_EVT_PD_CONTRACT_NEGOTIATION_COMPLETE:
#if (CCG_CC_SBU_OVP_RETRY_LIMIT != 0)
            /* Clear the CC/SBU OVP fault count if we have successfully negotiated a PD contract. */
            gl_app_fault_count[port][FAULT_TYPE_CC_OVP]  = 0;
            gl_app_fault_count[port][FAULT_TYPE_SBU_OVP] = 0;
#endif /* (CCG_CC_SBU_OVP_RETRY_LIMIT != 0) */
            break;

#if VBUS_OCP_ENABLE
        case APP_EVT_VBUS_OCP_FAULT:
#if RIDGE_SLAVE_ENABLE
            /* Update the OCP status. */
            ridge_slave_update_ocp_status(port, true);
#endif /* RIDGE_SLAVE_ENABLE */
            app_handle_fault(port, FAULT_TYPE_VBUS_OCP);
            break;
#endif /* VBUS_OCP_ENABLE */



#if VBUS_OVP_ENABLE
        case APP_EVT_VBUS_OVP_FAULT:
            app_handle_fault(port, FAULT_TYPE_VBUS_OVP);
            break;
#endif /* VBUS_OVP_ENABLE */

#if VBUS_UVP_ENABLE
        case APP_EVT_VBUS_UVP_FAULT:
            app_handle_fault(port, FAULT_TYPE_VBUS_UVP);
            break;
#endif /* VBUS_UVP_ENABLE */

    case APP_EVT_CC_OVP:
    case APP_EVT_SBU_OVP:
        {
            /* Make sure SOURCE/SINK FETs and VConn supply are turned OFF. */
            vconn_disable(port, dpm_stat->rev_pol);
            if ((dpm_stat->attach) && (dpm_stat->cur_port_role == PRT_ROLE_SOURCE))
            {
                /* Remove the Rp termination and notify the HAL that OVP is pending. */
                pd_typec_dis_rp(port, dpm_stat->polarity);
                pd_hal_set_cc_ovp_pending(port);

                psrc_disable(port, src_disable_cbk);
            }
            else
            {
#if CCG_HW_DRP_TOGGLE_ENABLE
                /* Abort auto toggle if enabled. */
                pd_hal_abort_auto_toggle(port);
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */

#if (!(CCG_SOURCE_ONLY))
                psnk_disable(port, 0);
#endif /* (!(CCG_SOURCE_ONLY)) */
            }

#if VBUS_OVP_ENABLE
            /* No need to take new action as long as previous fault handling is still pending. */
            if ((app_status[port].fault_status & (APP_PORT_SINK_FAULT_ACTIVE | APP_PORT_DISABLE_IN_PROGRESS)) == 0)
            {
                app_handle_fault(port, FAULT_TYPE_CC_OVP);
            }
            else
            {
                skip_soln_cb = true;
            }
#endif /* VBUS_OVP_ENABLE */
        }
        break;

        default:
            break;
    }
#endif /* FAULT_HANDLER_ENABLE */

    return skip_soln_cb;
}

bool fault_handler_init_vars (uint8_t port)
{
#if VBUS_OVP_ENABLE
    if (get_pd_port_config(port)->ovp_tbl_offset == 0)
    {
        return false;
    }

    gl_app_fault_retry_limit[port][FAULT_TYPE_VBUS_OVP] = pd_get_ptr_ovp_tbl(port)->retry_cnt;
#endif /* VBUS_OVP_ENABLE */

#if VBUS_OCP_ENABLE
    if (get_pd_port_config(port)->ocp_tbl_offset == 0)
    {
        return false;
    }

    gl_app_fault_retry_limit[port][FAULT_TYPE_VBUS_OCP] = pd_get_ptr_ocp_tbl(port)->retry_cnt;
#endif /* VBUS_OCP_ENABLE */


#if VBUS_UVP_ENABLE
    if (get_pd_port_config(port)->uvp_tbl_offset == 0)
    {
        return false;
    }

    gl_app_fault_retry_limit[port][FAULT_TYPE_VBUS_UVP] = pd_get_ptr_uvp_tbl(port)->retry_cnt;
#endif /* VBUS_UVP_ENABLE */


    return true;
}

void fault_handler_task(uint8_t port)
{
#if FAULT_HANDLER_ENABLE
    /*
     * If SINK fault handling is pending, queue a port disable command.
     */
    if ((app_status[port].fault_status & APP_PORT_SINK_FAULT_ACTIVE) != 0)
    {
        if (dpm_typec_command (port, DPM_CMD_PORT_DISABLE, app_port_disable_cb) != CCG_STAT_BUSY)
        {
            app_status[port].fault_status &= ~APP_PORT_SINK_FAULT_ACTIVE;
            app_status[port].fault_status |= APP_PORT_DISABLE_IN_PROGRESS;
        }
    }
#endif /* FAULT_HANDLER_ENABLE */
}

#if VBUS_OVP_ENABLE

#define MAX_OVP_DEBOUNCE_CYCLES         (0x20u)

/* Configure Over-Voltage Protection checks based on parameters in config table. */
void app_ovp_enable(uint8_t port, uint16_t volt_mV, bool pfet, PD_ADC_CB_T ovp_cb)
{
#if (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC)
    uint8_t level;
    uint8_t threshold;
#else
    uint8_t debounce = 0;
#endif /* (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC) */

    uint8_t intr_state;

    if (get_pd_port_config(port)->protection_enable & CFG_TABLE_OVP_EN_MASK)
    {
        intr_state = CyEnterCriticalSection();

#if (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC)
        threshold = pd_get_ptr_ovp_tbl(port)->threshold;


        /* Set OVP threshold. */
        level = pd_get_vbus_adc_level(port, APP_OVP_ADC_ID, volt_mV, threshold);
        pd_adc_comparator_ctrl(port, APP_OVP_ADC_ID, APP_OVP_ADC_INPUT, level, PD_ADC_INT_FALLING, ovp_cb);

#else /* (VBUS_OVP_MODE != VBUS_OVP_MODE_ADC) */

        /* Convert debounce delay in us to filter clock cycles assuming the use of 500 KHz filter clock. */
        debounce = pd_get_ptr_ovp_tbl(port)->debounce;
        debounce = (debounce + 1) / 2;
        debounce = GET_MIN (debounce, MAX_OVP_DEBOUNCE_CYCLES);

        pd_internal_vbus_ovp_en(port, volt_mV, pd_get_ptr_ovp_tbl(port)->threshold, ovp_cb,
                pfet, VBUS_OVP_MODE, debounce);

#endif /* (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC) */

        CyExitCriticalSection(intr_state);
    }
}

void app_ovp_disable(uint8_t port, bool pfet)
{
    if (get_pd_port_config(port)->protection_enable & CFG_TABLE_OVP_EN_MASK)
    {
        /* Disable OVP. */
#if (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC)
        pd_adc_comparator_ctrl(port, APP_OVP_ADC_ID, 0, 0, 0, NULL);
#else
        pd_internal_vbus_ovp_dis(port, pfet);
#endif /* (VBUS_OVP_MODE == VBUS_OVP_MODE_ADC) */
    }
}

#endif /* VBUS_OVP_ENABLE */

#if VBUS_UVP_ENABLE

#define MAX_UVP_DEBOUNCE_CYCLES         (0x20u)


/* Configure Under-Voltage Protection checks based on parameters in config table. */
void app_uvp_enable(uint8_t port, uint16_t volt_mV, bool pfet, PD_ADC_CB_T uvp_cb)
{
    uint8_t intr_state;
    uint8_t debounce;

    /* Convert debounce delay in us to filter clock cycles assuming the use of 500 KHz filter clock. */
    debounce = pd_get_ptr_uvp_tbl(port)->debounce;
    debounce = (debounce + 1) / 2;
    debounce = GET_MIN (debounce, MAX_UVP_DEBOUNCE_CYCLES);

    if (get_pd_port_config(port)->protection_enable & CFG_TABLE_UVP_EN_MASK)
    {
        intr_state = CyEnterCriticalSection ();

        {
            pd_internal_vbus_uvp_en (port, volt_mV, pd_get_ptr_uvp_tbl(port)->threshold,
                    uvp_cb, pfet, VBUS_UVP_MODE, debounce);
        }

        CyExitCriticalSection (intr_state);
    }
}

void app_uvp_disable(uint8_t port, bool pfet)
{
    /* Disable UVP. */
    if (get_pd_port_config(port)->protection_enable & CFG_TABLE_UVP_EN_MASK)
    {
        pd_internal_vbus_uvp_dis (port, pfet);
    }
}

#endif /* VBUS_UVP_ENABLE */

#if OTP_ENABLE


/* Globals to keep track of OTP condition. */
static uint8_t g1_otp_therm_type[NO_OF_TYPEC_PORTS] = {APP_THERMISTOR_TYPE_ERROR};
static uint8_t gl_otp_debounce_count[NO_OF_TYPEC_PORTS] = {0};
static bool    gl_otp_debounce_active[NO_OF_TYPEC_PORTS] = {false};
static bool    gl_otp_port_disable[NO_OF_TYPEC_PORTS] = {false};

static void app_otp_init(uint8_t port)
{
    /* Initialization for port specific instance. */
    gl_otp_port_disable[port]    = false;
    gl_otp_debounce_active[port] = false;
    gl_otp_debounce_count[port]  = 0;
    g1_otp_therm_type[port]      = APP_THERMISTOR_TYPE_ERROR;
}

static uint16_t app_otp_get_therm_volt (uint8_t port)
{
    uint8_t level = 0;
    uint16_t therm_volt = 0;

    if (pd_get_ptr_otp_tbl(port)->therm_type <= APP_THERMISTOR_TYPE_PTC)
    {
        /* NTC Thermistor */
        g1_otp_therm_type[port] = pd_get_ptr_otp_tbl(port)->therm_type;
    }
    else
    {
        /* Error in configuration */
        g1_otp_therm_type[port] = APP_THERMISTOR_TYPE_ERROR;
    }

    /* Take ADC sample. */
    level = pd_adc_sample (port, PD_ADC_ID_1, PD_ADC_INPUT_AMUX_A);
    therm_volt = pd_adc_level_to_volt (port, PD_ADC_ID_1, level);
    return therm_volt;
}

static bool otp_is_ot_exist(uint8_t port, uint32_t therm_volt)
{
    return  ((g1_otp_therm_type[port] == APP_THERMISTOR_TYPE_NTC)   &&
             (therm_volt <= pd_get_ptr_otp_tbl(port)->cutoff_val)) ||
           (((g1_otp_therm_type[port] == APP_THERMISTOR_TYPE_PTC)   &&
             (therm_volt >= pd_get_ptr_otp_tbl(port)->cutoff_val)));
}

static void otp_debounce_cb(uint8_t port, timer_id_t id)
{
    uint32_t therm_volt;

    (void)id;

    /* Get thermistor voltage. */
    therm_volt = app_otp_get_therm_volt(port);

    /* If OT still exists. */
    if (otp_is_ot_exist(port, therm_volt))
    {
        if ((get_pd_port_config(port)->protection_enable & CFG_TABLE_OTP_EN_MASK))
        {
            /* OT detected. Check if it has crossed configured debounce time */
            gl_otp_debounce_count[port]++;
            if (gl_otp_debounce_count[port] > pd_get_ptr_otp_tbl(port)->debounce)
            {
                /* Valid OT detected. Disable the port now. */
                dpm_stop (port);
                gl_otp_port_disable[port] = true;
                gl_otp_debounce_active[port] = false;
            }
            else
            {
                /* Start debounce timer again. */
                timer_start (port, OTP_DEBOUNCE_TIMER_ID, OTP_DEBOUNCE_PERIOD, otp_debounce_cb);
            }
        }
        else
        {
            /* OTP feature can get disabled while debouncing is in progress.
             * There is no point continuing OTP checking in this case.
             * This is equivalent to no OTP condition.
             */
            app_otp_enable (port);
        }
    }
    else
    {
        /* OT condition doesn't exist anymore. Restart OTP detection. */
        app_otp_enable (port);
    }
}

void app_otp_check_temp(uint8_t port)
{
    uint16_t therm_volt;

    /*
     * This function will be called in a polling fashion after every expiry of
     * activity timer. Proceed and do necessary steps only if OTP protection
     * is enabled for this PD port.
     */
    if ((get_pd_port_config(port)->protection_enable & CFG_TABLE_OTP_EN_MASK))
    {
        /* Check thermistor voltage and see if it is below cut off voltage. */
        therm_volt = app_otp_get_therm_volt(port);

        /* If port is disabled then look for restart voltage. */
        if (gl_otp_port_disable[port] == true)
        {
            if (
                    ((g1_otp_therm_type[port] == APP_THERMISTOR_TYPE_NTC) &&
                     (therm_volt >= pd_get_ptr_otp_tbl(port)->restart_val)) ||
                    ((g1_otp_therm_type[port] == APP_THERMISTOR_TYPE_PTC) &&
                     (therm_volt <= pd_get_ptr_otp_tbl(port)->restart_val))
               )
            {
                /* OT condition doesn't exist anymore. Re-enable the port. */
                dpm_start(port);
                /* Reset the port specific data structures. */
                app_otp_enable(port);
            }
        }
        /* If port not disabled, look for cut off voltage. */
        else if (gl_otp_debounce_active[port] == false)
        {
            /*
             * Compare therm volt and cut off voltage and start OT debounce,
             * if required. Thermistor type value will decide the comparison
             * algorithm.
             */
            if (otp_is_ot_exist(port, therm_volt))
            {
                gl_otp_debounce_active[port] = true;
                gl_otp_debounce_count[port] = 0;
                /* Start OTP debounce timer. */
                timer_start (port, OTP_DEBOUNCE_TIMER_ID, OTP_DEBOUNCE_PERIOD, otp_debounce_cb);
            }
        }
    }
}


void app_otp_enable(uint8_t port)
{
    /*
     * If port is < NO_OF_TYPEC_PORTS, individual port specific data structure
     * instances are updated. Port = NO_OF_TYPEC_PORTS is used for updating
     * data structures for all ports at 1 shot. This is used during
     * initialization.
     */
    if (NO_OF_TYPEC_PORTS == port)
    {
        /* This has been called from initialization. We need to do the data
           structure initialization for all port instances. */
        for(port = TYPEC_PORT_0_IDX ; port < NO_OF_TYPEC_PORTS; port++)
        {
            app_otp_init(port);
        }
    }
    else
    {
        /* Initialization for port specific instance. */
        app_otp_init(port);
    }
}

#endif /* OTP_ENABLE */

/* End of File */

