/**
 * @file pdss_mx_hal.c
 *
 * @brief @{CCG MX-PD PHY driver module source file (CCG5, CCG3PA families).@}
 */

/*
 * Copyright (2014-2019), Cypress Semiconductor Corporation or a subsidiary of
 * Cypress Semiconductor Corporation. All rights reserved.
 *
 * This software, including source code, documentation and related materials
 * (“Software”), is owned by Cypress Semiconductor Corporation or one of its
 * subsidiaries (“Cypress”) and is protected by and subject to worldwide patent
 * protection (United States and foreign), United States copyright laws and
 * international treaty provisions. Therefore, you may use this Software only
 * as provided in the license agreement accompanying the software package from
 * which you obtained this Software (“EULA”).
 *
 * If no EULA applies, Cypress hereby grants you a personal, nonexclusive,
 * non-transferable license to copy, modify, and compile the Software source
 * code solely for use in connection with Cypress’s integrated circuit
 * products. Any reproduction, modification, translation, compilation, or
 * representation of this Software except as specified above is prohibited
 * without the express written permission of Cypress. Disclaimer: THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress reserves the
 * right to make changes to the Software without notice. Cypress does not
 * assume any liability arising out of the application or use of the Software
 * or any product or circuit described in the Software. Cypress does not
 * authorize its products for use in any products where a malfunction or
 * failure of the Cypress product may reasonably be expected to result in
 * significant property damage, injury or death (“High Risk Product”). By
 * including Cypress’s product in a High Risk Product, the manufacturer of such
 * system or application assumes all risk of such use and in doing so agrees to
 * indemnify Cypress against all liability.
 */

#include <config.h>
#include <hal_ccgx.h>
#include <pd.h>
#include <pd_protocol.h>
#include <dpm.h>
#include <dpm_intern.h>
#include <typec_manager.h>
#include <pdss_hal.h>
#include <ccgx_regs.h>
#include <status.h>
#include <gpio.h>
#include <hpd.h>
#include <timer.h>
#include <utils.h>
#include <chgb_hal.h>
#include <battery_charging.h>
#include <system.h>
#include <app.h>
#include <srom_vars.h>

/**
 * Type C voltage thresholds (in mV) as per Section 4.11.3 of Type C
 * specification Rev1.
 */
const uint8_t thresholds[4][4] =
{
    {PD_CMP_VSEL_0_2_V, PD_CMP_VSEL_1_77_V, 0, 0}, /* Rp USB default row. */
    {PD_CMP_VSEL_0_4_V, PD_CMP_VSEL_1_77_V, 0, 0}, /* Rp 1.5A row. */
    {PD_CMP_VSEL_0_8_V, PD_CMP_VSEL_2_6_V, 0, 0}, /* Rp 3A row. */
    {PD_CMP_VSEL_0_2_V, PD_CMP_VSEL_0_655_V, PD_CMP_VSEL_1_235_V, PD_CMP_VSEL_2_6_V} /* RD row. */
};

/* Ordered sets for transmission. */
const uint32_t os_table[SOP_INVALID] =
{
    0x8E318u,      /**< SOP Default. */
    0x31B18u,      /**< SOP Prime. */
    0x360D8u,      /**< SOP Double Prime. */
    0x34F98u,      /**< SOP Prime Debug. */
    0x89A78u,      /**< SOP Double Prime Debug. */
    0xE7393u,      /**< Hard Reset. */
    0xE0F8Cu       /**< Cable Reset. */
};

#define VBUS_C_20_PER_DIV                   (5)       /* 20% */
#define VBUS_C_10_PER_DIV                   (10)      /* 10% */
#define VBUS_C_8_PER_DIV                    (12)      /* APPROX 8% */

/* On CCG5, AMUX_NHV[4] enables connection of VBus divider to ADC_IN_2. */
#define AMUX_ADC_CCG5_VBUS_DIV_EN_POS       (4)

/* Selecting 8% divider for connection of VBus divider to ADC. */
#define AMUX_ADC_CCG5_VBUS_DIV_8PC_POS      (3)

/* CCG3PA enable VBUS_IN resistor divider for TYPE-C VBUS monitoring using ADC. */
#define AMUX_ADC_CCG3PA_VBUS_IN_8P_EN_POS   (7)
#define AMUX_ADC_CCG3PA_VBUS_IN_20P_EN_POS  (4)

/* CCG3PA switch to 20% divider option at the final MUX. */
#define AMUX_ADC_CCG3PA_VBUS_DIV_2OP_EN_POS (14)

/* CCG3PA discharge drive strength settings. */
#define CCG3PA_DISCHG_DS_VBUS_C_00          (1)
#define CCG3PA_DISCHG_DS_VBUS_IN_00         (1)

/* Location of SFLASH flag that indicates validity of VConn OCP trim setting. */
#define SFLASH_VCONN_TRIM_ENABLE_ADDR       (0x0FFFF400)



static uint8_t  gl_ccgx_pfet_on[NO_OF_TYPEC_PORTS] = {false};
static uint8_t  gl_ccgx_cfet_on[NO_OF_TYPEC_PORTS] = {false};

/* LSCSA measured error for 15mV Vsense location in SFLASH. */
#define LSCSA_AMP1_ERR_SIGN     (*(volatile uint8_t *)(0x0ffff2a0))
#define LSCSA_AMP1_ERR_VAL      (*(volatile uint8_t *)(0x0ffff2a1))
#define LSCSA_AMP2_ERR_SIGN     (*(volatile uint8_t *)(0x0ffff2a2))
#define LSCSA_AMP2_ERR_VAL      (*(volatile uint8_t *)(0x0ffff2a3))

/* EA_IREF_GAIN TRIM setting location in SFLASH. */
#define EA_IREF_GAIN_PDAC       (*(volatile uint8_t *)(0x0ffff2a4))
#define EA_IREF_GAIN_NDAC       (*(volatile uint8_t *)(0x0ffff2a5))

/* Gain settings */
#define LSCSA_AV_SEL_150            (0x1Cu)
#define LSCSA_AV_SEL_125            (0x18u)
#define LSCSA_AV_SEL_35             (0x03u)

/* Range of VSense supported by the LSCSA */
#define LSCSA_VSENSE_MIN            (10u)
#define LSCSA_VSENSE_MAX            (600u)
#define LSCSA_GAIN_150_VSENSE_MAX   (140u)
#define LSCSA_GAIN_35_VSENSE_MIN    (160u)

/* Maximum voltage in mV that can be measured with 20% divider. */
#define VBUS_DIV_20_PER_MAX_VOLT    (9000)

/* Current threshold in 10mA units below which we detect it as CV mode. */
#define LSCSA_CF_CUR_THRES           (5)
#define LSCSA_CF_CUR_HIGH_LIMIT      (300)
#define LSCSA_CF_CUR_HIGH_THRES      (10)

#if VBUS_OCP_ENABLE

/* VBus OCP mode. */
static uint8_t gl_vbus_ocp_mode[NO_OF_TYPEC_PORTS];

/* VBus OCP software debounce in ms. */
static uint8_t gl_ocp_sw_db_ms[NO_OF_TYPEC_PORTS];

/* PGDO type for VBUS OCP. */
bool gl_vbus_ocp_pgdo_type[NO_OF_TYPEC_PORTS];

/* AMUX Control bit to select reference voltage for OCP comparator. */
#define VBUS_OCP_AMUX_CTRL_REF_SEL_BIT_POS      (3)
#endif /* VBUS_OCP_ENABLE */

#if VBUS_OVP_ENABLE

#define AMUX_OV_VBUS_SEL_MASK           (0x00000208)
#define AMUX_OV_DIV_SEL_BIT_POS         (2)
#define CCG5_P1_OV_DIV_SEL_BIT_POS      (1)
#define CCG5_P1_UV_DIV_SEL_BIT_POS      (0)

/* OVP callback pointer storage. */
PD_ADC_CB_T gl_ovp_cb[NO_OF_TYPEC_PORTS];

/* VBus OVP mode. */
static vbus_ovp_mode_t gl_vbus_ovp_mode[NO_OF_TYPEC_PORTS];

/* PGDO type for VBUS OVP. */
bool gl_vbus_ovp_pgdo_type[NO_OF_TYPEC_PORTS];

uint32_t gl_vbus_ovp_filter_id[NO_OF_TYPEC_PORTS];

#endif /* VBUS_OVP_ENABLE */

#if VCONN_OCP_ENABLE

/* Debounce period for VConn OCP condition. */
static uint8_t     gl_vconn_ocp_debounce[NO_OF_TYPEC_PORTS];

/* Callback to be invoked when VConn OCP is detected. */
static PD_ADC_CB_T gl_vconn_ocp_cb[NO_OF_TYPEC_PORTS];

/* CC channel on which VConn has been applied. */
static uint8_t     gl_vconn_channel[NO_OF_TYPEC_PORTS];

#endif /* VCONN_OCP_ENABLE */

#if VBUS_UVP_ENABLE

#define AMUX_UV_VBUS_SEL_MASK           (0x00000044)
#define AMUX_UV_DIV_SEL_BIT_POS         (12)

/* VBus UVP mode. */
static vbus_uvp_mode_t gl_vbus_uvp_mode;

/* UVP callback pointer storage. */
PD_ADC_CB_T gl_uvp_cb;

/* PGDO type for VBUS UVP. */
bool gl_vbus_uvp_pgdo_type;

#endif /* VBUS_UVP_ENABLE */


/* Callback used for notification of CC/SBU over-voltage conditions. */
PD_ADC_CB_T gl_ccg_fault_cb = NULL;

#if CCGX_V5V_CHANGE_DETECT
/* Status variable that stores the live status of V5V supply for each port. */
static volatile bool ccg5_v5v_supply_present[NO_OF_TYPEC_PORTS] = {
    true
#if CCG_PD_DUALPORT_ENABLE
    ,
    true
#endif /* CCG_PD_DUALPORT_ENABLE */
};
#endif /* CCGX_V5V_CHANGE_DETECT */


/* Callback used for notification of any input supply change. */
pd_supply_change_cbk_t gl_ccg_supply_changed_cb = NULL;

/**
 * @struct pdss_status_t
 * @brief Structure to hold PDSS IP status.
 */
typedef struct
{
    /** PD phy callback. */
    pd_phy_cbk_t pd_phy_cbk;

    /** The received PD packet. */
    pd_packet_extd_t rx_pkt;

    /** The tx data pointer. */
    uint32_t* tx_dat_ptr;

    /** ADC block variables. */
    volatile bool     adc_ref_vddd[PD_ADC_NUM_ADC];
    volatile uint16_t adc_vddd_mv[PD_ADC_NUM_ADC];

    /** ADC callback. */
    PD_ADC_CB_T adc_cb[PD_ADC_NUM_ADC];

    /** The tx data count. */
    uint8_t tx_dobj_count;

    /** The tx data pointer. */
    uint8_t volatile tx_obj_sent;

    /* Holds current transmission is unchunked or not */
    uint8_t volatile tx_unchunked;

    /** Holds retry count. */
    int8_t volatile retry_cnt;

    /**
     * Flag to indicate a message has been transmitted and we're waiting for
     * GoodCRC.
     */
    uint8_t volatile tx_done;

    /**
     * Flag to indicate currently received message is unchunked extended message
     */
    bool volatile rx_unchunked;

    /**
     * Length of currently being received extended unchunked messages in 32 bits units
     */
    uint8_t volatile rx_unchunk_len;

    /**
     * Count in 32 bits units of no of words read from rx memory for extended unchunked
     * message.
     */
    uint8_t volatile rx_unchunk_count;

    /**
     * Read memory location where the HAL should read the next portion of data from.
     */
    uint8_t volatile rx_read_location;

#if BATTERY_CHARGING_ENABLE
    /** BC phy callback. */
    bc_phy_cbk_t bc_phy_cbk;


#endif /* BATTERY_CHARGING_ENABLE */



    /** Auto toggle enable from stack. */
    uint8_t volatile auto_toggle_en;

    /** Auto toggle active state. */
    uint8_t volatile auto_toggle_act;

    /** Type-C state machine re-enable pending. */
    uint8_t volatile typec_start_pending;

    /** OVP fault pending on CC line. */
    uint8_t volatile cc_ovp_pending;

} pdss_status_t;

/** Pointer array for HW IP register structure. */
static PPDSS_REGS_T gl_pdss[NO_OF_TYPEC_PORTS] =
{
    PDSS0
#if CCG_PD_DUALPORT_ENABLE
    ,
    PDSS1
#endif /* CCG_PD_DUALPORT_ENABLE */
};



/** PDSS status. */
static pdss_status_t gl_pdss_status[NO_OF_TYPEC_PORTS];

void pdss_intr0_handler(uint8_t port);
CY_ISR_PROTO(pdss_port0_intr0_handler);

void pdss_intr1_handler(uint8_t port);
CY_ISR_PROTO(pdss_port0_intr1_handler);

#if CCG_PD_DUALPORT_ENABLE
CY_ISR_PROTO(pdss_port1_intr0_handler);
CY_ISR_PROTO(pdss_port1_intr1_handler);
#endif /* CCG_PD_DUALPORT_ENABLE */

/* HPD transmit enable per PD port. */
#if (CCG_PD_DUALPORT_ENABLE == 0)
    static bool hpd_transmit_enable[NO_OF_TYPEC_PORTS] =
#else
    static bool hpd_transmit_enable[2] =
#endif /* (CCG_PD_DUALPORT_ENABLE == 0) */
{
    false
#if CCG_PD_DUALPORT_ENABLE
        ,
    false
#endif /* CCG_PD_DUALPORT_ENABLE */
};

/* HPD receive enable per PD port. */
#if (CCG_PD_DUALPORT_ENABLE == 0)
    static bool hpd_receive_enable[NO_OF_TYPEC_PORTS] =
#else
    static bool hpd_receive_enable[2] =
#endif /* (CCG_PD_DUALPORT_ENABLE == 0) */
{
    false
#if CCG_PD_DUALPORT_ENABLE
        ,
    false
#endif
};

/* HPD event callback per PD port. */
#if (CCG_PD_DUALPORT_ENABLE == 0)
    static hpd_event_cbk_t hpd_cbks[NO_OF_TYPEC_PORTS] =
#else
    static hpd_event_cbk_t hpd_cbks[2] =
#endif /* (CCG_PD_DUALPORT_ENABLE == 0) */
{
    NULL
#if CCG_PD_DUALPORT_ENABLE
        ,
    NULL
#endif /* CCG_PD_DUALPORT_ENABLE */
};

/* Configuration provided from solution. */
static PD_ADC_INPUT_T   pd_vbus_detach_adc_input    = PD_ADC_INPUT_AMUX_A;
static PD_ADC_ID_T      pd_vbus_detach_adc_id       = PD_ADC_ID_1;

static bool             pd_vbus_mon_internal        = false;

#define VBUS_MON_DIV_20P_VAL                    (10u)   /* Multiplied by 2. */
#define VBUS_MON_DIV_8P_VAL                     (25u)   /* Multiplied by 2. */

static uint8_t          pd_vbus_mon_divider         = VBUS_MON_DIV_8P_VAL;

typedef enum
{
    SWAPR_SRC_ADC1,             /* 0 */
    SWAPR_SRC_ADC2,
    SWAPR_SRC_VBUS_MON,
    SWAPR_SRC_VSYS_DET,         /* 3 - Only for port 0. */
    SWAPR_SRC_UV = 5,
    SWAPR_SRC_OV,
    SWAPR_SRC_OCP = 9
} swapr_src_t;

/* The FRS comparator threshold should be set to 0.52V = 2. */
#define CMP_FS_VSEL_VALUE       (2)

/*
 * Swap CTRL default settings for FRS receive. This settings are based on 5Mhz clock
 * to the block.
 */
#define FRS_RX_SWAP_CTRL1_DFLT_VAL      ((175u << PDSS_SWAP_CTRL1_PULSE_MIN_POS)| \
                                         (650u << PDSS_SWAP_CTRL1_PULSE_MAX_POS)|\
                                         (PDSS_SWAP_CTRL1_RESET_SWAP_STATE))

#define FRS_RX_SWAP_CTRL2_DFLT_VAL      ((50u << PDSS_SWAP_CTRL2_GLITCH_WIDTH_LOW_POS) | \
                                         (1u << PDSS_SWAP_CTRL2_GLITCH_WIDTH_HIGH_POS))

#define FRS_RX_SWAP_CTRL3_DFLT_VAL      (160u << PDSS_SWAP_CTRL3_STABLE_LOW_POS)

#define FRS_RX_SWAP_CTRL5_DFLT_VAL      (750u << PDSS_SWAP_CTRL5_LONG_LOW_POS)

/* AUTO_MODE control mask for PGDO_1_CFG and PGDO_PU_1_CFG registers. */
#define PGDO_1_CFG_AUTO_SEL_MASK       (PDSS_PGDO_1_CFG_SEL_CSA_OC |\
                                        PDSS_PGDO_1_CFG_SEL_SWAP_VBUS_LESS_5_MASK |\
                                        PDSS_PGDO_1_CFG_SEL_FILT2_MASK |\
                                        PDSS_PGDO_1_CFG_SEL_CC1_OCP |\
                                        PDSS_PGDO_1_CFG_SEL_CC2_OCP |\
                                        PDSS_PGDO_1_CFG_SEL_CC1_OVP |\
                                        PDSS_PGDO_1_CFG_SEL_CC2_OVP |\
                                        PDSS_PGDO_1_CFG_SEL_SBU1_OVP_MASK |\
                                        PDSS_PGDO_1_CFG_SEL_SBU2_OVP_MASK)

#define PGDO_PU_1_CFG_AUTO_SEL_MASK     (PGDO_1_CFG_AUTO_SEL_MASK)


/*
 * Trim bits for CC Pull-up current source
 * Firmware must read SFlash and set this value for each Rp value
 *
 * 0FFF_F536 : Port 0 - Default
 * 0FFF_F537 : Port 0 - 1p5
 * 0FFF_F538 : Port 0 - 3p0
 * 0FFF_F542 : Port 1 - Default
 * 0FFF_F543 : Port 1 - 1p5
 * 0FFF_F544 : Port 1 - 3p0
 */
#define SFLASH_PDSS_PORT0_TRIM1_BASE_REV1       (0x0FFFF536u)
#define SFLASH_PDSS_PORT1_TRIM1_BASE_REV1       (0x0FFFF542u)

static const uint8_t *pdss_rp_trim_db_0 = (const uint8_t *)SFLASH_PDSS_PORT0_TRIM1_BASE_REV1;
#if CCG_PD_DUALPORT_ENABLE
static const uint8_t *pdss_rp_trim_db_1 = (const uint8_t *)SFLASH_PDSS_PORT1_TRIM1_BASE_REV1;
#endif /* CCG_PD_DUALPORT_ENABLE */





uint32_t ccg_get_vsys_status(uint8_t port)
{
    return gl_pdss[port]->vreg_vsys_ctrl;
}

/* This control is only supported on CCG5, CCG5C and CCG6. */
void pd_hal_set_cc_ovp_pending(uint8_t port)
{
    gl_pdss_status[port].cc_ovp_pending = true;
}


/* This function measures the current voltage on the VBus-in. */
uint16_t pd_hal_measure_vbus_in(uint8_t port)
{
    uint8_t state;
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t level;
    uint16_t retval;

    state = CyEnterCriticalSection();

/* Select VBUS_IN for ADC. VBUS_C in case of flipped FET control */
    pd->amux_nhv_ctrl |= ((1 << AMUX_ADC_CCG3PA_VBUS_IN_8P_EN_POS) |
        (1 << AMUX_ADC_CCG3PA_VBUS_IN_20P_EN_POS));
    CyDelayUs(20);

    /* Sample the VBus voltage using ADC. */
    level = pd_adc_sample(port, APP_VBUS_POLL_ADC_ID, APP_VBUS_POLL_ADC_INPUT);
    retval = pd_adc_get_vbus_voltage(port, APP_VBUS_POLL_ADC_ID, level);

/* Deselect VBUS_IN for ADC. VBUS_C in case of flipped FET control */
    pd->amux_nhv_ctrl &= ~((1 << AMUX_ADC_CCG3PA_VBUS_IN_8P_EN_POS) |
        (1 << AMUX_ADC_CCG3PA_VBUS_IN_20P_EN_POS));
    CyDelayUs(20);

    CyExitCriticalSection(state);
    return retval;
}

/* This function measures the current voltage on the VBus. */
uint16_t pd_hal_measure_vbus(uint8_t port)
{
    /* Sample the VBus voltage using ADC. */
    uint8_t level;
    uint16_t retval;

    pd_adc_calibrate (port, APP_VBUS_POLL_ADC_ID);
    level = pd_adc_sample(port, APP_VBUS_POLL_ADC_ID, APP_VBUS_POLL_ADC_INPUT);
    retval = pd_adc_get_vbus_voltage(port, APP_VBUS_POLL_ADC_ID, level);


    return retval;
}

/* Sample the VBus current using ADC. */
uint16_t pd_hal_measure_vbus_cur(uint8_t port)
{
    uint16_t current = 0;



    return current;
}

void pd_hal_config_auto_toggle(uint8_t port, bool enable)
{
#if CCG_HW_DRP_TOGGLE_ENABLE
    /* Abort auto toggle if it is in progress. */
    pd_hal_abort_auto_toggle(port);
    gl_pdss_status[port].auto_toggle_en = enable;
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */
}

bool pd_hal_is_auto_toggle_active(uint8_t port)
{
#if CCG_HW_DRP_TOGGLE_ENABLE
    /* Don't run through Type-C state machine if auto toggle is active or has just been stopped. */
    return (((bool)gl_pdss_status[port].auto_toggle_act) || ((bool)gl_pdss_status[port].typec_start_pending));
#else
    return false;
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */
}

void pd_hal_abort_auto_toggle(uint8_t port)
{
    (void)port;
#if CCG_HW_DRP_TOGGLE_ENABLE
    PPDSS_REGS_T pd = gl_pdss[port];

    if (gl_pdss_status[port].auto_toggle_act)
    {
        /* Disable the RP-RD toggle and the attach interrupt. */
        pd->rp_rd_cfg1 &= ~(PDSS_RP_RD_CFG1_HW_RP_RD_AUTO_TOGGLE | PDSS_RP_RD_CFG1_START_TOGGLE);
        pd->intr1_mask &= ~PDSS_INTR1_DRP_ATTACHED_DETECTED;

        gl_pdss_status[port].auto_toggle_act     = false;
        gl_pdss_status[port].typec_start_pending = false;
    }
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */
}

PD_ADC_ID_T pd_hal_get_vbus_detach_adc(void)
{
    return pd_vbus_detach_adc_id;
}

PD_ADC_INPUT_T pd_hal_get_vbus_detach_input(void)
{
    return pd_vbus_detach_adc_input;
}

void pd_hal_set_vbus_detach_params(PD_ADC_ID_T adc_id, PD_ADC_INPUT_T adc_inp)
{
    pd_vbus_detach_adc_input = adc_inp;
    pd_vbus_detach_adc_id    = adc_id;
}

void pd_hal_set_vbus_mon_divider(uint8_t divider)
{
    pd_vbus_mon_divider = divider;
}

void pd_hal_enable_internal_vbus_mon(bool enable)
{
    pd_vbus_mon_internal = enable;
}

void pd_hal_set_fet_drive(pd_fet_dr_t pctrl_drive, pd_fet_dr_t cctrl_drive)
{
    (void)pctrl_drive;
    (void)cctrl_drive;
}

void pd_hal_dual_fet_config(bool dual_fet, uint8_t spacing)
{
    (void)dual_fet;
    (void)spacing;
}

/* Function definitions. */

CY_ISR(pdss_port0_intr0_handler)
{
    pdss_intr0_handler(TYPEC_PORT_0_IDX);
}

CY_ISR(pdss_port0_intr1_handler)
{
    pdss_intr1_handler(TYPEC_PORT_0_IDX);
}

#if CCG_PD_DUALPORT_ENABLE
CY_ISR(pdss_port1_intr0_handler)
{
    pdss_intr0_handler(TYPEC_PORT_1_IDX);
}

CY_ISR(pdss_port1_intr1_handler)
{
    pdss_intr1_handler(TYPEC_PORT_1_IDX);
}
#endif /* CCG_PD_DUALPORT_ENABLE */


#if CCG_PD_DUALPORT_ENABLE

/* Firmware has to copy trims for second PD block from SFLASH to registers. */

/* MMIO address of PD block trim registers. */
#define CCG5_USBPD1_MMIO_TRIM_ADDR   (0x400bff00)

/* Number of trim registers to be initialized. */
#define CCG5_USBPD_TRIM_REG_CNT      (29u)

/* SFLASH address where the trims are stored. Skip the count and address. */
#define CCG5_SFLASH_PD1_TRIM_ADDR    (0x0FFFF502)

static void pd_hal_init_ccg5_pd1_trims (void)
{
    uint32_t *trim_mmio_p   = (uint32_t *)CCG5_USBPD1_MMIO_TRIM_ADDR;
    uint8_t  *trim_sflash_p = (uint8_t *)CCG5_SFLASH_PD1_TRIM_ADDR;
    uint8_t   val, cnt;

    /* Read the trim values from SFLASH and copy into MMIO registers.
       Each register occupies one byte in SFLASH, but 4 bytes in MMIO.
     */
    for (cnt = 0; cnt < CCG5_USBPD_TRIM_REG_CNT; cnt++)
    {
        val = *trim_sflash_p;
        *trim_mmio_p = (uint32_t)val;

        trim_sflash_p++;
        trim_mmio_p++;
    }
}
#endif /* CCG_PD_DUALPORT_ENABLE */

/* Function to update a register field with a new value. */
static uint32_t pd_hal_mmio_reg_update_field(uint32_t origval, uint32_t fld, uint32_t mask, uint8_t pos)
{
    return ((origval & ~mask) | (fld << pos));
}

/* Function to register an ISR and enable the corresponding IRQ. */
static void pd_hal_init_intr (uint8_t intr_no, cyisraddress isr_p)
{
    CyIntDisable (intr_no);
    CyIntSetVector (intr_no, isr_p);
    CyIntEnable (intr_no);
}

ccg_status_t pd_hal_init(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (port == TYPEC_PORT_0_IDX)
    {
        /* Register sync interrupt handler. */
        pd_hal_init_intr (PD_PORT0_INTR0, &pdss_port0_intr0_handler);

        /* Register ganged interrupt handler. */
        pd_hal_init_intr (PD_PORT0_INTR1, &pdss_port0_intr1_handler);
    }
#if CCG_PD_DUALPORT_ENABLE
    else
    {
        /* Register sync interrupt handler. */
        pd_hal_init_intr (PD_PORT1_INTR0, &pdss_port1_intr0_handler);

        /* Register ganged interrupt handler. */
        pd_hal_init_intr (PD_PORT1_INTR1, &pdss_port1_intr1_handler);
    }
#endif /* CCG_PD_DUALPORT_ENABLE */

    /* Enable the PD block. */
    pd->ctrl |= PDSS_CTRL_IP_ENABLED;

    /* Power up the block. */
    pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_PWR_DISABLE;

    /* Turn off PHY deepsleep. References require 100us to stabilize. */
    pd->dpslp_ref_ctrl &= ~PDSS_DPSLP_REF_CTRL_PD_DPSLP;

    /*
     * Enable deep-sleep current reference outputs.
     */
    pd->dpslp_ref_ctrl |= PDSS_DPSLP_REF_CTRL_IGEN_EN;
    CyDelayUs(100);

    /*
     * CCG5/CCG5C/CCG6:
     * The Deep Sleep voltage reference is used as input to the refgen block at all times.
     */
    pd->refgen_0_ctrl &= ~PDSS_REFGEN_0_CTRL_REFGEN_PD;
    pd->refgen_1_ctrl  = 0x1C143616; /* SEL0=0x16(420 mV), SEL1=0x36(740 mV), SEL2=0x14(400 mV), SEL3=0x1C(480 mV) */
    pd->refgen_2_ctrl  = 0x003D6B5F; /* SEL4=0x5F(1.15 V), SEL5=0x6B(1.27 V), SEL6=0x3D(810 mV), SEL7=0x00(200 mV) */
    pd->refgen_3_ctrl  = 0x00003D14; /* SEL8=0x14(400 mV), SEL9=0x3D(810 mV), SEL10=0x00(200 mV) */
    pd->refgen_4_ctrl  = 0x00000900; /* SEL11=0x00(450 mV), SEL12=0x00(650 mV), SEL13=0x04(2.0 V), SEL14=0x04(1.12 V) */

    /* Give some delay for references to settle. */
    CyDelayUs (50);

    /* Enable the VSYS_DET comparator. Corresponding LF filter also needs to be enabled.
       Look for both positive and negative edge interrupts.
     */
    if (port == 0)
    {
        /* CDT 275510: Convert 5V pump trims from 8 bit to 9 bit. */
        PDSS_TRIMS0->trim_5vpump1_0 = (PDSS_TRIMS0->trim_5vpump1_0 & 0x3F) | ((PDSS_TRIMS0->trim_5vpump1_0 & 0xC0) << 1);
        PDSS_TRIMS0->trim_5vpump2_0 = (PDSS_TRIMS0->trim_5vpump2_0 & 0x3F) | ((PDSS_TRIMS0->trim_5vpump2_0 & 0xC0) << 1);
        PDSS_TRIMS0->trim_5vpump3_0 = (PDSS_TRIMS0->trim_5vpump3_0 & 0x3F) | ((PDSS_TRIMS0->trim_5vpump3_0 & 0xC0) << 1);

        /* Update the trims for VConn OCP to increase the current limit to the maximum. */
        PDSS_TRIMS0->trim_vconn20_2 = pd_hal_mmio_reg_update_field (PDSS_TRIMS0->trim_vconn20_2, 0x01, 0x0C, 0x02);

        /* Enable interrupt on either positive or negative edge from the VSYS_DET comparator. */
        pd->comp_ctrl[COMP_ID_VSYS_DET] |= PDSS_COMP_CTRL_COMP_ISO_N;
        pd->comp_ctrl[COMP_ID_VSYS_DET] &= ~PDSS_COMP_CTRL_COMP_PD;
        pd->intr7_filter_cfg[1] = PDSS_INTR7_FILTER_CFG_FILT_EN | PDSS_INTR7_FILTER_CFG_CLK_LF_FILT_RESET |
            (6 << PDSS_INTR7_FILTER_CFG_CLK_LF_FILT_SEL_POS) |
            (FILTER_CFG_POS_EN_NEG_EN << PDSS_INTR7_FILTER_CFG_FILT_CFG_POS);


        /* Wait for some time and check VSYS status. */
        CyDelay (1);
        if ((pd->intr7_status & (2 << PDSS_INTR7_STATUS_FILT_8_POS)) == 0)
        {
            /* Notify application layer about absence of VSYS supply. */
            if (gl_ccg_supply_changed_cb != NULL)
            {
                gl_ccg_supply_changed_cb (port, CCG_SUPPLY_VSYS, false);
            }
            CyDelay (1);

            /* VSYS is not present, disable VSYS switch. */
            pd->vreg_vsys_ctrl &= ~PDSS_VREG_VSYS_CTRL_ENABLE_VDDD_SWITCH;
        }
        else
        {
            /* Notify application about presence of VSYS supply. */
            if (gl_ccg_supply_changed_cb != NULL)
            {
                gl_ccg_supply_changed_cb (port, CCG_SUPPLY_VSYS, true);
            }
        }

        /* Enable interrupt for VSYS detection. */
        pd->intr7_mask |= (2 << PDSS_INTR7_CLK_LF_EDGE_CHANGED_POS);
    }
#if CCG_PD_DUALPORT_ENABLE
    else
    {
        pd_hal_init_ccg5_pd1_trims();

        /* CDT 275510: Convert 5V pump trims from 8 bit to 9 bit. */
        PDSS_TRIMS1->trim_5vpump1_0 = (PDSS_TRIMS1->trim_5vpump1_0 & 0x3F) | ((PDSS_TRIMS1->trim_5vpump1_0 & 0xC0) << 1);
        PDSS_TRIMS1->trim_5vpump2_0 = (PDSS_TRIMS1->trim_5vpump2_0 & 0x3F) | ((PDSS_TRIMS1->trim_5vpump2_0 & 0xC0) << 1);

        /* Update the trims for VConn OCP to increase the current limit to the maximum. */
        PDSS_TRIMS1->trim_vconn20_2 = pd_hal_mmio_reg_update_field (PDSS_TRIMS1->trim_vconn20_2, 0x01, 0x0C, 0x02);
    }
#endif /* CCG_PD_DUALPORT_ENABLE */


    /* Enable HF Clk as source for Fault protection filters. */
    pd->ctrl |= PDSS_CTRL_SEL_CLK_FILTER;


    /* For CCG5, amux_nhv[4]/amux_nhv[3] should be set for proper connection.
       amux_nhv[3]/amux_nhv[2] is used to select 8% divider instead of 10% divider.
     */
    pd->amux_nhv_ctrl |= (3 << (AMUX_ADC_CCG5_VBUS_DIV_8PC_POS - port));

    /*
     * Connect 10% of VBUS_C to VBUS_MON comparator input. This has to be done at start to prevent errors on
     * the pct10 feedback lines.
     */
    pd->amux_denfet_ctrl |= PDSS_AMUX_DENFET_CTRL_SEL;

    /* Initialize ADCs. */
    pd_adc_init(port, PD_ADC_ID_0);



    return CCG_STAT_SUCCESS;
}

void pd_hal_cleanup(uint8_t port)
{
    (void)port;
}

void pd_phy_vbus_detach_cbk(uint8_t port, bool comp_out)
{
    /* Do nothing. */
}

/* Function to register callbacks for input supply change. */
void pd_hal_set_supply_change_evt_cb(pd_supply_change_cbk_t cb)
{
    gl_ccg_supply_changed_cb = cb;
}



/* Function to register callbacks for CC/SBU fault conditions. */
void ccg_set_fault_cb(PD_ADC_CB_T cb)
{
    gl_ccg_fault_cb = cb;
}

/* Helper function to disable pump on CCG5 device. */
static void ccg5_pump_disable(uint8_t port, uint8_t index)
{
    gl_pdss[port]->pump5v_ctrl[index] |= PDSS_PUMP5V_CTRL_PUMP5V_BYPASS_LV;
    CyDelayUs (10);
    gl_pdss[port]->pump5v_ctrl[index]  = PDSS_PUMP5V_CTRL_DEFAULT;
}

/* Helper function to enable pump on CCG5 device. */
static void ccg5_pump_enable(uint8_t port, uint8_t index)
{
    /* Enable the pump only if it is not already on. */
    if ((gl_pdss[port]->pump5v_ctrl[index] & PDSS_PUMP5V_CTRL_PUMP5V_PUMP_EN) == 0)
    {
        gl_pdss[port]->pump5v_ctrl[index] = PDSS_PUMP5V_CTRL_PUMP5V_PUMP_EN | PDSS_PUMP5V_CTRL_PUMP5V_BYPASS_LV;
        CyDelayUs (10);
        gl_pdss[port]->pump5v_ctrl[index] = PDSS_PUMP5V_CTRL_PUMP5V_PUMP_EN;
        CyDelayUs (40);
        gl_pdss[port]->pump5v_ctrl[index] = PDSS_PUMP5V_CTRL_PUMP5V_PUMP_EN | PDSS_PUMP5V_CTRL_PUMP5V_DEL_PUMP_EN;
    }
}

void pd_phy_detect_cc_rise(uint8_t port, bool rp_connected)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    const dpm_status_t *dpm_stat = dpm_get_info(port);

    /* Connect UP comparator to CC1 and down comparator to CC2 */
    pd->cc_ctrl_0 = PDSS_CC_CTRL_0_CMP_DN_CC1V2 |
        (pd->cc_ctrl_0 &
         ~(PDSS_CC_CTRL_0_CMP_UP_CC1V2 | PDSS_CC_CTRL_0_CMP_UP_VSEL_MASK | PDSS_CC_CTRL_0_CMP_DN_VSEL_MASK));

    /* Set the comparator voltage references based on the active Rp level applied by us. */
    if (rp_connected)
    {
        pd->cc_ctrl_0 |= ((thresholds[dpm_stat->src_cur_level_live][0]) << PDSS_CC_CTRL_0_CMP_UP_VSEL_POS) |
            ((thresholds[dpm_stat->src_cur_level_live][0]) << PDSS_CC_CTRL_0_CMP_DN_VSEL_POS);
    }

    pd->intr1_cfg_vcmp_up_down_ls &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_CFG_MASK |
            PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN |
            PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_BYPASS |
            PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_CFG_MASK |
            PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN |
            PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_BYPASS);
    pd->intr1_cfg_vcmp_up_down_ls |= (((PD_ADC_INT_RISING) << PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_CFG_POS) |
            ((PD_ADC_INT_RISING) << PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_CFG_POS) |
            (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN | PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN));

    CyDelayUs(10);
    pd->intr1 = (PDSS_INTR1_VCMP_UP_CHANGED | PDSS_INTR1_VCMP_DN_CHANGED | PDSS_INTR1_VCMP_LA_CHANGED);
    pd->intr1_mask |= (PDSS_INTR1_VCMP_UP_CHANGED | PDSS_INTR1_VCMP_DN_CHANGED);

    /* If comparators have already triggered, then set the interrupts and return. */
    if (pd->intr1_status & (PDSS_INTR1_STATUS_VCMP_UP_STATUS | PDSS_INTR1_STATUS_VCMP_DN_STATUS))
    {
        pd->intr1_set |= PDSS_INTR1_VCMP_UP_CHANGED;
    }
}

bool pd_phy_deepsleep(uint8_t port)
{
#if SYS_DEEPSLEEP_ENABLE
    dpm_status_t* dpm_stat = dpm_get_status(port);
    PPDSS_REGS_T pd = gl_pdss[port];
#if (!(CCG_SOURCE_ONLY))
    uint8_t level;
#endif /* (!(CCG_SOURCE_ONLY)) */
    uint32_t volatile status;
    uint32_t regval;

    if (!(dpm_stat->dpm_enabled))
    {
        return true;
    }

    if (dpm_stat->connect == true)
    {
        /* Set LA comparator for wakeup. */
        pd->intr1 = PDSS_INTR1_VCMP_LA_CHANGED;
        pd->intr1_mask |= PDSS_INTR1_VCMP_LA_CHANGED;

        regval = pd->intr1_cfg_vcmp_up_down_ls;

        if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
        {
            if (dpm_stat->attached_dev == DEV_AUD_ACC)
            {
                pd_phy_detect_cc_rise (port, true);
            }
            else
            {
                regval &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_CFG_MASK |
                        PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN);
                regval |= (PD_ADC_INT_RISING) << PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_CFG_POS;
                pd->intr1_cfg_vcmp_up_down_ls = regval;

                pd->intr1 = PDSS_INTR1_VCMP_UP_CHANGED;
                pd->intr1_mask |= PDSS_INTR1_VCMP_UP_CHANGED;

                /* If the comparator has already triggered, set the interrupt and return. */
                if (pd->intr1_status & PDSS_INTR1_STATUS_VCMP_UP_STATUS)
                {
                    pd->intr1_set |= PDSS_INTR1_VCMP_UP_CHANGED;
                }
            }
        }
        else
        {
#if (!(CCG_SOURCE_ONLY))
            regval &= ~ (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN);
            /* Set up/down for both edges */
            regval |=  (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_CFG_MASK |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_CFG_MASK);
            pd->intr1_cfg_vcmp_up_down_ls = regval;

            pd->intr1 = PDSS_INTR1_VCMP_UP_CHANGED | PDSS_INTR1_VCMP_DN_CHANGED;
            pd->intr1_mask |= PDSS_INTR1_VCMP_UP_CHANGED | PDSS_INTR1_VCMP_DN_CHANGED;

            /* Check old cc status if diffrent then */
            if(dpm_stat->cc_old_status.state != pd_typec_get_cc_status(port).state)
            {
                /* Fire anyone interrupt to wakeup */
                pd->intr1_set |= PDSS_INTR1_VCMP_UP_CHANGED;
                return true;
            }

#if CCG_PD_REV3_ENABLE
            if(dpm_stat->fr_rx_en_live == false)
#endif /* CCG_PD_REV3_ENABLE */
            {
                /* Set the VBus detach comparator as per current detach threshold. */
                level = pd_get_vbus_adc_level(port, pd_vbus_detach_adc_id,
                        dpm_get_sink_detach_voltage(port), dpm_get_sink_detach_margin(port));

                /*
                 * The following call will also check if the comparator has
                 * triggered and set the interrupt.
                 */
                pd_adc_comparator_ctrl(port, pd_vbus_detach_adc_id, pd_vbus_detach_adc_input,
                        level, PD_ADC_INT_RISING, pd_phy_vbus_detach_cbk);
            }
#endif /* (!(CCG_SOURCE_ONLY)) */
        }
    }
    else
    {
        uint8_t cc1_edge = PD_ADC_INT_RISING;
        uint8_t cc2_edge = PD_ADC_INT_RISING;

#if CCG_HW_DRP_TOGGLE_ENABLE
        /* Don't do anything if auto toggle is already running. */
        if (gl_pdss_status[port].auto_toggle_act)
        {
            return true;
        }
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */

        /* Connect UP comparator to CC1 and down comparator to CC2 */
        pd->cc_ctrl_0 = ((pd->cc_ctrl_0 & ~PDSS_CC_CTRL_0_CMP_UP_CC1V2) |
                PDSS_CC_CTRL_0_CMP_DN_CC1V2);

        if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
        {
            /*
             * If Ra is present on only 1 CC line, then set the Up comparator
             * on the Ra line for a rising edge as per the Rp level. Check if
             * the comparator has already triggered, then set the interrupt and
             * return.
             *
             * Set the Dn comparator on the other line for a falling edge as
             * per the Rp level. Check if the comparator has already triggered,
             * then set the interrupt and return.
             *
             * Otherwise,
             *
             * Set the Up comparator on CC1 for a falling edge as per the Rp
             * level. Set the Dn comparator on CC2 for a falling edge as per
             * the Rp level. If the comparators have already triggered, then
             * set the respective interrupt and return.
             */

            /* Set threshold to Ra level to check if Ra is present on single CC line. */
            pd->cc_ctrl_0 &= ~(PDSS_CC_CTRL_0_CMP_UP_VSEL_MASK | PDSS_CC_CTRL_0_CMP_DN_VSEL_MASK);
            pd->cc_ctrl_0 |= ((thresholds[dpm_stat->src_cur_level_live][0]) << PDSS_CC_CTRL_0_CMP_UP_VSEL_POS) |
                ((thresholds[dpm_stat->src_cur_level_live][0]) << PDSS_CC_CTRL_0_CMP_DN_VSEL_POS);
            CyDelayUs(10);

            status = pd->intr1_status;

            /* Apply resistor based Rp and remove current source Rp */
            pd->cc_ctrl_1 |= PDSS_CC_CTRL_1_DS_ATTACH_DET_EN;
            pd->cc_ctrl_0 &= ~(PDSS_CC_CTRL_0_RP_CC1_EN | PDSS_CC_CTRL_0_RP_CC2_EN);

            if ((status & (PDSS_INTR1_STATUS_VCMP_UP_STATUS | PDSS_INTR1_STATUS_VCMP_DN_STATUS))
                    == PDSS_INTR1_STATUS_VCMP_DN_STATUS)
            {
                cc1_edge = PD_ADC_INT_FALLING;
            }
            else if ((status & (PDSS_INTR1_STATUS_VCMP_UP_STATUS | PDSS_INTR1_STATUS_VCMP_DN_STATUS))
                    == PDSS_INTR1_STATUS_VCMP_UP_STATUS)
            {
                cc2_edge = PD_ADC_INT_FALLING;
            }
            CyDelayUs(10);

            /* Configure and enable the CC1/CC2 detect filter. */
            pd->intr1_cfg_cc1_cc2_ls &= ~ (PDSS_INTR1_CFG_CC1_CC2_LS_CC1_CFG_MASK |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_CFG_MASK |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_BYPASS |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_BYPASS);
            pd->intr1_cfg_cc1_cc2_ls |= (((cc1_edge) << PDSS_INTR1_CFG_CC1_CC2_LS_CC1_CFG_POS) |
                        ((cc2_edge) << PDSS_INTR1_CFG_CC1_CC2_LS_CC2_CFG_POS) |
                    (PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN | PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN));

            pd->intr1 = (PDSS_INTR1_VCMP_UP_CHANGED |
                    PDSS_INTR1_VCMP_DN_CHANGED |
                    PDSS_INTR1_VCMP_LA_CHANGED |
                    PDSS_INTR1_CC1_CHANGED |
                    PDSS_INTR1_CC2_CHANGED);
            pd->intr1_mask |= (PDSS_INTR1_CC1_CHANGED | PDSS_INTR1_CC2_CHANGED);
            status = pd->intr1_status;

            /* If the comparators have  already triggered, then set the interrupts and return. */
            if(((cc1_edge == PD_ADC_INT_RISING) && ((status & PDSS_INTR1_STATUS_CC1_STATUS) != 0)) ||
                    ((cc1_edge == PD_ADC_INT_FALLING) && ((status & PDSS_INTR1_STATUS_CC1_STATUS) == 0)) ||
                    ((cc2_edge == PD_ADC_INT_RISING) && ((status & PDSS_INTR1_STATUS_CC2_STATUS) != 0)) ||
                    ((cc2_edge == PD_ADC_INT_FALLING) && ((status & PDSS_INTR1_STATUS_CC2_STATUS) == 0)))
            {
                /* Fire anyone to wakeup*/
                pd->intr1_set |= PDSS_INTR1_CC1_CHANGED;
                return true;
            }
        }
        else
        {
            pd_phy_detect_cc_rise (port, false);

            /* Auto toggle cannot be started in Unattached.SNK state. */
            return true;
        }

#if CCG_HW_DRP_TOGGLE_ENABLE
        /* We can only use auto toggle when we don't already have an Ra connected. */
        if(
                (dpm_stat->toggle == true) &&
                (gl_pdss_status[port].auto_toggle_en != 0) &&
                ((cc1_edge == PD_ADC_INT_RISING) && (cc2_edge == PD_ADC_INT_RISING))
          )
        {
            /* Halt Type-C state machine. */
            timer_stop(port, TYPEC_GENERIC_TIMER1);
            dpm_stat->typec_evt &= ~TYPEC_EVT_TIMEOUT1;

            /* Make sure trimmed Rp/Rd are disabled. */
            pd->cc_ctrl_0 &= 0xFC300000;

            pd->intr1_mask &= ~(PDSS_INTR1_VCMP_UP_CHANGED |
                    PDSS_INTR1_VCMP_DN_CHANGED |
                    PDSS_INTR1_CC1_CHANGED |
                    PDSS_INTR1_CC2_CHANGED |
                    PDSS_INTR1_VCMP_LA_CHANGED);
            pd->intr1 = (PDSS_INTR1_VCMP_UP_CHANGED |
                    PDSS_INTR1_VCMP_DN_CHANGED |
                    PDSS_INTR1_VCMP_LA_CHANGED |
                    PDSS_INTR1_CC1_CHANGED |
                    PDSS_INTR1_CC2_CHANGED);

            pd->rp_rd_cfg2 &= ~(PDSS_RP_RD_CFG2_OVERRIDE_HW_REF_CTRL |
                                PDSS_RP_RD_CFG2_VCMP_CC_OVERRIDE |
                                PDSS_RP_RD_CFG2_CC1_ATTACH_VALUE |
                                PDSS_RP_RD_CFG2_CC2_ATTACH_VALUE);
            /* Need to use firmware override of references to get expected voltage on the CC line. */
            pd->rp_rd_cfg2 |= PDSS_RP_RD_CFG2_VCMP_CC_OVERRIDE | PDSS_RP_RD_CFG2_OVERRIDE_HW_REF_CTRL;

            pd->rp_rd_cfg1 &= ~(PDSS_RP_RD_CFG1_TOGGLE_PERIOD_MASK |
                    PDSS_RP_RD_CFG1_BASE_HIGH_WIDTH_MASK |
                    PDSS_RP_RD_CFG1_CONTINUE_PREV);

#if (TIMER_TYPE == TIMER_TYPE_WDT)
            /* If WDT timer is being used, we can use a calibrated period setting. */
            pd->rp_rd_cfg1 |= (
                    ((PDSS_DRP_TOGGLE_PERIOD_MS * timer_get_multiplier()) << PDSS_RP_RD_CFG1_TOGGLE_PERIOD_POS) |
                    ((PDSS_DRP_HIGH_PERIOD_MS * timer_get_multiplier()) << PDSS_RP_RD_CFG1_BASE_HIGH_WIDTH_POS) |
                    PDSS_RP_RD_CFG1_HW_RP_RD_AUTO_TOGGLE |
                    PDSS_RP_RD_CFG1_RESET_COUNT
                    );
#else
            /* SYSTICK is used and LF CLK calibration is not done. */
            pd->rp_rd_cfg1 |= (
                    (PDSS_DRP_TOGGLE_PERIOD_VAL << PDSS_RP_RD_CFG1_TOGGLE_PERIOD_POS) |
                    (PDSS_DRP_HIGH_PERIOD_VAL << PDSS_RP_RD_CFG1_BASE_HIGH_WIDTH_POS) |
                    PDSS_RP_RD_CFG1_HW_RP_RD_AUTO_TOGGLE |
                    PDSS_RP_RD_CFG1_RESET_COUNT
                    );
#endif /* TIMER_TYPE */

            while(pd->rp_rd_cfg1 & PDSS_RP_RD_CFG1_RESET_COUNT);

            /* Setting cc1/cc2 filters */
            /* Configure filter clock cycles and disable the filter. */
            pd->intr1_cfg_cc1_cc2_ls &= ~(PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_SEL_MASK |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_SEL_MASK |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_RESET |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_RESET |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_BYPASS |
                    PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_BYPASS);

            pd->intr1_cfg_cc1_cc2_ls |= ((PDSS_CC_FILT_CYCLES << PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_SEL_POS) |
                    (PDSS_CC_FILT_CYCLES << PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_SEL_POS) |
                    (PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN | PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN));

            /*
             * Connect  up comparator to CC1 and down comparator to CC2. Also,
             * Set the up comparator on CC1 and the down comparator on CC2 for
             * rising threshold of 0.2V.
             */
            pd->cc_ctrl_0 = ((pd->cc_ctrl_0 & ~(PDSS_CC_CTRL_0_CMP_UP_CC1V2 |
                    PDSS_CC_CTRL_0_CMP_UP_VSEL_MASK | PDSS_CC_CTRL_0_CMP_DN_VSEL_MASK)) |
                    (PDSS_CC_CTRL_0_CMP_EN | PDSS_CC_CTRL_0_CMP_DN_CC1V2));

            /* Setting up/dn filters */
            pd->intr1_cfg_vcmp_up_down_ls &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_SEL_MASK |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_SEL_MASK |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_RESET |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_RESET |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_BYPASS |
                    PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_BYPASS);
            pd->intr1_cfg_vcmp_up_down_ls |= (
                    (PDSS_CC_FILT_CYCLES << PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_SEL_POS) |
                    (PDSS_CC_FILT_CYCLES << PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_SEL_POS) |
                    (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN |
                     PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN));

            /* Auto toggle is active. Prevent other changes from happening. */
            gl_pdss_status[port].auto_toggle_act = true;

            pd->intr1 = PDSS_INTR1_DRP_ATTACHED_DETECTED;
            pd->intr1_mask |= PDSS_INTR1_DRP_ATTACHED_DETECTED;

            pd->rp_rd_cfg1 |= PDSS_RP_RD_CFG1_START_TOGGLE;
        }
        else
        {
            /*
               Leave auto toggle disabled for now. It will get re-enabled when
               the Type-C state machine enters Unattached.SRC again.
             */
            gl_pdss_status[port].auto_toggle_en = false;
        }
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */
    }

    return true;
#else /* !SYS_DEEPSLEEP_ENABLE */
    return false;
#endif /* SYS_DEEPSLEEP_ENABLE */
}

#if SYS_DEEPSLEEP_ENABLE
extern void typec_gen_entry_event(uint8_t port, typec_fsm_state_t next_state);

static void pd_phy_wake_port(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    dpm_status_t* dpm_stat = dpm_get_status(port);
    uint32_t regval;
    uint32_t mask;

    if (!(dpm_stat->dpm_enabled))
    {
        return;
    }

    /* Clear and disable all deepsleep interrupts. */
    mask = (PDSS_INTR1_VCMP_UP_CHANGED | PDSS_INTR1_VCMP_DN_CHANGED | PDSS_INTR1_VCMP_LA_CHANGED |
            PDSS_INTR1_CC1_CHANGED | PDSS_INTR1_CC2_CHANGED);
    pd->intr1_mask &= ~mask;
    pd->intr1       = mask;

#if (!(CCG_SOURCE_ONLY))
    if ((dpm_stat->connect == true) && (dpm_stat->cur_port_role == PRT_ROLE_SINK))
    {
#if CCG_PD_REV3_ENABLE
        if(dpm_stat->fr_rx_en_live == false)
#endif /* CCG_PD_REV3_ENABLE */
        {
            /* Disable the detach detection comparator. */
            pd_adc_comparator_ctrl(port, pd_vbus_detach_adc_id, PD_ADC_INPUT_AMUX_A, 0, PD_ADC_INT_DISABLED, NULL);
        }
    }
#else
    if (0)
    {

    }
#endif /* (!(CCG_SOURCE_ONLY)) */
    else if(dpm_stat->connect == false)
    {
#if (!(CCG_SOURCE_ONLY))
        if (dpm_stat->toggle == true)
        {
#if CCG_HW_DRP_TOGGLE_ENABLE
            if ((gl_pdss_status[port].auto_toggle_en != 0) || (gl_pdss_status[port].typec_start_pending != 0))
            {
                if (gl_pdss_status[port].auto_toggle_act)
                {
                    /*
                       Auto toggle is active and attach has not been detected. Do nothing.
                     */
                    return;
                }

                /* Type-C restart will be done below if required. */
                gl_pdss_status[port].typec_start_pending = false;

                /*
                   Type-C state machine will not be up-to-date when DRP toggle is being done by hardware.
                   We need to jump to the right Type-C state to resume operation.
                 */
                if ((pd->rp_rd_cfg1 & PDSS_RP_RD_CFG1_HW_RP_RD_AUTO_TOGGLE) != 0)
                {
                    if (pd->status & PDSS_STATUS_RP_RD_STATUS)
                    {
                        pd_typec_en_rp(port, CC_CHANNEL_1, (rp_term_t)dpm_stat->src_cur_level_live);
                        pd_typec_en_rp(port, CC_CHANNEL_2, (rp_term_t)dpm_stat->src_cur_level_live);

                        /* Disable the deep sleep Rp. */
                        pd->cc_ctrl_1 &= ~PDSS_CC_CTRL_1_DS_ATTACH_DET_EN;

                        dpm_stat->cur_port_role = PRT_ROLE_SOURCE;
                        dpm_stat->cur_port_type = PRT_TYPE_DFP;
                        gl_dpm_port_type[port]  = PRT_TYPE_DFP;
                        typec_gen_entry_event(port, TYPEC_FSM_UNATTACHED_SRC);
                    }
                    else
                    {
                        pd_typec_en_rd(port, CC_CHANNEL_1);
                        pd_typec_en_rd(port, CC_CHANNEL_2);

                        dpm_stat->cur_port_role = PRT_ROLE_SINK;
                        dpm_stat->cur_port_type = PRT_TYPE_UFP;
                        gl_dpm_port_type[port]  = PRT_TYPE_UFP;
                        typec_gen_entry_event(port, TYPEC_FSM_UNATTACHED_SNK);
                    }

                    /* Disable the RP-RD toggle. Rp or Rd needs to be applied before this. */
                    pd->rp_rd_cfg1 &= ~(PDSS_RP_RD_CFG1_HW_RP_RD_AUTO_TOGGLE | PDSS_RP_RD_CFG1_START_TOGGLE);
                    pd->intr1_mask &= ~PDSS_INTR1_DRP_ATTACHED_DETECTED;

                    /* Leave auto toggle disabled until enabled again by Type-C module. */
                    gl_pdss_status[port].auto_toggle_en = false;

                    /* typec_gen_entry_event disables scanning so reenable it */
                    dpm_stat->skip_scan = false;

                    /* Type-C start is required to enable RX. */
                    pd_typec_start(port);
                }
            }
#endif /* CCG_HW_DRP_TOGGLE_ENABLE */
        }
#endif /* (!(CCG_SOURCE_ONLY)) */

        if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
        {
            /* Re-enable the trimmed Rp. */
            pd_typec_en_rp(port, CC_CHANNEL_1, (rp_term_t)dpm_stat->src_cur_level_live);
            pd_typec_en_rp(port, CC_CHANNEL_2, (rp_term_t)dpm_stat->src_cur_level_live);
        }

        /* Disable the deep sleep Rp. */
        pd->cc_ctrl_1 &= ~PDSS_CC_CTRL_1_DS_ATTACH_DET_EN;

        /* Disable cc1/cc2/up/down filters */
        regval = pd->intr1_cfg_cc1_cc2_ls;
        regval &= ~(PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN |
                PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN);
        regval |= PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_BYPASS |
            PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_BYPASS;
        pd->intr1_cfg_cc1_cc2_ls = regval;


        regval = pd->intr1_cfg_vcmp_up_down_ls;
        regval &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN |
                PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN);
        regval |= (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_BYPASS |
                PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_BYPASS);
        pd->intr1_cfg_vcmp_up_down_ls = regval;

    }
}
#endif /* SYS_DEEPSLEEP_ENABLE */

void pd_hal_typec_sm_restart(uint8_t port)
{
#if ((SYS_DEEPSLEEP_ENABLE) && (CCG_HW_DRP_TOGGLE_ENABLE))
    if (gl_pdss_status[port].typec_start_pending)
    {
        pd_phy_wake_port(port);
    }
#endif /* ((SYS_DEEPSLEEP_ENABLE) && (CCG_HW_DRP_TOGGLE_ENABLE)) */
}

bool pd_phy_wakeup(void)
{
#if SYS_DEEPSLEEP_ENABLE
    uint8_t port;

    for (port = 0; port < NO_OF_TYPEC_PORTS; port++)
    {
        pd_phy_wake_port(port);
    }
#endif /* SYS_DEEPSLEEP_ENABLE */

    return true;
}

ccg_status_t pd_phy_init(uint8_t port, pd_phy_cbk_t cbk)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];

    pdss_stat->pd_phy_cbk = cbk;

#if CCG_PD_REV3_ENABLE
    /* Configure RX_SOP_GOOD_CRC_EN_CTRL */
    pd->rx_sop_good_crc_en_ctrl = RX_SOP_GOOD_CRC_EN_CTRL_REV3_CFG;
    /* Configure Extended Header Info register */
    pd->header_info = HEADER_INFO_CFG;
#else
    /* Configure RX_SOP_GOOD_CRC_EN_CTRL */
    pd->rx_sop_good_crc_en_ctrl = RX_SOP_GOOD_CRC_EN_CTRL_CFG;
#endif /* CCG_PD_REV3_ENABLE */

    /* Configure RX_CC reg */
    pd->rx_cc_0_cfg = RX_CC_CFG;

    /* Configure RX_ORDER_SET_CTRL */
    pd->rx_order_set_ctrl = RX_ORDER_SET_CTRL_CFG;

    /* Configure CRC_COUNTER reg */
    pd->crc_counter = CRC_COUNTER_CFG;

    /* Configure INTER_PACKET_COUNTER reg */
    pd->inter_packet_counter = INTER_PACKET_COUNTER_CFG;

    /* Disable all PD interrupts */
    pd->intr0_mask &= ~PD_INTR_MASK;

    /* Configure DEBUG_CC_2 reg to disable cc monitoring during idle gap before
     * transmitting goodcrc and set expected goodrc message header mask */
    pd->debug_cc_2 = PDSS_DEBUG_CC_2_DIS_CC_MON_AUTO_CRC | pd_hal_mmio_reg_update_field (pd->debug_cc_2,
            EXPECTED_GOOD_CRC_HDR_MASK, PDSS_DEBUG_CC_2_EXPECTED_HEADER_MASK_MASK,
            PDSS_DEBUG_CC_2_EXPECTED_HEADER_MASK_POS);

    /* Configure SOP_PRIME and SOP_DPRIME Auto Goodrc Header */
    pd->tx_goodcrc_msg_order_set = TX_SOP_PRIME_DPRIME_GD_CRC_HDR_DFLT;

    return CCG_STAT_SUCCESS;
}

void pd_phy_refresh_roles(uint8_t port)
{
#if CCG_PD_REV3_ENABLE
    PPDSS_REGS_T pd = gl_pdss[port];
    dpm_status_t* dpm_stat = dpm_get_status(port);
    uint32_t temp;
    bool rev3 = false;

    if (dpm_stat->spec_rev_sop_live >= PD_REV3)
        rev3 = true;

    temp = pd->rx_order_set_ctrl;
    temp &= ~PDSS_RX_ORDER_SET_CTRL_SOP_RST_EN_MASK;
    temp |= (EN_DEFAULT_SOP_DET_VAL | EN_RX_HARD_RESET_DET_VAL);

    if (rev3)
    {
        /* Update goodcrc mask */
        pd->debug_cc_2 |= ((uint32_t)EXPECTED_GOOD_CRC_HDR_DIFF_MASK_REV3 << PDSS_DEBUG_CC_2_EXPECTED_HEADER_MASK_POS);

        /* Enable Extended RX */
        pd->header_info |= PDSS_HEADER_INFO_EN_RX_EXTENDED_DATA;
    }
    else
    {
        /* Update goodcrc mask */
        pd->debug_cc_2 &= ~((uint32_t)EXPECTED_GOOD_CRC_HDR_DIFF_MASK_REV3 << PDSS_DEBUG_CC_2_EXPECTED_HEADER_MASK_POS);

        /* Disable Extended RX/TX */
        pd->header_info &= ~(PDSS_HEADER_INFO_EN_RX_EXTENDED_DATA | PDSS_HEADER_INFO_EN_TX_EXTENDED_DATA);
    }

    /* Start off with cable communication disallowed. */
    temp &= ~(EN_PRIME_SOP_DET_VAL | EN_DBL_SOP_DET_VAL);

    /* If cable discovery is disabled, never allow SOP'/SOP'' communication. */
    if (dpm_stat->cbl_dsc != false)
    {
        if (dpm_stat->contract_exist == false)
        {
            /*
             * While in implicit contract, only source can talk to cable (SOP' only allowed).
             * Also, only VConn Source is allowed when the spec revision is PD 3.0.
             */
            if (
                    (dpm_stat->cur_port_role == PRT_ROLE_SOURCE) &&
                    ((!rev3) || (dpm_stat->vconn_logical != false))
               )
            {
                /* Enable SOP_PRIME only */
                temp |= EN_PRIME_SOP_DET_VAL;
            }
        }
        else
        {
            /*
             * Only VConn Source can talk to cable during a PD REV3 contract.
             * Only DFP can talk to cable during a PD 2.0 contract.
             */
            if (
                    ((rev3) && (dpm_stat->vconn_logical != false)) ||
                    ((!rev3) && (dpm_stat->cur_port_type == PRT_TYPE_DFP))
               )
            {
                /* Enable SOP_PRIME GoodCRC. */
                temp |= EN_PRIME_SOP_DET_VAL;

                /* If cable has been discovered, enabled SOP_DPRIME GoodCRC. */
                if (dpm_stat->emca_present)
                {
                    temp |= EN_DBL_SOP_DET_VAL;
                }
            }
        }
    }

    pd->rx_order_set_ctrl = temp;

    temp = pd->tx_ctrl;
    temp &= ~PDSS_TX_CTRL_GOODCRC_MSG_BITS_MASK;
    temp |= ( CTRL_MSG_GOOD_CRC | PD_DR_PR_ROLE(dpm_stat->cur_port_type, dpm_stat->cur_port_role));
    temp |= (PD_REV2 << PD_REV_POS);
    pd->tx_ctrl = temp;

    /* Configure SOP_PRIME and SOP_DPRIME Auto Goodrc Header */
    temp = CTRL_MSG_GOOD_CRC;
    temp |= (PD_REV2 << PD_REV_POS);
    pd->tx_goodcrc_msg_order_set = (temp << 16)| temp;

#else

    PPDSS_REGS_T pd = gl_pdss[port];
    dpm_status_t* dpm_stat = dpm_get_status(port);
    uint32_t temp;

    temp = pd->rx_order_set_ctrl;
    temp &= ~PDSS_RX_ORDER_SET_CTRL_SOP_RST_EN_MASK;
    temp |= (EN_DEFAULT_SOP_DET_VAL | EN_RX_HARD_RESET_DET_VAL);

    /* Start off with cable communication disallowed. */
    temp &= ~(EN_PRIME_SOP_DET_VAL | EN_DBL_SOP_DET_VAL);

    /* If cable discovery is disabled, never allow SOP'/SOP'' communication. */
    if (dpm_stat->cbl_dsc != false)
    {
        if (dpm_stat->contract_exist == false)
        {
            /* While in implicit contract, only source can talk to cable (SOP' only allowed). */
            if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
            {
                /* Enable SOP_PRIME only */
                temp |= EN_PRIME_SOP_DET_VAL;
            }
        }
        else
        {
            /* Only DFP can talk to cable during a PD 2.0 contract. */
            if (dpm_stat->cur_port_type == PRT_TYPE_DFP)
            {
                /* Enable SOP_PRIME GoodCRC. */
                temp |= EN_PRIME_SOP_DET_VAL;

                /* If cable has been discovered, enabled SOP_DPRIME GoodCRC. */
                if (dpm_stat->emca_present)
                {
                    temp |= EN_DBL_SOP_DET_VAL;
                }
            }
        }
    }

    pd->rx_order_set_ctrl = temp;

    temp = pd->tx_ctrl;
    temp &= ~PDSS_TX_CTRL_GOODCRC_MSG_BITS_MASK;
    temp |= (TX_SOP_GD_CRC_HDR_DFLT | PD_DR_PR_ROLE(dpm_stat->cur_port_type, dpm_stat->cur_port_role));
    pd->tx_ctrl = temp;
#endif /* CCG_PD_REV3_ENABLE */
}

void pd_phy_en_unchunked_tx(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pd->header_info |= PDSS_HEADER_INFO_EN_TX_EXTENDED_DATA;
}

void pd_phy_dis_unchunked_tx(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pd->header_info &= ~PDSS_HEADER_INFO_EN_TX_EXTENDED_DATA;
}

bool pd_phy_load_data_in_mem(uint8_t port, bool start)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t *pdss_stat = &gl_pdss_status[port];
    uint8_t i;
    uint8_t tx_ptr = pd->sram_ptr & PDSS_SRAM_PTR_TX_FUNC_RD_PTR_MASK;
    uint8_t start_idx = 0;
    uint8_t mem_size = 0;

    if(pdss_stat->tx_dobj_count == 0)
    {
        return false;
    }

    if(start == true)
    {
        mem_size = PDSS_MAX_TX_MEM_SIZE;
    }
    else
    {
        mem_size = PDSS_MAX_TX_MEM_HALF_SIZE;
        if(tx_ptr < PDSS_MAX_TX_MEM_HALF_SIZE)
        {
            start_idx = PDSS_MAX_TX_MEM_HALF_SIZE;
        }
    }

    /* Copy the data into the Tx memory. */
    for (i = start_idx; i < (start_idx+ mem_size); i++)
    {
        pd->tx_mem_data[i] = pdss_stat->tx_dat_ptr[pdss_stat->tx_obj_sent];
        pdss_stat->tx_obj_sent++;
        if(pdss_stat->tx_obj_sent >= pdss_stat->tx_dobj_count)
        {
            return false;
        }
    }

    return true;
}

#if CCG_PD_REV3_ENABLE
void pd_phy_read_data_from_mem(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t *pdss_stat = &gl_pdss_status[port];
    uint8_t i;
    uint8_t start_idx = pdss_stat->rx_read_location;
    uint8_t mem_size = PDSS_MAX_RX_MEM_HALF_SIZE;

    /* Copy the data from rx memory. */
    for (i = start_idx; i < (start_idx + mem_size); i++)
    {
        if(pdss_stat->rx_unchunk_count >= pdss_stat->rx_unchunk_len)
        {
            return;
        }
        pdss_stat->rx_pkt.dat[pdss_stat->rx_unchunk_count].val = pd->rx_mem_data[i];
        pdss_stat->rx_unchunk_count++;
    }

    /* Flip to the other half of the SRAM for the next read. */
    pdss_stat->rx_read_location = (pdss_stat->rx_read_location == 0) ?
        PDSS_MAX_RX_MEM_HALF_SIZE: 0;
}
#endif /* CCG_PD_REV3_ENABLE */

bool pd_phy_load_msg(uint8_t port, sop_t sop, uint8_t retries,
        uint8_t dobj_count, uint32_t header, bool unchunked, uint32_t* buf)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t *pdss_stat = &gl_pdss_status[port];
    uint16_t exp_hdr;

    pdss_stat->tx_dat_ptr = buf;
    pdss_stat->tx_dobj_count = dobj_count;
    pdss_stat->tx_unchunked = unchunked;

    /* Make sure GoodCRC response to SOP'' messages is enabled where required. */
    if (sop == SOP_DPRIME)
    {
        pd->rx_order_set_ctrl |= EN_DBL_SOP_DET_VAL;
    }

    /* Configure SOP ordered set. */
    pd->tx_sop_order_set = os_table[sop];

    /*
     * Configure the expected sop type and expected GoodCRC. Expected GoodCRC
     * mask was already set by pd_phy_init(). SOP type in hardware is sop + 1.
     */
    exp_hdr = header & (~EXPECTED_GOOD_CRC_CLEAR_MASK);
    exp_hdr |= CTRL_MSG_GOOD_CRC;
    pd->rx_expect_goodcrc_msg = exp_hdr | ((sop + 1) << PDSS_RX_EXPECT_GOODCRC_MSG_EXPECTED_SOP_POS);

    /* Load the header in the Tx header register. */
    pd->tx_header = header;

    /* Save the number of requested retries. */
    pdss_stat->retry_cnt = (int8_t)retries;
    return true;
}

void pd_phy_reset_rx_tx_sm(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Stop any ongoing transmission */
    pd->debug_ctrl |= (PDSS_DEBUG_CTRL_RESET_TX | PDSS_DEBUG_CTRL_RESET_RX);
    CyDelayUs(5);
    pd->debug_ctrl &= ~(PDSS_DEBUG_CTRL_RESET_TX | PDSS_DEBUG_CTRL_RESET_RX);
}

bool pd_phy_send_msg(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];
    uint32_t rval;

    pd->intr0_mask &= ~PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;

    /* Clear Tx interrupts. */
    pd->intr0 = (TX_INTERRUPTS | PDSS_INTR0_RCV_EXPT_GOODCRC_MSG_COMPLETE |
        PDSS_INTR0_TX_RETRY_ENABLE_CLRD | PDSS_INTR0_CC_NO_VALID_DATA_DETECTED |
        PDSS_INTR0_TX_SRAM_HALF_END);

    if (pdss_stat->retry_cnt < 0)
    {
        /* Create this interrupt to stop transmission. */
        pd->intr0_set |= PDSS_INTR0_CRC_RX_TIMER_EXP;
        return true;
    }

    if (pd->status & (PDSS_STATUS_RX_BUSY | PDSS_STATUS_SENDING_GOODCRC_MSG))
    {
        pdss_stat->retry_cnt--;

        pd->intr0_mask |= PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;

        /*
         * Notify the protocol layer so that it can start a timer so as to
         * avoid an infinite wait on the channel going idle.
         */
        pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_MSG_COLLISION);

        return true;
    }

    pdss_stat->tx_obj_sent = 0;
    if(pd_phy_load_data_in_mem(port, true) == true)
    {
        /* Enable TX SRAM HALF END interrupt */
        pd->intr0_mask |= PDSS_INTR0_TX_SRAM_HALF_END;
    }
    /* Enable Tx interrupts. */
    pd->intr0_mask |= TX_INTERRUPTS;

    /* Checks if unchunked TX need to be enabled */
    if(pdss_stat->tx_unchunked == true)
    {
        pd->header_info |= PDSS_HEADER_INFO_EN_TX_EXTENDED_DATA;
    }
    else
    {
        pd->header_info &= ~PDSS_HEADER_INFO_EN_TX_EXTENDED_DATA;
    }

    rval = pd->tx_ctrl;
    if (pdss_stat->retry_cnt != 0)
    {
        rval |= PDSS_TX_CTRL_TX_RETRY_ENABLE;
    }
    else
    {
        /* No retries. */
        rval &= ~PDSS_TX_CTRL_TX_RETRY_ENABLE;
    }
    rval |= PDSS_TX_CTRL_TX_GO;

    pdss_stat->tx_done = false;
    pdss_stat->retry_cnt--;

    /* Begin transmission. */
    pd->tx_ctrl = rval;

    return true;
}

ccg_status_t pd_prot_stop(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    pd_prot_rx_dis(port, false);

    pd->intr0_mask &= ~(TX_INTERRUPTS | RST_TX_INTERRUPTS |
                        PDSS_INTR0_TX_RETRY_ENABLE_CLRD |
                        PDSS_INTR0_CC_NO_VALID_DATA_DETECTED|
                        PDSS_INTR0_TX_SRAM_HALF_END);
    pd->intr0 = (TX_INTERRUPTS | RST_TX_INTERRUPTS |
                 PDSS_INTR0_TX_RETRY_ENABLE_CLRD |
                 PDSS_INTR0_CC_NO_VALID_DATA_DETECTED|
                 PDSS_INTR0_TX_SRAM_HALF_END);

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_prot_rx_en(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];

    pdss_stat->rx_unchunked = false;

    /* Clear and enable RX interrupts. */
    pd->intr0 = (RX_INTERRUPTS |RCV_INTR_MASK);

#if CCG_PD_REV3_ENABLE

    dpm_status_t* dpm_stat = dpm_get_status(port);
    pd->intr2 = PDSS_INTR2_EXTENDED_MSG_DET | PDSS_INTR2_CHUNK_DET |PDSS_INTR2_RX_SRAM_OVER_FLOW;
    if(dpm_stat->spec_rev_sop_live >=PD_REV3)
    {
        pd->intr2_mask |= PDSS_INTR2_EXTENDED_MSG_DET;
    }

#endif /* CCG_PD_REV3_ENABLE */

    pd->intr0_mask |= RX_INTERRUPTS;

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_prot_rx_dis(uint8_t port, uint8_t hard_reset_en)
{
    uint32_t temp;
    PPDSS_REGS_T pd = gl_pdss[port];

#if CCG_PD_REV3_ENABLE

    pd->intr2_mask &= ~(PDSS_INTR2_EXTENDED_MSG_DET | PDSS_INTR2_CHUNK_DET);
    pd->intr2 = (PDSS_INTR2_EXTENDED_MSG_DET | PDSS_INTR2_CHUNK_DET |
            PDSS_INTR2_RX_SRAM_OVER_FLOW);

#endif /* CCG_PD_REV3_ENABLE */

    if (hard_reset_en == false)
    {
        /* Disable Rx.*/
        pd->rx_order_set_ctrl &= ~PDSS_RX_ORDER_SET_CTRL_SOP_RST_EN_MASK;

        /* Disable and clear all Rx interrupts.*/
        pd->intr0_mask &= ~RX_INTERRUPTS;
    }

    if (hard_reset_en == true)
    {
        /* Enable only Hard Reset reception. */
        temp = pd->rx_order_set_ctrl;
        temp &= ~PDSS_RX_ORDER_SET_CTRL_SOP_RST_EN_MASK;
        temp |= EN_RX_HARD_RESET_DET_VAL;
        pd->rx_order_set_ctrl = temp;

        /* Enable only the Hard Reset received interrrupt. */
        temp = pd->intr0_mask;
        temp &= ~RX_INTERRUPTS;
        temp |=  PDSS_INTR0_RCV_RST;
        pd->intr0_mask = temp;
    }

    pd->intr0 = RX_INTERRUPTS;

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_phy_send_bist_cm2(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Enable Tx regulator. */
    pd->tx_ctrl |= PDSS_TX_CTRL_TX_REG_EN;

    /* Delay to let the Tx regulator turn on. */
    CyDelayUs(50);

    /* Start BIST CM2. */
    pd->tx_ctrl |= PDSS_TX_CTRL_EN_TX_BIST_CM2;

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_phy_abort_bist_cm2(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Stop BIST CM2. */
    pd->tx_ctrl &= ~PDSS_TX_CTRL_EN_TX_BIST_CM2;

    /* Disable Tx regulator. */
    pd->tx_ctrl &= ~PDSS_TX_CTRL_TX_REG_EN;

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_phy_abort_tx_msg(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];

    pdss_stat->tx_done = false;

    pd->intr0_mask &= ~(TX_INTERRUPTS | PDSS_INTR0_TX_RETRY_ENABLE_CLRD |
                        PDSS_INTR0_CC_NO_VALID_DATA_DETECTED | PDSS_INTR0_TX_SRAM_HALF_END);
    pd->intr0 = (TX_INTERRUPTS | PDSS_INTR0_TX_RETRY_ENABLE_CLRD |
                 PDSS_INTR0_CC_NO_VALID_DATA_DETECTED |PDSS_INTR0_TX_SRAM_HALF_END);

    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_phy_send_reset(uint8_t port, sop_t sop)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t loops = 10;

    /* If this is a hard reset, we should reset the TX and RX state machine for this port. */
    if (sop == HARD_RESET)
    {
        pd_phy_reset_rx_tx_sm(port);
    }

    /* Send a Hard Reset or Cable Reset. */
    pd->intr0 = RST_TX_INTERRUPTS;
    pd->intr0_mask |= RST_TX_INTERRUPTS;

    pd->tx_hard_cable_order_set = os_table[sop];

    /* Wait while there is valid data on the CC line. */
    if (sop == HARD_RESET)
    {
        /* Wait while there is valid data on the CC line. */
        while ((loops > 0) &&
                ((pd->status & (
                                PDSS_STATUS_CC_DATA_VALID |
                                PDSS_STATUS_RX_BUSY |
                                PDSS_STATUS_TX_BUSY |
                                PDSS_STATUS_SENDING_GOODCRC_MSG
                               )
                 ) != 0)
              )
        {
            loops--;
            CyDelayUs (10);
        }

        if (
                (pd->status & (
                               PDSS_STATUS_CC_DATA_VALID |
                               PDSS_STATUS_RX_BUSY |
                               PDSS_STATUS_TX_BUSY |
                               PDSS_STATUS_SENDING_GOODCRC_MSG
                              )
                ) != 0)
        {
            /* Return busy so that the reset gets attempted again at a later time. */
            return CCG_STAT_BUSY;
        }
    }

    pd->tx_ctrl |= PDSS_TX_CTRL_TX_SEND_RST;
    return CCG_STAT_SUCCESS;
}

pd_packet_extd_t *pd_phy_get_rx_packet(uint8_t port)
{
    return &gl_pdss_status[port].rx_pkt;
}

bool pd_phy_is_busy(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (((pd->status & (PDSS_STATUS_CC_DATA_VALID |
                        PDSS_STATUS_RX_BUSY |
                        PDSS_STATUS_TX_BUSY |
                        PDSS_STATUS_SENDING_GOODCRC_MSG
                       )) != 0 ) ||
        (pd->intr0 & PDSS_INTR0_RCV_RST))
    {
        return true;
    }

    return false;
}


void pdss_intr0_handler(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];
    uint32_t rval;

#if ((CCG_HPD_RX_ENABLE) || (!CCG_PD_REV3_ENABLE))
    uint32_t  i;
#endif /* ((CCG_HPD_RX_ENABLE) || (!CCG_PD_REV3_ENABLE)) */

#if CCG_PD_REV3_ENABLE
    dpm_status_t* dpm_stat = dpm_get_status(port);
    pd_hdr_t msg_hdr;
#endif /* CCG_PD_REV3_ENABLE */

    if (pd->intr0_masked != 0)
    {
        /*
         * Receive interrupt handling.
         */
        if (pd->intr0_masked & PDSS_INTR0_RCV_RST)
        {
            pdss_stat->tx_done = false;
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_RX_RST);
            pd->intr0 = (PDSS_INTR0_RCV_RST | PDSS_INTR0_EOP_ERROR);
        }

        if (pd->intr0_masked & PDSS_INTR0_TX_PACKET_DONE)
        {
            pd->intr0 = PDSS_INTR0_TX_PACKET_DONE;
            pdss_stat->tx_done = true;
        }

#if CCG_PD_REV3_ENABLE
        if (pd->intr2_masked & PDSS_INTR2_EXTENDED_MSG_DET)
        {
            if(pd->intr2 & PDSS_INTR2_CHUNK_DET)
            {
                pdss_stat->rx_unchunked = false;
            }
            else
            {
                pdss_stat->rx_unchunked = true;

                /* Store total byte count and initialize bytes received. */
                msg_hdr.val = pd->rx_header;
                pdss_stat->rx_unchunk_len = ((msg_hdr.hdr.data_size + 3) >> 2);
                if(pdss_stat->rx_unchunk_len > MAX_EXTD_PKT_WORDS)
                {
                    pdss_stat->rx_unchunk_len = MAX_EXTD_PKT_WORDS;
                }

                pdss_stat->rx_unchunk_count = 0;
                pdss_stat->rx_read_location = 0;
            }

            /* Extended message detected */
            /* Clear interrupt */
            pd->intr2 = PDSS_INTR2_CHUNK_DET | PDSS_INTR2_EXTENDED_MSG_DET;
        }

        if(pd->intr0_masked & PDSS_INTR0_RX_SRAM_HALF_END)
        {
            /* Store data in extended buf and update count*/
            pd_phy_read_data_from_mem(port);
            pd->intr0 = PDSS_INTR0_RX_SRAM_HALF_END;
        }
#endif /* CCG_PD_REV3_ENABLE */

        if (pd->intr0_masked & PDSS_INTR0_RX_STATE_IDLE)
        {
            rval =  pd->intr0;

            if (rval & PDSS_INTR0_RCV_GOODCRC_MSG_COMPLETE)
            {
                if ((rval & (PDSS_INTR0_RCV_EXPT_GOODCRC_MSG_COMPLETE | PDSS_INTR0_EOP_ERROR)) ==
                        PDSS_INTR0_RCV_EXPT_GOODCRC_MSG_COMPLETE)
                {
                    if (pdss_stat->tx_done == true)
                    {
                        pdss_stat->tx_done = false;

                        /* Stop retries due to CRC countdown expiry. */
                        pd->rx_expect_goodcrc_msg |= PDSS_RX_EXPECT_GOODCRC_MSG_DISABLE_RX_CRC_TIMER;

                        pd->intr0_mask &= ~TX_INTERRUPTS;
                        pd->intr0 = TX_INTERRUPTS;

                        /* Successful transmission notification. */
                        pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_MSG_SUCCESS);
                    }
                }
            }

            if (rval & PDSS_INTR0_RCV_GOOD_PACKET_COMPLETE)
            {
                if ((rval & PDSS_INTR0_EOP_ERROR) == 0)
                {
                    pdss_stat->tx_done = false;

                    /* Disable and clear PDSS_INTR0_CC_NO_VALID_DATA_DETECTED. */
                    pd->intr0_mask &= ~PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;
                    pd->intr0 = PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;

                    /*
                     * Copy the received packet and analyze it. If the packet
                     * is valid with good msg id and if a Tx message is active,
                     * stop the Tx message and send a tx discard response to the
                     * upper layer. Also do not create a packet received event
                     * just now.
                     */
                    pdss_stat->rx_pkt.sop = (((pd->status & PDSS_STATUS_SOP_TYPE_DETECTED_MASK) >>
                                PDSS_STATUS_SOP_TYPE_DETECTED_POS) - 1);

                    /* Copy out the header from the PD hardware. */
                    pdss_stat->rx_pkt.hdr.val = pd->rx_header;

#if CCG_PD_REV3_ENABLE
                    if(dpm_stat->spec_rev_sop_live <= PD_REV2)
                    {
                        /* Ignore reserved bits */
                        pdss_stat->rx_pkt.hdr.val &= ~(PD_MSG_HDR_REV2_IGNORE_MASK);
                    }
#else
                    pdss_stat->rx_pkt.hdr.val &= ~(PD_MSG_HDR_REV2_IGNORE_MASK);
#endif /* CCG_PD_REV3_ENABLE */

                    /* Copy the data from the hardware buffer to the software buffer. */
                    pdss_stat->rx_pkt.len = pdss_stat->rx_pkt.hdr.hdr.len;
                    pdss_stat->rx_pkt.msg = pdss_stat->rx_pkt.hdr.hdr.msg_type;
                    pdss_stat->rx_pkt.data_role = pdss_stat->rx_pkt.hdr.hdr.data_role;

#if CCG_PD_REV3_ENABLE
                    if(pdss_stat->rx_unchunked == false)
                    {
                        mem_copy_word((uint32_t*)pdss_stat->rx_pkt.dat,
                                (uint32_t*)pd->rx_mem_data, pdss_stat->rx_pkt.len);
                    }
                    else
                    {
                        pd_phy_read_data_from_mem(port);
                    }
#else
                    for (i = 0; i < pdss_stat->rx_pkt.len; i++)
                    {
                        pdss_stat->rx_pkt.dat[i].val = pd->rx_mem_data[i];
                    }
#endif /* CCG_PD_REV3_ENABLE*/

                    pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_RX_MSG);
                }
            }

            pd->intr0 = RCV_INTR_MASK;

#if CCG_PD_REV3_ENABLE
            pdss_stat->rx_unchunked = false;
            pd->intr2 = PDSS_INTR2_EXTENDED_MSG_DET | PDSS_INTR2_CHUNK_DET | PDSS_INTR2_RX_SRAM_OVER_FLOW;
#endif /* CCG_PD_REV3_ENABLE */
        }

        if (pd->intr0_masked & PDSS_INTR0_TX_GOODCRC_MSG_DONE)
        {
            /* Create a packet received event. */
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_RX_MSG_CMPLT);

            /* Clear the interrupt. */
            pd->intr0 = PDSS_INTR0_TX_GOODCRC_MSG_DONE;
        }

        if (pd->intr0_masked & PDSS_INTR0_COLLISION_TYPE3)
        {
            /* Create a packet received event. */
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_RX_MSG_CMPLT);
            pd->intr0 = PDSS_INTR0_COLLISION_TYPE3;
        }

        if (pd->intr0_masked & PDSS_INTR0_CC_NO_VALID_DATA_DETECTED)
        {
            /* Disable the interrupt. */
            pd->intr0_mask &= ~PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;
            pd->intr0 = PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;

            /* Notify the protocol layer to stop the phy busy max limit timer. */
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_MSG_PHY_IDLE);
        }

        /*
         * Tx interrupt handling.
         */

        if(pd->intr0_masked & PDSS_INTR0_TX_SRAM_HALF_END)
        {
            if (pd_phy_load_data_in_mem(port, false) == false)
            {
                pd->intr0_mask &= ~PDSS_INTR0_TX_SRAM_HALF_END;
            }
            pd->intr0 = PDSS_INTR0_TX_SRAM_HALF_END;
        }

        if (pd->intr0_masked & PDSS_INTR0_CRC_RX_TIMER_EXP)
        {
            pdss_stat->tx_done = false;

            if (pdss_stat->retry_cnt < 0)
            {
                /* Transmission failed. */
                pd->intr0_mask &= ~TX_INTERRUPTS;
                pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_MSG_FAILED);
            }
            else
            {
                if (pdss_stat->retry_cnt != 0)
                {
                    /* Clear and enable the TX retry enable cleared interrupt if required */
                    pd->intr0 = PDSS_INTR0_TX_RETRY_ENABLE_CLRD;
                    /* Delay to remove any race */
                    CyDelayUs(5);

                    if (pd->tx_ctrl & PDSS_TX_CTRL_TX_RETRY_ENABLE)
                    {
                        pd->intr0_mask |= PDSS_INTR0_TX_RETRY_ENABLE_CLRD;
                    }
                    else
                    {
                        /* Delay so that IP works otherwise if clear and set is too fast
                         * retry can fail */
                        CyDelayUs(5);
                        pd->tx_ctrl |= PDSS_TX_CTRL_TX_RETRY_ENABLE;
                    }
                }
                pdss_stat->retry_cnt--;
            }
            pd->intr0 = PDSS_INTR0_CRC_RX_TIMER_EXP;
        }

        if (pd->intr0_masked & PDSS_INTR0_TX_RETRY_ENABLE_CLRD)
        {
            CyDelayUs(5);
            /* Enable retry. */
            pd->tx_ctrl |= PDSS_TX_CTRL_TX_RETRY_ENABLE;

            /* Disable interrupts. */
            pd->intr0_mask &= ~PDSS_INTR0_TX_RETRY_ENABLE_CLRD;
            pd->intr0 = PDSS_INTR0_TX_RETRY_ENABLE_CLRD;
        }

        if (pd->intr0_masked & (PDSS_INTR0_COLLISION_TYPE1 | PDSS_INTR0_COLLISION_TYPE2))
        {
            /*
             * Notify the protocol layer so that it can start a timer so as to
             * avoid an infinite wait on the channel going idle.
             */
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_MSG_COLLISION);

            /* Clear interrupts and enable the channel idle interrupt. */
            pd->intr0 = (PDSS_INTR0_COLLISION_TYPE1 | PDSS_INTR0_COLLISION_TYPE2 |
                         PDSS_INTR0_CC_NO_VALID_DATA_DETECTED);
            pd->intr0_mask |= PDSS_INTR0_CC_NO_VALID_DATA_DETECTED;

        }

        /*
         * Reset interrupt handling.
         */
        if (pd->intr0_masked & PDSS_INTR0_TX_HARD_RST_DONE)
        {
            pdss_stat->tx_done = false;
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_RST_SUCCESS);
            pd->intr0_mask &= ~RST_TX_INTERRUPTS;
            pd->intr0 = RST_TX_INTERRUPTS;
        }

        if (pd->intr0_masked & PDSS_INTR0_COLLISION_TYPE4)
        {
            pdss_stat->tx_done = false;
            pd->intr0_mask &= ~RST_TX_INTERRUPTS;
            pd->intr0 = RST_TX_INTERRUPTS;
            pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_TX_RST_COLLISION);
        }
    }

    if (pd->intr2_masked != 0)
    {
        /* Handle the queue interrupt, instead of specific plug/unplug/irq interrupts. */
        if ((pd->intr2_masked & PDSS_INTR2_HPD_QUEUE) != 0)
        {
            /* Clear the interrupt and send callbacks for all queued events. */
            pd->intr2 = PDSS_INTR2_HPD_QUEUE;

#if CCG_HPD_RX_ENABLE
            if (hpd_cbks[port] != NULL)
            {
                i = pd->hpd_queue;
                if (HPD_GET_EVENT_0(i) != HPD_EVENT_NONE)
                    hpd_cbks[port] (port, HPD_GET_EVENT_0(i));
                if (HPD_GET_EVENT_1(i) != HPD_EVENT_NONE)
                    hpd_cbks[port] (port, HPD_GET_EVENT_1(i));
                if (HPD_GET_EVENT_2(i) != HPD_EVENT_NONE)
                    hpd_cbks[port] (port, HPD_GET_EVENT_2(i));
                if (HPD_GET_EVENT_3(i) != HPD_EVENT_NONE)
                    hpd_cbks[port] (port, HPD_GET_EVENT_3(i));
            }
#endif /* CCG_HPD_RX_ENABLE */
        }

        if ((pd->intr2_masked & PDSS_INTR2_HPDT_COMMAND_DONE) != 0)
        {
            /* Clear the interrupt and send the callback. */
            pd->intr2 = PDSS_INTR2_HPDT_COMMAND_DONE;
            if (hpd_cbks[port] != NULL)
                hpd_cbks[port] (port, HPD_COMMAND_DONE);
        }

#if (!(CCG_SOURCE_ONLY))
#if (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE)
        if (pd->intr2_masked & (PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT))
        {
            /* Disable frs receive interrupts as we cannot clear them here. */
            pd->intr2_mask &= ~(PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT);

            /* Disable the swap controller */
            pd->swap_ctrl1 |= PDSS_SWAP_CTRL1_RESET_SWAP_STATE;

            /* Stop any ongoing transmission */
            pd_phy_reset_rx_tx_sm(port);

            /* Clear pending rx interrupts */
            pd->intr0 = RCV_INTR_MASK | PDSS_INTR0_COLLISION_TYPE3 |PDSS_INTR0_TX_GOODCRC_MSG_DONE;

            pdss_stat->rx_unchunked = false;
            pd->intr2 = PDSS_INTR2_EXTENDED_MSG_DET | PDSS_INTR2_CHUNK_DET | PDSS_INTR2_RX_SRAM_OVER_FLOW;

            /* Turn off the consumer fet */
            dpm_stat->app_cbk->psnk_disable(port, NULL);
            dpm_stat->skip_scan = true;

            if(pdss_stat->pd_phy_cbk != NULL)
            {
                pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_FRS_SIG_RCVD);
            }

            /* Cannot clear interrupt here as this will cause auto fet turn on to assume no FRS signal */
            CyIntClearPending(PD_PORT0_INTR0 + port);

            /* Enable the SWAP_VBUS_LESS_5_DONE interrupt so that we can identify when the power swap is done. */
            pd->intr1_mask |= PDSS_INTR1_VSWAP_VBUS_LESS_5_DONE;
        }
#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE) */

#if (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE)
        if(pd->intr2_masked & PDSS_INTR2_SWAP_COMMAND_DONE)
        {
            pd_frs_tx_disable(port);
            dpm_stat->fr_tx_en_live = false;

            pd_phy_reset_rx_tx_sm(port);

            /* Change Rp to allow sink to initiate AMS */
            typec_change_rp(port, RP_TERM_RP_CUR_3A);

            /* Turn On the sink fet */
            dpm_stat->app_cbk->psnk_enable(port);
            /* Stop sourcing power. */
            dpm_stat->app_cbk->psrc_disable(port, NULL);

            if(pdss_stat->pd_phy_cbk != NULL)
            {
                pdss_stat->pd_phy_cbk(port, PD_PHY_EVT_FRS_SIG_SENT);
            }
        }
#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE) */
#endif /* (!(CCG_SOURCE_ONLY)) */

    }

}

ccg_status_t pd_typec_init(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    pd->cc_ctrl_0 &= ~(PDSS_CC_CTRL_0_HYST_MODE | PDSS_CC_CTRL_0_EN_HYST | PDSS_CC_CTRL_0_CMP_LA_VSEL_MASK);
    pd->cc_ctrl_0 |= (PDSS_CC_CTRL_0_CMP_LA_VSEL_CFG << PDSS_CC_CTRL_0_CMP_LA_VSEL_POS);

    /*
     * Up/Down comparators filter will only be enabled before going to
     * deepsleep and disabled after coming out of deepsleep.
     */
    pd->intr1_cfg_vcmp_up_down_ls &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN |
                                       PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN);


    /* Disable filter on comparator output. */
    pd->intr3_cfg_adc_hs &= ~(PDSS_INTR3_CFG_ADC_HS_FILT_EN);
    pd->intr3_cfg_adc_hs |= PDSS_INTR3_CFG_ADC_HS_FILT_BYPASS;

    /* Always enable the pump. PUMP enable is done through Port0 for both ports. */
    ccg5_pump_enable (0, 0);

    return CCG_STAT_SUCCESS;
}

#if CCG_PD_DUALPORT_ENABLE
static uint32_t pdss_active_ports = 0;
#endif /* CCG_PD_DUALPORT_ENABLE */

ccg_status_t pd_typec_start(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;

    pd->dpslp_ref_ctrl &= ~PDSS_DPSLP_REF_CTRL_PD_DPSLP;
#if CCG_PD_DUALPORT_ENABLE
    if (port == 1)
    {
        /* Deep sleep reference has to be enabled on PD0 block. */
        gl_pdss[0]->dpslp_ref_ctrl &= ~PDSS_DPSLP_REF_CTRL_PD_DPSLP;
    }
#endif

    /* Power up the block. */
    pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_PWR_DISABLE;

    /* Enable PUMP */
    /* PUMP enable is done through Port0 for both ports. */
    ccg5_pump_enable (0, 0);

    CyDelayUs(50);

    pd->cc_ctrl_0  |= (PDSS_CC_CTRL_0_CMP_EN | PDSS_CC_CTRL_0_RX_EN);

    /* Use voltage reference from refgen to define CC tx_swing. */
    pd->cc_ctrl_1 |= PDSS_CC_CTRL_1_CC_VREF_1P1_SEL;



    /* Disable and bypass all filters. */
    regval = pd->intr1_cfg_cc1_cc2_ls;
    regval &= ~(PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_EN | PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_EN);
    regval |= (PDSS_INTR1_CFG_CC1_CC2_LS_CC1_FILT_BYPASS | PDSS_INTR1_CFG_CC1_CC2_LS_CC2_FILT_BYPASS);
    pd->intr1_cfg_cc1_cc2_ls = regval;

    regval = pd->intr1_cfg_vcmp_up_down_ls;
    regval &= ~(PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_EN | PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_EN);
    regval |= (PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_UP_FILT_BYPASS | PDSS_INTR1_CFG_VCMP_UP_DOWN_LS_VCMP_DN_FILT_BYPASS);
    pd->intr1_cfg_vcmp_up_down_ls = regval;

    /* Set LA config for wakeup */
    pd->intr1_cfg |= PDSS_INTR1_CFG_VCMP_LA_CFG_MASK;

    /* Enable the filter associated with CC1/2 OVP detection. */
    pd->intr1_cfg_cc12_ovp_hs = (
            (4 << PDSS_INTR1_CFG_CC12_OVP_HS_CC1_OVP_FILT_SEL_POS) |
            (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR1_CFG_CC12_OVP_HS_CC1_OVP_FILT_CFG_POS) |
            (PDSS_INTR1_CFG_CC12_OVP_HS_CC1_OVP_DPSLP_MODE) |
            (4 << PDSS_INTR1_CFG_CC12_OVP_HS_CC2_OVP_FILT_SEL_POS) |
            (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR1_CFG_CC12_OVP_HS_CC2_OVP_FILT_CFG_POS) |
            (PDSS_INTR1_CFG_CC12_OVP_HS_CC2_OVP_DPSLP_MODE)
            );
    pd->intr1_cfg_cc12_ovp_hs |= (
            PDSS_INTR1_CFG_CC12_OVP_HS_CC1_OVP_FILT_EN |
            PDSS_INTR1_CFG_CC12_OVP_HS_CC2_OVP_FILT_EN
            );

    /* Clear and Enable CC1/2 OVP change interrupt. */
    pd->intr1       = (PDSS_INTR1_CC1_OVP_CHANGED | PDSS_INTR1_CC2_OVP_CHANGED);
    pd->intr1_mask |= (PDSS_INTR1_MASK_CC1_OVP_CHANGED_MASK | PDSS_INTR1_MASK_CC2_OVP_CHANGED_MASK);

    /* If OVP condition is present, set the interrupt again. */
    if ((pd->intr1_status & PDSS_INTR1_STATUS_CC1_OVP_FILT) != 0)
        pd->intr1_set |= PDSS_INTR1_SET_CC1_OVP_CHANGED;
    if ((pd->intr1_status & PDSS_INTR1_STATUS_CC2_OVP_FILT) != 0)
        pd->intr1_set |= PDSS_INTR1_SET_CC2_OVP_CHANGED;

    /* Enable the SBU OVP filters. */
    pd->intr3_cfg_sbu20_ovp_hs = (
            (4 << PDSS_INTR3_CFG_SBU20_OVP_HS_SBU1_FILT_SEL_POS) |
            (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR3_CFG_SBU20_OVP_HS_SBU1_FILT_CFG_POS) |
            (PDSS_INTR3_CFG_SBU20_OVP_HS_SBU1_DPSLP_MODE) |
            (4 << PDSS_INTR3_CFG_SBU20_OVP_HS_SBU2_FILT_SEL_POS) |
            (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR3_CFG_SBU20_OVP_HS_SBU2_FILT_CFG_POS) |
            (PDSS_INTR3_CFG_SBU20_OVP_HS_SBU2_DPSLP_MODE)
            );
    pd->intr3_cfg_sbu20_ovp_hs |= (
            PDSS_INTR3_CFG_SBU20_OVP_HS_SBU1_FILT_EN |
            PDSS_INTR3_CFG_SBU20_OVP_HS_SBU2_FILT_EN
            );

    /* Enable OVP detection on the SBU pins. */
    pd->intr3       = PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK;
    pd->intr3_mask |= PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK;

#if CCGX_V5V_CHANGE_DETECT
    /* Enable the V5V detect comparator. */
    pd->vconn20_ctrl |= PDSS_VCONN20_CTRL_EN_COMP;

    /* Enable the V5V detect filter. */
    pd->intr1_cfg     = (pd->intr1_cfg & ~(PDSS_INTR1_CFG_V5V_FILT_EN |
                PDSS_INTR1_CFG_V5V_CFG_MASK | PDSS_INTR1_CFG_V5V_FILT_BYPASS));
    pd->intr1_cfg    |= PDSS_INTR1_CFG_V5V_CFG_MASK;
    CyDelayUs (10);
    pd->intr1_cfg    |= PDSS_INTR1_CFG_V5V_FILT_EN;

    /* Clear and enable the V5V change interrupt. */
    pd->intr1       = PDSS_INTR1_V5V_CHANGED;
    pd->intr1_mask |= PDSS_INTR1_MASK_V5V_CHANGED_MASK;
#endif /* CCGX_V5V_CHANGE_DETECT */


#if CCG_PD_DUALPORT_ENABLE
    pdss_active_ports |= (1 << port);
#endif

    return CCG_STAT_SUCCESS;
}

void pd_typec_rd_enable(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t temp;

    pd->dpslp_ref_ctrl &= ~PDSS_DPSLP_REF_CTRL_PD_DPSLP;
#if CCG_PD_DUALPORT_ENABLE
    if (port == 1)
    {
        /* Deep sleep reference has to be enabled on PD0 block. */
        gl_pdss[0]->dpslp_ref_ctrl &= ~PDSS_DPSLP_REF_CTRL_PD_DPSLP;
    }
#endif

    /* Power up the block. */
    pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_PWR_DISABLE;
    pd->cc_ctrl_0 |= (PDSS_CC_CTRL_0_CMP_EN | PDSS_CC_CTRL_0_RX_EN);

    /* Enable Rd on both CC lines. */
    temp = pd->cc_ctrl_0;
    temp |= (PDSS_CC_CTRL_0_RD_CC1_EN | PDSS_CC_CTRL_0_RD_CC1_DB_DIS);
    temp |= (PDSS_CC_CTRL_0_RD_CC2_EN | PDSS_CC_CTRL_0_RD_CC2_DB_DIS);
    temp &= ~PDSS_CC_CTRL_0_DFP_EN;
    pd->cc_ctrl_0 = temp;
}

ccg_status_t pd_typec_stop(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

#if CCGX_V5V_CHANGE_DETECT
    /* Clear and disable the V5V change detect interrupt. */
    pd->intr1       = PDSS_INTR1_V5V_CHANGED;
    pd->intr1_mask &= ~PDSS_INTR1_MASK_V5V_CHANGED_MASK;

    /* Disable and bypass the V5V detect filter. */
    pd->intr1_cfg = (pd->intr1_cfg & ~(PDSS_INTR1_CFG_V5V_FILT_EN |
                PDSS_INTR1_CFG_V5V_CFG_MASK | PDSS_INTR1_CFG_V5V_FILT_BYPASS));
    CyDelayUs (10);
    pd->intr1     = PDSS_INTR1_V5V_CHANGED;
#endif /* CCGX_V5V_CHANGE_DETECT */

    /* Clear and disable SBU OVP detect interrupts. */
    pd->intr3_mask &= ~(PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK);
    pd->intr3       = PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK;
    pd->intr3_cfg_sbu20_ovp_hs &= ~(
            PDSS_INTR3_CFG_SBU20_OVP_HS_SBU1_FILT_EN |
            PDSS_INTR3_CFG_SBU20_OVP_HS_SBU2_FILT_EN
            );

    /* Clear and disable CC1/2 OVP change interrupt. */
    pd->intr1       = (PDSS_INTR1_CC1_OVP_CHANGED | PDSS_INTR1_CC2_OVP_CHANGED);
    pd->intr1_mask &= ~(PDSS_INTR1_MASK_CC1_OVP_CHANGED_MASK | PDSS_INTR1_MASK_CC2_OVP_CHANGED_MASK);

    pd->intr1_cfg_cc12_ovp_hs &= ~(
            PDSS_INTR1_CFG_CC12_OVP_HS_CC1_OVP_FILT_EN |
            PDSS_INTR1_CFG_CC12_OVP_HS_CC2_OVP_FILT_EN
            );

    /* Power down the block. */
    pd->cc_ctrl_0 |= PDSS_CC_CTRL_0_PWR_DISABLE;

    /* Disable PUMP */
#if CCG_PD_DUALPORT_ENABLE
    pdss_active_ports &= ~(1 << port);
    if (pdss_active_ports == 0)
#endif /* CCG_PD_DUALPORT_ENABLE */
    {
        ccg5_pump_disable (0, 0);
    }

#if (CCG_PD_DUALPORT_ENABLE)
    if (pdss_active_ports == 0)
#endif /* CCG_PD_DUALPORT_ENABLE */
    {
        /* Turn off references. */
        pd->dpslp_ref_ctrl |= PDSS_DPSLP_REF_CTRL_PD_DPSLP;
    }

    return CCG_STAT_SUCCESS;
}

#if (!(CCG_SOURCE_ONLY))
void pd_typec_snk_update_trim(uint8_t port)
{
    PPDSS_TRIMS_REGS_T trimregs;
    dpm_status_t *dpm_stat = dpm_get_status(port);

#if CCG_PD_DUALPORT_ENABLE
    if (port != 0)
        trimregs = PDSS_TRIMS1;
    else
        trimregs = PDSS_TRIMS0;
#else
    trimregs = PDSS_TRIMS0;
#endif /* CCG_PD_DUALPORT_ENABLE */

    if (dpm_stat->cur_port_role == PRT_ROLE_SINK)
    {
        trimregs->trim_cc_0 &= ~PDSS_TRIM_CC_0_TX_TRIM_MASK;

        if (dpm_stat->snk_cur_level == RD_3A)
        {
            /* Use faster slew rate when 3A Rp is in use. */
            trimregs->trim_cc_0 |= (TRIM0_TX_TRIM_VALUE_3A << PDSS_TRIM_CC_0_TX_TRIM_POS);
        }
    }
}
#endif /* (!(CCG_SOURCE_ONLY)) */

void pd_typec_en_rp(uint8_t port, uint8_t channel, rp_term_t rp_val)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t rp_mode;
    uint32_t temp;
    rp_mode = rp_val;

    PPDSS_TRIMS_REGS_T trimregs;
    uint8_t cc_trim = 0;

    /* Enable PUMP */
    /* PUMP enable is done through Port0 for both ports. */
    ccg5_pump_enable (0, 0);

    if (port == TYPEC_PORT_0_IDX)
    {
        cc_trim = pdss_rp_trim_db_0[rp_val];

        trimregs = PDSS_TRIMS0;
    }
#if CCG_PD_DUALPORT_ENABLE
    else
    {
        cc_trim = pdss_rp_trim_db_1[rp_val];
        trimregs = PDSS_TRIMS1;
    }
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */

    /* Set cc trim from sflash */
    if (channel == CC_CHANNEL_1)
    {
        trimregs->trim_cc_1 = cc_trim;
    }
    else
    {
        trimregs->trim_cc_2 = cc_trim;
    }

    /* Do the TX trim only for CCG5. */
    trimregs->trim_cc_0 &= ~PDSS_TRIM_CC_0_TX_TRIM_MASK;
    if (rp_val == RP_TERM_RP_CUR_3A)
    {
        /* Actual value in HW register for 3A Rp is (RP_TERM_RP_CUR_3A + 1) */
        rp_mode++;

        /* Use faster slew rate when 3A Rp is in use. */
        trimregs->trim_cc_0 |= (TRIM0_TX_TRIM_VALUE_3A << PDSS_TRIM_CC_0_TX_TRIM_POS);
    }

    /* Set Rp mode and enable references for source operation. */
    temp = pd->cc_ctrl_0;
    temp &= ~PDSS_CC_CTRL_0_RP_MODE_MASK;
    temp |= (rp_mode << PDSS_CC_CTRL_0_RP_MODE_POS) | PDSS_CC_CTRL_0_DFP_EN;

    if (channel == CC_CHANNEL_1)
    {
        temp |= PDSS_CC_CTRL_0_RP_CC1_EN;
    }
    else
    {
        temp |= PDSS_CC_CTRL_0_RP_CC2_EN;
    }
    pd->cc_ctrl_0 = temp;
}

void pd_typec_dis_rp(uint8_t port, uint8_t channel)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (channel == CC_CHANNEL_1)
    {
        pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_RP_CC1_EN;
    }
    else
    {
        pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_RP_CC2_EN;
    }
}

void pd_typec_en_dpslp_rp(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    pd->cc_ctrl_1 |= PDSS_CC_CTRL_1_DS_ATTACH_DET_EN;
}

void pd_typec_dis_dpslp_rp(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    pd->cc_ctrl_1 &= ~PDSS_CC_CTRL_1_DS_ATTACH_DET_EN;
}

void pd_typec_en_deadbat_rd(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t temp;

    temp = pd->cc_ctrl_0;

    /* Re-enable dead battery Rd */
    temp &= ~(PDSS_CC_CTRL_0_RD_CC1_DB_DIS | PDSS_CC_CTRL_0_RD_CC2_DB_DIS);

    /* Remove trimmed Rd */
    temp &= ~(PDSS_CC_CTRL_0_RD_CC1_EN | PDSS_CC_CTRL_0_RD_CC2_EN);

    pd->cc_ctrl_0 = temp;
}

void pd_typec_en_rd(uint8_t port, uint8_t channel)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t temp;

    /* Disable PUMP */
#if (!CCG_PD_DUALPORT_ENABLE)
    ccg5_pump_disable (0, 0);
#endif /* (!CCG_PD_DUALPORT_ENABLE) */

    temp = pd->cc_ctrl_0;
    if (channel == CC_CHANNEL_1)
    {
        temp |= (PDSS_CC_CTRL_0_RD_CC1_EN | PDSS_CC_CTRL_0_RD_CC1_DB_DIS);
    }
    else
    {
        temp |= (PDSS_CC_CTRL_0_RD_CC2_EN | PDSS_CC_CTRL_0_RD_CC2_DB_DIS);
    }

    temp &= ~PDSS_CC_CTRL_0_DFP_EN;
    pd->cc_ctrl_0 = temp;
}

void pd_typec_dis_rd(uint8_t port, uint8_t channel)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval =  pd->cc_ctrl_0;

    if (channel == CC_CHANNEL_1)
    {
        regval &= ~PDSS_CC_CTRL_0_RD_CC1_EN;
        regval |= PDSS_CC_CTRL_0_RD_CC1_DB_DIS;
    }
    else
    {
        regval &= ~PDSS_CC_CTRL_0_RD_CC2_EN;
        regval |= PDSS_CC_CTRL_0_RD_CC2_DB_DIS;
    }
    pd->cc_ctrl_0 = regval;
}

/* Returns the current status on the CC line (rp_cc_status_t or rd_cc_status_t). */
static uint8_t pd_typec_get_rp_rd_status(uint8_t port, uint8_t channel, bool rd_idx)
{
    dpm_status_t* dpm_stat = dpm_get_status(port);
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t rval = 0;
    uint32_t temp;
    uint8_t  out;
    bool     is_src = true;

    /* Set default output. */
    if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
    {
        out = RP_OPEN;
    }
    else
    {
        out = RD_RA + rd_idx;
        is_src = false;
    }

    /* Connect both the Up/Dn comparators to the active CC line. */
    if (channel == CC_CHANNEL_2)
    {
        rval = (PDSS_CC_CTRL_0_CMP_DN_CC1V2 | PDSS_CC_CTRL_0_CMP_UP_CC1V2);
    }

    if (is_src)
    {
        /*
         * Set the threshold of the Dn comparator to Ra level and the Up
         * comparator to Rp open level.
         */
        rval |= ((thresholds[dpm_stat->src_cur_level_live][0]) << PDSS_CC_CTRL_0_CMP_DN_VSEL_POS) |
            ((thresholds[dpm_stat->src_cur_level_live][1]) << PDSS_CC_CTRL_0_CMP_UP_VSEL_POS);
    }
    else
    {
        /* Set the Dn comparator to vRdUSB and the Up comparator to vRd1.5A. */
        rval |= ((thresholds[RD_ROW_NO][rd_idx]) << PDSS_CC_CTRL_0_CMP_DN_VSEL_POS) |
            ((thresholds[RD_ROW_NO][rd_idx + 1]) << PDSS_CC_CTRL_0_CMP_UP_VSEL_POS);
    }

    temp = pd->cc_ctrl_0 & (PDSS_CC_CTRL_0_CMP_DN_CC1V2 | PDSS_CC_CTRL_0_CMP_UP_CC1V2 |
            PDSS_CC_CTRL_0_CMP_DN_VSEL_MASK | PDSS_CC_CTRL_0_CMP_UP_VSEL_MASK);
    if (temp != rval)
    {
        pd->cc_ctrl_0 &= ~(PDSS_CC_CTRL_0_CMP_DN_CC1V2 | PDSS_CC_CTRL_0_CMP_UP_CC1V2 |
                PDSS_CC_CTRL_0_CMP_DN_VSEL_MASK | PDSS_CC_CTRL_0_CMP_UP_VSEL_MASK);
        pd->cc_ctrl_0 |= rval;

        /* Delay to allow references to settle. */
        CyDelayUs (50);
    }

    temp = (pd->intr1_status & (PDSS_INTR1_STATUS_VCMP_DN_STATUS | PDSS_INTR1_STATUS_VCMP_UP_STATUS));
    if ((temp & PDSS_INTR1_STATUS_VCMP_UP_STATUS) != 0)
    {
        if (!is_src)
        {
            out = RD_1_5A + rd_idx;
        }
    }
    else
    {
        if ((temp & PDSS_INTR1_STATUS_VCMP_DN_STATUS) != 0)
        {
            if (is_src)
            {
                out = RP_RD;
            }
            else
            {
                out = RD_USB + rd_idx;
            }
        }
        else
        {
            if (is_src)
            {
                out = RP_RA;
            }
        }
    }

    return out;
}

cc_state_t pd_typec_get_cc_status(uint8_t port)
{
    dpm_status_t* dpm_stat = dpm_get_status(port);
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t polarity = dpm_stat->polarity;
    cc_state_t new_state;
    uint8_t i;

    /* If the CC TX/RX is busy, retain previously detected CC status. */
    new_state = dpm_stat->cc_old_status;
    if ((dpm_stat->attach) && (pd->status & (PDSS_STATUS_TX_BUSY | PDSS_STATUS_CC_DATA_VALID)))
    {
        return new_state;
    }

    if (dpm_stat->cur_port_role == PRT_ROLE_SOURCE)
    {
        /* Scan both CC lines: the active CC line should be scanned last. */
        new_state.cc[1 - polarity] = pd_typec_get_rp_rd_status(port, 1 - polarity, 0);
        new_state.cc[polarity]     = pd_typec_get_rp_rd_status(port, polarity, 0);

        if (gl_pdss_status[port].cc_ovp_pending)
        {
            if (new_state.cc[polarity] == RP_OPEN)
            {
                /* Keep returning RP_RD status while OVP is active. */
                new_state.cc[polarity] = RP_RD;
            }
            else
            {
                /* Re-enable the Rp termination and mark OVP not active. */
                pd_typec_en_rp(port, polarity, (rp_term_t)dpm_stat->src_cur_level_live);
                gl_pdss_status[port].cc_ovp_pending = false;
            }
        }
    }
    else
    {
        if (dpm_stat->attach == true)
        {
            if (new_state.cc[polarity] > RD_USB)
            {
                new_state.cc[polarity] = pd_typec_get_rp_rd_status(port, polarity, 1);
            }

            /* If CC line voltage is below the 1.5 A Rp threshold, do another check for presence of Rp. */
            if (new_state.cc[polarity] <= RD_USB)
            {
                new_state.cc[polarity] = pd_typec_get_rp_rd_status(port, polarity, 0);
            }

            /* Only the active CC line needs to be scanned. */
            new_state.cc[dpm_stat->rev_pol] = RD_RA;
        }
        else
        {
            for (i = 0; i < 2; i++)
            {
                /* Scan CC[i] with threshold vRa and vRdUsb. */
                new_state.cc[i] = pd_typec_get_rp_rd_status(port, i, 0);
                if (new_state.cc[i] != RD_RA)
                {
                    /* Scan CC[i] again with vRdusb and vRd1.5A to determine correct Rp value. */
                    new_state.cc[i] = pd_typec_get_rp_rd_status(port, i, 1);
                }
            }
        }
    }

    return new_state;
}

void pd_typec_set_polarity (uint8_t port, bool polarity)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (polarity == 0)
    {
        pd->cc_ctrl_0 &= ~PDSS_CC_CTRL_0_CC_1V2;
    }
    else
    {
        pd->cc_ctrl_0 |= PDSS_CC_CTRL_0_CC_1V2;
    }
}

bool pd_is_v5v_supply_on(uint8_t port)
{
    bool stat = true;

#if CCGX_V5V_CHANGE_DETECT
    PPDSS_REGS_T pd = gl_pdss[port];

    /* If V5V is not present, return error. */
    if ((pd->intr1_status & PDSS_INTR1_STATUS_V5V_STATUS) == 0)
        stat = false;
#endif /* CCGX_V5V_CHANGE_DETECT */

    return stat;
}

ccg_status_t pd_vconn_enable(uint8_t port, uint8_t channel)
{

    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;

#if CCGX_V5V_CHANGE_DETECT
    /* If V5V is not present, return error. */
    if ((pd->intr1_status & PDSS_INTR1_STATUS_V5V_STATUS) == 0)
        return CCG_STAT_FAILURE;
#endif /* CCGX_V5V_CHANGE_DETECT */

    /* Check whether VConn has already been turned ON. */
    if (pd_is_vconn_present(port, channel))
        return CCG_STAT_SUCCESS;

    /* Turn on the VConn switch. */
    if (channel == CC_CHANNEL_1)
    {
        regval = pd->vconn20_cc1_switch_1_ctrl;
        regval |= PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_ON_OFF |
            PDSS_VCONN20_CC1_SWITCH_1_CTRL_EN_SWITCH_CC1_ON_VALUE |
            PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_CC1_OVP |
            PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_CC2_OVP;
        pd->vconn20_cc1_switch_1_ctrl = regval;

        /* Reset edge detector. */
        pd->vconn20_cc1_switch_1_ctrl |= PDSS_VCONN20_CC1_SWITCH_1_CTRL_RST_EDGE_DET;
        pd->vconn20_cc1_switch_1_ctrl &= ~PDSS_VCONN20_CC1_SWITCH_1_CTRL_RST_EDGE_DET;
    }
    else
    {
        regval = pd->vconn20_cc2_switch_1_ctrl;
        regval |= PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_ON_OFF |
            PDSS_VCONN20_CC2_SWITCH_1_CTRL_EN_SWITCH_CC2_ON_VALUE |
            PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_CC1_OVP |
            PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_CC2_OVP;
        pd->vconn20_cc2_switch_1_ctrl = regval;

        /* Reset edge detector. */
        pd->vconn20_cc2_switch_1_ctrl |= PDSS_VCONN20_CC2_SWITCH_1_CTRL_RST_EDGE_DET;
        pd->vconn20_cc2_switch_1_ctrl &= ~PDSS_VCONN20_CC2_SWITCH_1_CTRL_RST_EDGE_DET;
    }

    /* Turn on the VConn pump. */
    regval = pd->vconn20_pump_en_1_ctrl;
    regval |= PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_ON_OFF | PDSS_VCONN20_PUMP_EN_1_CTRL_EN_VCONN20_PUMP_ON_VALUE |
        PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_CC1_OVP | PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_CC2_OVP;
    pd->vconn20_pump_en_1_ctrl = regval;


    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_vconn_disable(uint8_t port, uint8_t channel)
{


    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;

    /* Check whether VConn has already been turned OFF. */
    if (!pd_is_vconn_present(port, channel))
        return CCG_STAT_SUCCESS;

    /* Turn off the VConn pump. */
    regval = pd->vconn20_pump_en_1_ctrl;
    regval &= ~(PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_ON_OFF | PDSS_VCONN20_PUMP_EN_1_CTRL_EN_VCONN20_PUMP_ON_VALUE |
            PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_CC1_OVP | PDSS_VCONN20_PUMP_EN_1_CTRL_SEL_CC2_OVP);
    pd->vconn20_pump_en_1_ctrl = regval;

    /* Adding a small delay. */
    CyDelayUs (10);

    /* Turn off the VConn switch. */
    if (channel == CC_CHANNEL_1)
    {
        regval = pd->vconn20_cc1_switch_1_ctrl;
        regval &= ~(PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_ON_OFF | PDSS_VCONN20_CC1_SWITCH_1_CTRL_EN_SWITCH_CC1_ON_VALUE |
                PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_CC1_OVP);
        pd->vconn20_cc1_switch_1_ctrl = regval;

        /* Reset edge detector. */
        pd->vconn20_cc1_switch_1_ctrl |= PDSS_VCONN20_CC1_SWITCH_1_CTRL_RST_EDGE_DET;
        pd->vconn20_cc1_switch_1_ctrl &= ~PDSS_VCONN20_CC1_SWITCH_1_CTRL_RST_EDGE_DET;
    }
    else
    {
        regval = pd->vconn20_cc2_switch_1_ctrl;
        regval &= ~(PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_ON_OFF | PDSS_VCONN20_CC2_SWITCH_1_CTRL_EN_SWITCH_CC2_ON_VALUE |
                PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_CC2_OVP);
        pd->vconn20_cc2_switch_1_ctrl = regval;

        /* Reset edge detector. */
        pd->vconn20_cc2_switch_1_ctrl |= PDSS_VCONN20_CC2_SWITCH_1_CTRL_RST_EDGE_DET;
        pd->vconn20_cc2_switch_1_ctrl &= ~PDSS_VCONN20_CC2_SWITCH_1_CTRL_RST_EDGE_DET;
    }


    return CCG_STAT_SUCCESS;
}

bool pd_is_vconn_present(uint8_t port, uint8_t channel)
{
    bool retval = true;


    PPDSS_REGS_T pd = gl_pdss[port];

    /* Check whether the V5V -> VConn Switch is ON. */
    if (channel == CC_CHANNEL_1)
    {
        retval = ((pd->vconn20_cc1_switch_1_ctrl & PDSS_VCONN20_CC1_SWITCH_1_CTRL_SEL_ON_OFF) != 0);
    }
    else
    {
        retval = ((pd->vconn20_cc2_switch_1_ctrl & PDSS_VCONN20_CC2_SWITCH_1_CTRL_SEL_ON_OFF) != 0);
    }

    return retval;
}

ccg_status_t hpd_receive_init(uint8_t port, hpd_event_cbk_t cbk)
{
#if CCG_HPD_RX_ENABLE
    PPDSS_REGS_T pd;

    if (cbk == NULL)
    {
        return CCG_STAT_BAD_PARAM;
    }

    if ((hpd_transmit_enable[port]) || (hpd_receive_enable[port]))
    {
        return CCG_STAT_BUSY;
    }

    /* PD block should have been enabled. */
    pd = gl_pdss[port];
    if ((pd->ctrl & PDSS_CTRL_IP_ENABLED) == 0)
    {
        return CCG_STAT_NOT_READY;
    }

    /* Store the callback pointer. */
    hpd_cbks[port] = cbk;
    hpd_receive_enable[port] = true;

    /* Configure the relevant GPIO for HPD functionality. */
    if (port == 0)
    {
        CALL_IN_FUNCTION(gpio_set_drv_mode)(HPD_P0_PORT_PIN, GPIO_DM_HIZ_DIGITAL);
        CALL_IN_FUNCTION(hsiom_set_config)(HPD_P0_PORT_PIN, HPD_HSIOM_SETTING);
    }
    else
    {
        CALL_IN_FUNCTION(gpio_set_drv_mode)(HPD_P1_PORT_PIN, GPIO_DM_HIZ_DIGITAL);
        CALL_IN_FUNCTION(hsiom_set_config)(HPD_P1_PORT_PIN, HPD_HSIOM_SETTING);
    }

    /* Set the default values for the HPD config settings. */
    pd->hpd_ctrl1 = PDSS_HPD_CTRL1_DEFAULT_VALUE;
    pd->hpd_ctrl2 = PDSS_HPD_CTRL2_DEFAULT;
    pd->hpd_ctrl3 = PDSS_HPD_CTRL3_DEFAULT_VALUE;
    pd->hpd_ctrl4 = PDSS_HPD_CTRL4_DEFAULT;
    pd->hpd_ctrl5 = PDSS_HPD_CTRL5_DEFAULT;

    pd->hpd_queue = pd->hpd_queue;

    /* Enable the HPD queue interrupt. */
    pd->intr2 = PDSS_INTR2_MASK_HPD_QUEUE_MASK;
    pd->intr2_mask |= PDSS_INTR2_MASK_HPD_QUEUE_MASK;

    /*
     * CDT 245126 workaround.
     * Enable the HPDIN_CHANGE interrupt with both edge detection. As HPD module
     * can't detect HPD events across deep sleep, this interrupt is used to ensure
     * that device doesn't go back to deepsleep after HPD status changes.
     * HPD RX activity timer is started when this interrupt fires and device
     * doesn't go back to deep sleep until timer is running or a queue interrupt
     * fires.
     */
    pd->intr1_cfg |= (3 << PDSS_INTR1_CFG_HPDIN_CFG_POS);
    /* Disable HPD IN filter. */
    pd->intr1_cfg &= ~(PDSS_INTR1_CFG_HPDIN_FILT_EN);
    /* Clear and then enable the interrupt. */
    pd->intr1 = PDSS_INTR1_HPDIN_CHANGED;
    pd->intr1_mask |= PDSS_INTR1_HPDIN_CHANGED;

    /* Enable the HPD function and the bring the HPD receiver out of reset. */
    pd->ctrl = (pd->ctrl & ~(PDSS_CTRL_HPD_DIRECTION | PDSS_CTRL_HPDT_ENABLED)) |
        PDSS_CTRL_HPD_ENABLED;
    pd->hpd_ctrl1 &= ~(PDSS_HPD_CTRL1_RESET_HPD_STATE);
#endif /* CCG_HPD_RX_ENABLE */

    return CCG_STAT_SUCCESS;
}

ccg_status_t hpd_transmit_init(uint8_t port, hpd_event_cbk_t cbk)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (hpd_transmit_enable[port])
    {
        return CCG_STAT_BUSY;
    }

    /* Store the callback pointer. */
    hpd_cbks[port] = cbk;
    hpd_transmit_enable[port] = true;

    /* Configure the relevant GPIO for HPD functionality. */
    if (port == 0)
    {
        CALL_IN_FUNCTION(gpio_set_drv_mode)(HPD_P0_PORT_PIN, GPIO_DM_STRONG);
        CALL_IN_FUNCTION(hsiom_set_config)((gpio_port_pin_t)HPD_P0_PORT_PIN, (hsiom_mode_t)HPD_HSIOM_SETTING);
    }
    else
    {
        CALL_IN_FUNCTION(gpio_set_drv_mode)(HPD_P1_PORT_PIN, GPIO_DM_STRONG);
        CALL_IN_FUNCTION(hsiom_set_config)((gpio_port_pin_t)HPD_P1_PORT_PIN, (hsiom_mode_t)HPD_HSIOM_SETTING);
    }

    /* Set the default values for the HPDT config settings. */
    pd->hpdt_ctrl1 = PDSS_HPDT_CTRL1_DEFAULT;
    pd->hpdt_ctrl2 = PDSS_HPDT_CTRL2_DEFAULT;

    /* Enable the HPD queue interrupt. */
    pd->intr2 = PDSS_INTR2_MASK_HPDT_COMMAND_DONE_MASK;
    pd->intr2_mask |= PDSS_INTR2_MASK_HPDT_COMMAND_DONE_MASK;

    /* Enable the HPDT function and the bring the HPD transmitter out of reset. */
    pd->ctrl = (pd->ctrl & ~(PDSS_CTRL_HPD_ENABLED)) |
        PDSS_CTRL_HPDT_ENABLED | PDSS_CTRL_HPD_DIRECTION;
    pd->hpdt_ctrl1 &= ~(PDSS_HPDT_CTRL1_RESET_HPDT_STATE);

    return CCG_STAT_SUCCESS;
}

void hpd_sleep_entry(uint8_t port)
{
    /* Configure the relevant pin for GPIO functionality. */
    if (hpd_transmit_enable[port])
    {
        if (port == 0)
        {
            CALL_IN_FUNCTION(hsiom_set_config)(HPD_P0_PORT_PIN, HSIOM_MODE_GPIO);
        }
        else
        {
            CALL_IN_FUNCTION(hsiom_set_config)(HPD_P1_PORT_PIN, HSIOM_MODE_GPIO);
        }
    }
}

void hpd_wakeup(uint8_t port, bool value)
{
    PPDSS_REGS_T pd;

    /* PD block should be turned on already. */
    pd = gl_pdss[port];

    /* Configure the relevant GPIO for HPD functionality. */
    if (hpd_transmit_enable[port])
    {
        /* Set the default values for the HPDT config settings. */
        if (value)
        {
            /* Start HPD off in the high state and queue a PLUG event. */
            pd->hpdt_ctrl1 = PDSS_HPDT_CTRL1_DEFAULT | PDSS_HPDT_CTRL1_DEFAULT_LEVEL;
            pd->hpdt_ctrl2 = PDSS_HPDT_CTRL2_DEFAULT;
        }
        else
        {
            /* Start HPD off in the low state. */
            pd->hpdt_ctrl1 = PDSS_HPDT_CTRL1_DEFAULT;
            pd->hpdt_ctrl2 = PDSS_HPDT_CTRL2_DEFAULT;
        }

        /*
         * Bring the HPDT block out of reset. We need a small delay here to
         * ensure that there is no glitch on the HPD line.
         */
        CyDelayUs(5);
        pd->hpdt_ctrl1 &= ~(PDSS_HPDT_CTRL1_RESET_HPDT_STATE);

        if (port == 0)
        {
            CALL_IN_FUNCTION(hsiom_set_config)((gpio_port_pin_t)HPD_P0_PORT_PIN, (hsiom_mode_t)HPD_HSIOM_SETTING);
        }
        else
        {
            CALL_IN_FUNCTION(hsiom_set_config)((gpio_port_pin_t)HPD_P1_PORT_PIN, (hsiom_mode_t)HPD_HSIOM_SETTING);
        }
    }
}

#if CCG_HPD_RX_ENABLE
/*
 * CDT 245126 workaround.
 * This routine implements the workaround before entering deep sleep.
 *
 * Details:
 * HPD RX module can't detect HPD High to Low and IRQ transitions across
 * deepsleep. Workaround is this:
 *
 * Before entering deepsleep, check if HPD is high. If yes, enable HPD
 * TX module with default value of HIGH. Enable HPD loopback. Configure HPD
 * RX to detect a high with minimum time possible (<50us). After this enter
 * deepsleep. Once device enters deep sleep, HPD RX module loses all memory.
 * Now, when HPD goes low, HPD IN wakeup interrupt will wake up the device.
 * HPD RX module starts with HPD RX status as LOW. Due to loopback enabled and HPD
 * TX driving high, HPD RX will see HPD Connect event. Then disable the loopback
 * and revert HPD RX settings. From this point, HPD RX will look at actual
 * HPD status and will capture HPD events correctly.
 *
 * FW also uses a HPD RX activity timer. Whenever HPD IN interrupt fires, start this
 * timer with maximum HPD event time period. This is currently set to 5ms and can be fine
 * tuned if required. This ensures that on any HPD activity, device remains active
 * till the HPD event is captured in HPD RX queue. Stop the timer once HPD Queue
 * interrupt fires.
 */

/*
 * This flag keeps track of HPD Connection status. It is used in HPD CHANGE wakeup
 * interrupt.
 */
bool gl_hpd_state = false;

void hpd_rx_sleep_entry(uint8_t port, bool hpd_state)
{
    PPDSS_REGS_T pd;
    pd = gl_pdss[port];

    /* Store HPD Connection status. */
    gl_hpd_state = hpd_state;

    if (hpd_receive_enable[port])
    {
        /* If HPD is connected, implement the CDT 245126 workaround. */
        if (hpd_state)
        {
            /* Ensure default level of HPD TX is high. */
            pd->hpdt_ctrl1 |= PDSS_HPDT_CTRL1_DEFAULT_LEVEL;
            /* Enable HPD TX. */
            pd->ctrl |= PDSS_CTRL_HPDT_ENABLED;

            /* Enable HPD loop back. */
            pd->hpd_ctrl1 |= PDSS_HPD_CTRL1_LOOPBACK_EN;

            /* Update HPD RX Stable High minimum time to a very small value (<50us) */
            pd->hpd_ctrl3 = ((pd->hpd_ctrl3 & ~PDSS_HPD_CTRL3_STABLE_HIGH_MASK)
                | (1 << PDSS_HPD_CTRL3_STABLE_HIGH_POS));
            pd->hpd_ctrl5 = ((pd->hpd_ctrl5 & ~PDSS_HPD_CTRL5_LONG_HIGH_MASK)
                | (1 << PDSS_HPD_CTRL5_LONG_HIGH_POS));

            /*
             * Disable HPD Queue interrupt. There is no point in using Queue interrupt
             * for HPD high detection once device wakes up. We can poll for this.
             */
            pd->intr2 = PDSS_INTR2_HPD_QUEUE;
            pd->intr2_mask &= ~PDSS_INTR2_MASK_HPD_QUEUE_MASK;
        }
    }
}

/* CDT 245126 workaround: This routine implements the wakeup portion of workaround. */
void hpd_rx_wakeup(uint8_t port)
{
    PPDSS_REGS_T pd;
    pd = gl_pdss[port];
    uint8_t timeout = 0;

    if (hpd_receive_enable[port])
    {
        /* Revert the settings only if Loopback was enabled before entering deep sleep. */
        if (pd->hpd_ctrl1 & PDSS_HPD_CTRL1_LOOPBACK_EN)
        {
            /*
             * Wait for the HPD Queue connect event. This is the fake HPD Queue connect
             * event triggered due to CDT 245126 workaround. 20us wait is enough.
             */
            while ((HPD_GET_EVENT_0(pd->hpd_queue) != HPD_EVENT_PLUG) && (timeout < 20))
            {
                CyDelayUs (1);
                timeout++;
            }

            /* Ensure that HPD RX high time is reset back to default. */
            pd->hpd_ctrl3 = PDSS_HPD_CTRL3_DEFAULT_VALUE;
            pd->hpd_ctrl5 = PDSS_HPD_CTRL5_DEFAULT;
            /* Ensure that Loopback is disabled. */
            pd->hpd_ctrl1 &= ~PDSS_HPD_CTRL1_LOOPBACK_EN;
        }
        /* Enable the HPD Queue interrupt to capture true HPD interrupts from now on. */
        pd->intr2 = PDSS_INTR2_HPD_QUEUE;
        pd->intr2_mask |= PDSS_INTR2_MASK_HPD_QUEUE_MASK;
    }
}

bool is_hpd_rx_state_idle(uint8_t port)
{
    /* If timer is running, HPD RX module is busy. */
    return (!timer_is_running (port, HPD_RX_ACTIVITY_TIMER_ID));
}

#endif /* CCG_HPD_RX_ENABLE */

ccg_status_t hpd_deinit(uint8_t port)
{
    PPDSS_REGS_T pd;
    gpio_port_pin_t pin;

    if ((!hpd_transmit_enable[port]) && (!hpd_receive_enable[port]))
    {
        return CCG_STAT_FAILURE;
    }

    /* Disable all HPD related interrupts. */
    pd = gl_pdss[port];
    pd->intr2 = PDSS_INTR2_MASK_HPDT_COMMAND_DONE_MASK | PDSS_INTR2_MASK_HPD_QUEUE_MASK;
    pd->intr2_mask &= ~(PDSS_INTR2_MASK_HPD_QUEUE_MASK | PDSS_INTR2_MASK_HPDT_COMMAND_DONE_MASK);

    pd->intr1 = PDSS_INTR1_HPDIN_CHANGED;
    pd->intr1_mask &= ~PDSS_INTR1_MASK_HPDIN_CHANGED_MASK;

    /* Disable both HPD transmit and receive blocks. */
    pd->ctrl &= ~(PDSS_CTRL_HPDT_ENABLED | PDSS_CTRL_HPD_ENABLED);

    if (port == 0)
    {
        pin = HPD_P0_PORT_PIN;
    }
    else
    {
        pin = HPD_P1_PORT_PIN;
    }

    /* Revert the HPD pin to GPIO mode. */
    CALL_IN_FUNCTION(hsiom_set_config)(pin, HSIOM_MODE_GPIO);

    if (hpd_transmit_enable[port])
    {
        /* Make sure that the HPD signal is driven to zero. */
        CALL_IN_FUNCTION(gpio_set_value)(pin, 0);
    }

    hpd_cbks[port] = NULL;
    hpd_transmit_enable[port] = false;
    hpd_receive_enable[port] = false;

    return CCG_STAT_SUCCESS;
}

ccg_status_t hpd_transmit_sendevt(uint8_t port, hpd_event_type_t evtype,
        bool wait)
{
    PPDSS_REGS_T pd;
    uint32_t val = 0;

    /* Wait is currently not supported. */
    (void)wait;

    pd = gl_pdss[port];
    if ((pd->hpdt_ctrl1 & PDSS_HPDT_CTRL1_COMMAND_START) != 0)
    {
        return CCG_STAT_BUSY;
    }

    /* Update HPD-out as required. */
    switch (evtype)
    {
        case HPD_EVENT_UNPLUG:
            break;

        case HPD_EVENT_PLUG:
            val = 1;
            break;

        case HPD_EVENT_IRQ:
            val = 2;
            break;

        default:
            return CCG_STAT_BAD_PARAM;
    }

    pd->hpdt_ctrl1 = pd_hal_mmio_reg_update_field(pd->hpdt_ctrl1, val,
            PDSS_HPDT_CTRL1_COMMAND_MASK, PDSS_HPDT_CTRL1_COMMAND_POS);
    pd->hpdt_ctrl1 |= PDSS_HPDT_CTRL1_COMMAND_START;

    return CCG_STAT_SUCCESS;
}

/******************** PD block ADC functionality *****************************/

uint8_t pd_adc_volt_to_level(uint8_t port, PD_ADC_ID_T adc_id, uint16_t volt)
{
    uint32_t threshold;

    threshold = ((volt * PD_ADC_NUM_LEVELS) / gl_pdss_status[port].adc_vddd_mv[adc_id]);

    if (threshold < PD_ADC_LEVEL_MIN_THRESHOLD)
    {
        threshold = PD_ADC_LEVEL_MIN_THRESHOLD;
    }
    if (threshold > PD_ADC_LEVEL_MAX_THRESHOLD)
    {
        threshold = PD_ADC_LEVEL_MAX_THRESHOLD;
    }

    return (uint8_t)threshold;
}

uint16_t pd_adc_level_to_volt(uint8_t port, PD_ADC_ID_T adc_id, uint8_t level)
{
    uint32_t threshold;

    threshold = ((level * gl_pdss_status[port].adc_vddd_mv[adc_id]) / PD_ADC_NUM_LEVELS);

    return (uint16_t)threshold;
}

uint16_t pd_adc_get_vbus_voltage(uint8_t port, PD_ADC_ID_T adc_id, uint8_t level)
{
    uint32_t result;
    /* Unused in MX-IP */
    (void)port;
    (void)adc_id;

    /* We need to multiply PD_ADC_NUM_LEVELS by 2 as pd_vbus_mon_divider has been pre-multiplied by 2. */
    result = ((level * gl_pdss_status[port].adc_vddd_mv[adc_id] * pd_vbus_mon_divider)/(PD_ADC_NUM_LEVELS << 1u));
    return result;
}


uint8_t pd_get_vbus_adc_level(uint8_t port, PD_ADC_ID_T adc_id, uint16_t volt,
        int8_t per)
{
    int32_t threshold = apply_threshold(volt, per);

    /* Remove negative numbers. */
    if (threshold < 0)
    {
        threshold = 0;
    }

    /* Convert volts to ADC units. */
    return pd_adc_volt_to_level(port, adc_id, (2 * threshold / pd_vbus_mon_divider));
}

ccg_status_t  pd_adc_free_run_ctrl(uint8_t port, PD_ADC_ID_T adc_id, PD_ADC_INPUT_T input,
        uint8_t level)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Only one ADC supported by CCG5. */
    (void)adc_id;

    if (gl_pdss_status[port].adc_ref_vddd[adc_id])
        level |= PDSS_ADC_CTRL_VREF_DAC_SEL;


    /* Disable interrupts. */
    pd->intr3_mask &= ~PDSS_INTR3_CMP_OUT_CHANGED;
    pd->intr3 = PDSS_INTR3_CMP_OUT_CHANGED;

    /* Configure ADC */
    pd->adc_ctrl = level | PDSS_ADC_CTRL_ADC_ISO_N |
            ((input << PDSS_ADC_CTRL_VSEL_POS) & PDSS_ADC_CTRL_VSEL_MASK);

    return CCG_STAT_SUCCESS;
}


void pd_adc_comparator_ctrl(uint8_t port, PD_ADC_ID_T adc_id, PD_ADC_INPUT_T input,
        uint8_t level, PD_ADC_INT_T int_cfg, PD_ADC_CB_T cb)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;
    bool out;
    /* CCG5 has only one ADC. */
    (void)adc_id;

    state = CyEnterCriticalSection();
    gl_pdss_status[port].adc_cb[adc_id] = cb;

    if (gl_pdss_status[port].adc_ref_vddd[adc_id])
        level |= PDSS_ADC_CTRL_VREF_DAC_SEL;


    if (cb != NULL)
    {
        pd->intr3_cfg_adc_hs = pd_hal_mmio_reg_update_field(pd->intr3_cfg_adc_hs, int_cfg,
                PDSS_INTR3_CFG_ADC_HS_FILT_CFG_MASK, PDSS_INTR3_CFG_ADC_HS_FILT_CFG_POS);
        pd->adc_ctrl = level | PDSS_ADC_CTRL_ADC_ISO_N |
                        ((input << PDSS_ADC_CTRL_VSEL_POS) & PDSS_ADC_CTRL_VSEL_MASK);
        /* Delay 10us for the input selection to stabilize. */
        CyDelayUs(10);

        /* Clear comparator interrupts. */
        pd->intr3 = PDSS_INTR3_CMP_OUT_CHANGED;

        /* Enable comparator interrupts. */
        pd->intr3_mask |= PDSS_INTR3_CMP_OUT_CHANGED;

        if (pd->adc_ctrl & PDSS_ADC_CTRL_CMP_OUT)
        {
            out = true;
        }
        else
        {
            out = false;
        }
        if (((int_cfg ==  PD_ADC_INT_FALLING) && (out == false)) ||
            ((int_cfg ==  PD_ADC_INT_RISING) && (out == true)))
        {
            /* Raise an interrupt. */
            pd->intr3_set |= PDSS_INTR3_CMP_OUT_CHANGED;
        }
    }
    else
    {
        /* Revert register configuration. */
        pd->adc_ctrl = PDSS_ADC_CTRL_ADC_ISO_N | PDSS_ADC_CTRL_PD_LV;

        /* Disable interrupts. */
        pd->intr3_mask &= ~(PDSS_INTR3_CMP_OUT_CHANGED);
        pd->intr3 = PDSS_INTR3_CMP_OUT_CHANGED;
    }

    CyExitCriticalSection(state);
}

static void pd_adc_restore_intr(uint8_t port, PD_ADC_ID_T adc_id, uint32_t reg_adc_ctrl)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t rval;
    bool out;
    (void)adc_id;


    /* Revert register configuration. */
    pd->adc_ctrl = reg_adc_ctrl;
    CyDelayUs(10);

    pd->intr3 = PDSS_INTR3_CMP_OUT_CHANGED;

    if (((pd->intr3_mask & PDSS_INTR3_CMP_OUT_CHANGED) != 0) &&
        ((reg_adc_ctrl & PDSS_ADC_CTRL_PD_LV) == 0))
    {
        rval = (pd->intr3_cfg_adc_hs & PDSS_INTR3_CFG_ADC_HS_FILT_CFG_MASK) >>
            PDSS_INTR3_CFG_ADC_HS_FILT_CFG_POS;

        if (pd->adc_ctrl & PDSS_ADC_CTRL_CMP_OUT)
        {
            out = true;
        }
        else
        {
            out = false;
        }

        if (((rval ==  PD_ADC_INT_FALLING) && (out == false)) ||
            ((rval ==  PD_ADC_INT_RISING) && (out == true)))
        {
            /* Raise an interrupt. */
            pd->intr3_set |= PDSS_INTR3_CMP_OUT_CHANGED;
        }
    }
}

bool pd_adc_comparator_sample(uint8_t port, PD_ADC_ID_T adc_id, PD_ADC_INPUT_T input,
        uint8_t level)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t reg_adc_ctrl;
    uint8_t state;
    uint8_t comp_out = true;
    (void)adc_id;

    /* Store previous configuration and disable interrupts. */
    state = CyEnterCriticalSection();

    if (gl_pdss_status[port].adc_ref_vddd[adc_id])
        level |= PDSS_ADC_CTRL_VREF_DAC_SEL;


    reg_adc_ctrl = pd->adc_ctrl;

    /* Configure the input and level. */
    pd->adc_ctrl = level | PDSS_ADC_CTRL_ADC_ISO_N |
            ((input << PDSS_ADC_CTRL_VSEL_POS) & PDSS_ADC_CTRL_VSEL_MASK);

    /* Delay 10us for the input selection to stabilize. */
    CyDelayUs(10);

    if (pd->adc_ctrl & PDSS_ADC_CTRL_CMP_OUT)
    {
        comp_out = false;
    }

    pd_adc_restore_intr(port, adc_id, reg_adc_ctrl);
    CyExitCriticalSection(state);

    return comp_out;
}

bool pd_adc_get_comparator_status(uint8_t port, PD_ADC_ID_T adc_id)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    (void)adc_id;


    if (pd->adc_ctrl & PDSS_ADC_CTRL_CMP_OUT)
    {
        return false;
    }

    return true;
}

uint8_t pd_adc_sample(uint8_t port, PD_ADC_ID_T adc_id, PD_ADC_INPUT_T input)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;
    uint32_t volatile timeout = 0;
    uint8_t level = 0;
    uint32_t reg_adc_ctrl;
    (void)adc_id;

    /* Store previous configuration and disable interrupts. */
    state = CyEnterCriticalSection();


    reg_adc_ctrl = pd->adc_ctrl;

    /* Clear the SAR done interrupt. */
    pd->intr0 = PDSS_INTR0_SAR_DONE;

    /* Configure the input. */
    if (gl_pdss_status[port].adc_ref_vddd[adc_id])
        pd->adc_ctrl = PDSS_ADC_CTRL_VREF_DAC_SEL | PDSS_ADC_CTRL_ADC_ISO_N |
            ((input << PDSS_ADC_CTRL_VSEL_POS) & PDSS_ADC_CTRL_VSEL_MASK);
    else
        pd->adc_ctrl = PDSS_ADC_CTRL_ADC_ISO_N |
            ((input << PDSS_ADC_CTRL_VSEL_POS) & PDSS_ADC_CTRL_VSEL_MASK);
    pd->adc_sar_ctrl |= PDSS_ADC_SAR_CTRL_SAR_EN;

    /* Wait for SAR done interrupt status or timeout. */
    while (((pd->intr0 & PDSS_INTR0_SAR_DONE) == 0) && (timeout < PD_ADC_TIMEOUT_COUNT))
    {
        timeout++;
    }

    /* Delay required between SAR_EN bit to be cleared and value to be loaded. */
    CyDelayUs(2);

    level = ((pd->adc_sar_ctrl & PDSS_ADC_SAR_CTRL_SAR_OUT_MASK) >> PDSS_ADC_SAR_CTRL_SAR_OUT_POS);

    /* Clear the SAR done interrupt. */
    pd->intr0 = PDSS_INTR0_SAR_DONE;


    pd_adc_restore_intr(port, adc_id, reg_adc_ctrl);
    CyExitCriticalSection(state);

    return level;
}

uint16_t pd_adc_calibrate(uint8_t port, PD_ADC_ID_T adc_id)
{
    uint8_t  level;
    uint32_t threshold;

    if (gl_pdss_status[port].adc_ref_vddd[adc_id])
    {
        level = pd_adc_sample(port, adc_id, PD_ADC_INPUT_BANDGAP);

        /* Check for zero. If level came out as zero, then do not calculate. */
        if (level != 0)
        {
            threshold = ((PD_ADC_BAND_GAP_VOLT_MV * PD_ADC_NUM_LEVELS) / (uint32_t)level);
            gl_pdss_status[port].adc_vddd_mv[adc_id] = (uint16_t)threshold;
        }
    }

    return gl_pdss_status[port].adc_vddd_mv[adc_id];
}

ccg_status_t pd_adc_init(uint8_t port, PD_ADC_ID_T adc_id)
{
    PPDSS_REGS_T pd = gl_pdss[port];


    /* Enable the ADC and power it down. */
    pd->adc_ctrl = PDSS_ADC_CTRL_ADC_ISO_N | PDSS_ADC_CTRL_PD_LV;

    gl_pdss_status[port].adc_ref_vddd[adc_id] = false;
    gl_pdss_status[port].adc_vddd_mv[adc_id]  = MX_PD_ADC_REF_VOLT_MV;
    return CCG_STAT_SUCCESS;
}

ccg_status_t pd_adc_select_vref(uint8_t port, PD_ADC_ID_T adc_id, PD_ADC_VREF_T vref_sel)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (vref_sel == PD_ADC_VREF_VDDD)
    {

        /* Enable the ADC and power it down. */
        pd->adc_ctrl |= PDSS_ADC_CTRL_VREF_DAC_SEL;

        gl_pdss_status[port].adc_ref_vddd[adc_id] = true;
        pd_adc_calibrate (port, adc_id);
    }
    else
    {

        /* Enable the ADC and power it down. */
        pd->adc_ctrl &= ~PDSS_ADC_CTRL_VREF_DAC_SEL;

        gl_pdss_status[port].adc_ref_vddd[adc_id] = false;
        gl_pdss_status[port].adc_vddd_mv[adc_id]  = MX_PD_ADC_REF_VOLT_MV;
    }

    return CCG_STAT_SUCCESS;
}

bool pd_frs_rx_enable(uint8_t port)
{
#if (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE)
    dpm_status_t* dpm_stat = dpm_get_status(port);
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;


    /* Set the VBus detach comparator threshold to Vsafe5V */
    uint8_t level = pd_get_vbus_adc_level (port, pd_hal_get_vbus_detach_adc(),
            VSAFE_5V, VSAFE_5V_FRS_SWAP_RX_MARGIN);

    /* Enable VSAFE5V comparator */
    pd_adc_free_run_ctrl(port, pd_hal_get_vbus_detach_adc(), pd_hal_get_vbus_detach_input(), level);

    /* Configure CC line voltage thresholds to detect frs signal */
    regval  = (pd->cc_ctrl_1 & ~(PDSS_CC_CTRL_1_CMP_FS_VSEL_MASK | PDSS_CC_CTRL_1_CMP_FS_CC1V2));
    regval |= (CMP_FS_VSEL_VALUE << PDSS_CC_CTRL_1_CMP_FS_VSEL_POS);

    /* See if cc polarity need update */
    if(dpm_stat->polarity == CC_CHANNEL_2)
    {
        regval |= PDSS_CC_CTRL_1_CMP_FS_CC1V2;
    }
    pd->cc_ctrl_1 = regval;

    /*
     * Set the vsafe5v comp signal source:
     * Using VBUS_MON. Also clear Rx Swap Done status.
     */
    pd->swap_ctrl0 = (pd_hal_get_vbus_detach_adc() << PDSS_SWAP_CTRL0_SWAPR_SOURCE_SEL_POS) |
        (1 << PDSS_SWAP_CTRL0_RX_SWAP_SOURCE_POS) |
        PDSS_SWAP_CTRL0_CLR_RX_SWAP_DONE;

    /* Now configure the Swap controller */
    pd->swap_ctrl1 = FRS_RX_SWAP_CTRL1_DFLT_VAL;
    pd->swap_ctrl2 = FRS_RX_SWAP_CTRL2_DFLT_VAL;
    pd->swap_ctrl3 = FRS_RX_SWAP_CTRL3_DFLT_VAL;
    pd->swap_ctrl5 = FRS_RX_SWAP_CTRL5_DFLT_VAL;

    /* Let thresholds settle */
    CyDelayUs(10);

    /* Take swap controller out of reset */
    pd->swap_ctrl1 &= ~PDSS_SWAP_CTRL1_RESET_SWAP_STATE;

    /* Enabling the FR pulse and disconnect interrupts. FET switching will only happen on pulse. */
    pd->intr2 = PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT;
    pd->intr2_mask |= PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT;

    pd->intr1 = PDSS_INTR1_VSWAP_VBUS_LESS_5_DONE;

    /* Enable the swap controller */
    pd->swap_ctrl0 &= ~PDSS_SWAP_CTRL0_CLR_RX_SWAP_DONE;
    pd->swap_ctrl0 |= PDSS_SWAP_CTRL0_SWAP_ENABLED;

    /* Ensure that the FET switching happens based on SWAP IRQ and VBUS Detect. */
    pd->debug_cc_0 |= PDSS_DEBUG_CC_0_VBUS_C_SWAP_SOURCE_SEL | PDSS_DEBUG_CC_0_VBUS_P_SWAP_SOURCE_SEL;


    /* Set the sink fet OFF settings as per current HW, and enable LF filter 0 for auto FET switching. */
    regval = pd->pgdo_1_cfg[0];
    regval |= ((1 << PDSS_PGDO_1_CFG_SEL_SWAP_VBUS_LESS_5_POS) | PDSS_PGDO_1_CFG_AUTO_MODE);
    pd->pgdo_1_cfg[0]  = regval;

    /* Ensure that source FET is off to start with, and then configure it for turn ON on FR trigger. */
    pd_internal_pfet_off (port, false);
    regval = pd->pgdo_1_cfg[1];
    regval |= (PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE |
            (1 << PDSS_PGDO_1_CFG_SEL_SWAP_VBUS_LESS_5_POS) |
            PDSS_PGDO_1_CFG_AUTO_MODE);
    pd->pgdo_1_cfg[1] = regval;

#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE) */

    return true;
}

bool pd_frs_rx_disable(uint8_t port)
{
#if (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE)

    PPDSS_REGS_T pd = gl_pdss[port];

    pd_adc_comparator_ctrl (port, pd_hal_get_vbus_detach_adc(), PD_ADC_INPUT_AMUX_A, 0, PD_ADC_INT_DISABLED, NULL);

    /* Disable the swap controller */
    pd->swap_ctrl1 |= PDSS_SWAP_CTRL1_RESET_SWAP_STATE;
    pd->swap_ctrl0 &= ~PDSS_SWAP_CTRL0_SWAP_ENABLED;

    /* Disable and clear frs receive interrupts */
    pd->intr1_mask &= ~(PDSS_INTR1_VSWAP_VBUS_LESS_5_DONE);
    pd->intr1 = (PDSS_INTR1_VSWAP_VBUS_LESS_5_DONE);

    pd->intr2_mask &= ~(PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT);
    pd->intr2 = (PDSS_INTR2_SWAP_RCVD | PDSS_INTR2_SWAP_DISCONNECT);

    /* Clear the switch on SWAP bits in the gate driver registers. */
    pd->pgdo_1_cfg[0] &= ~PDSS_PGDO_1_CFG_SEL_SWAP_VBUS_LESS_5_MASK;
    pd->pgdo_2_cfg[0] &= ~(1 << PDSS_PGDO_2_CFG_LS_SOURCE_SEL_POS);
    pd->pgdo_1_cfg[1] &= ~PDSS_PGDO_1_CFG_SEL_SWAP_VBUS_LESS_5_MASK;
    pd->pgdo_2_cfg[1] &= ~(1 << PDSS_PGDO_2_CFG_LS_SOURCE_SEL_POS);

    /* Make sure auto-mode is turned off on both the provider and consumer gate drivers. */
    if (((pd->pgdo_1_cfg[1] & PGDO_1_CFG_AUTO_SEL_MASK) == 0) && (pd->pgdo_2_cfg[1] == 0))
    {
        pd_reset_edge_det(port, true);
        pd->pgdo_1_cfg[1] &= ~(PDSS_PGDO_1_CFG_AUTO_MODE);
    }

    if (((pd->pgdo_1_cfg[0] & PGDO_1_CFG_AUTO_SEL_MASK) == 0) && (pd->pgdo_2_cfg[0] == 0))
    {
        pd_reset_edge_det(port, false);
        pd->pgdo_1_cfg[0] &= ~(PDSS_PGDO_1_CFG_AUTO_MODE);
    }

    /* Restore FET switch condition to default. */
    pd->debug_cc_0 &= ~(PDSS_DEBUG_CC_0_VBUS_C_SWAP_SOURCE_SEL | PDSS_DEBUG_CC_0_VBUS_P_SWAP_SOURCE_SEL);

#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE) */

    return true;
}

bool pd_frs_tx_enable(uint8_t port)
{
#if (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE)
    dpm_status_t* dpm_stat = dpm_get_status(port);
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;

    /* Configure FRS TX source */
    if(port == TYPEC_PORT_0_IDX)
    {
        /* Configuring a GPIO for trigering FRS signal */
        CALL_IN_FUNCTION(gpio_hsiom_set_config)(APP_FRS_TX_GPIO_PORT_PIN_P1, HSIOM_MODE_P0_SWAPT_IN,
                GPIO_DM_HIZ_DIGITAL, 0);
    }
#if CCG_PD_DUALPORT_ENABLE
    if (port == TYPEC_PORT_1_IDX)
    {
        /* Configuring a GPIO for trigering FRS signal */
        CALL_IN_FUNCTION(gpio_hsiom_set_config)(APP_FRS_TX_GPIO_PORT_PIN_P2, HSIOM_MODE_P1_SWAPT_IN,
                GPIO_DM_HIZ_DIGITAL, 0);
    }
#endif /* CCG_PD_DUALPORT_ENABLE */

    /* Configure for Auto FRS signal transmitting */
    regval = (pd->debug_cc_1 & ~(PDSS_DEBUG_CC_1_PFET300_PULLDN_EN_CC1 |
                PDSS_DEBUG_CC_1_PFET300_PULLDN_EN_CC2 |
                PDSS_DEBUG_CC_1_SWAPT_TO_CC1_EN |
                PDSS_DEBUG_CC_1_SWAPT_TO_CC2_EN));

    /* Enable TX discard on swap */
    regval |= PDSS_TX_STOP_ON_SWAP_MASK;

     /* Set cc polarity for pulldowns */
    if(dpm_stat->polarity == CC_CHANNEL_2)
    {
        regval |= (PDSS_DEBUG_CC_1_SWAPT_TO_CC2_EN);
    }
    else
    {
        regval |= (PDSS_DEBUG_CC_1_SWAPT_TO_CC1_EN);
    }
    pd->debug_cc_1 = regval;

    pd->swap_ctrl0 = PDSS_SWAP_CTRL0_SWAP_ENABLED;
    pd->swap_ctrl0 |= FRS_TX_SOURCE_GPIO;

    pd->swap_ctrl0 |= PDSS_SWAP_CTRL0_SWAPT_POLARITY;
    pd->swapt_ctrl1 = FRS_TX_SWAP_CTRL1_DFLT_VAL;

    /* Enable necessary interrupts */
    pd->intr2 = PDSS_INTR2_SWAP_COMMAND_DONE;
    pd->intr2_mask |= PDSS_INTR2_SWAP_COMMAND_DONE;

    /* This delay is needed otherwise swap TX indefinitely short the cc line */
    CyDelayUs(10);

    /* Enable the swap tx  */
    pd->swapt_ctrl1 &= ~PDSS_SWAPT_CTRL1_RESET_SWAPT_STATE;
#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE) */

    return true;
}

bool pd_frs_tx_disable(uint8_t port)
{
#if (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE)
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Disable the swap controller */
    pd->swapt_ctrl1 = PDSS_SWAPT_CTRL1_RESET_SWAPT_STATE;
    pd->swap_ctrl0 &= ~PDSS_SWAP_CTRL0_SWAP_ENABLED;

    /* Disable pulldown */
    pd->debug_cc_1 &= ~(PDSS_DEBUG_CC_1_SWAPT_TO_CC1_EN |
                PDSS_DEBUG_CC_1_SWAPT_TO_CC2_EN);

    /* Clear and disable frs receive interrupts */
    pd->intr2_mask &= ~PDSS_INTR2_SWAP_COMMAND_DONE;
    pd->intr2       = PDSS_INTR2_SWAP_COMMAND_DONE;

#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_TX_ENABLE) */

    return true;
}

#if (VBUS_OCP_ENABLE)
static void ocp_handler_wrapper(uint8_t port, timer_id_t id)
{
    /* OCP debounced. Invoke callback. */
    vbus_ocp_handler(port);
}
#endif /* VBUS_OCP_ENABLE */

#if VCONN_OCP_ENABLE
static void vconn_ocp_timer_cb(uint8_t port, timer_id_t id)
{
    (void)id;

    /* VConn OCP debounced. Deliver callback to app layer. */
    if (gl_vconn_ocp_cb[port] != NULL)
    {
        gl_vconn_ocp_cb[port] (port, true);
    }
}
#endif /* VCONN_OCP_ENABLE */

#if CCGX_V5V_CHANGE_DETECT
static void ccg5_v5v_supply_debounce_cb (uint8_t port, timer_id_t id)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (ccg5_v5v_supply_present[port])
    {
        if ((pd->intr1_status & PDSS_INTR1_STATUS_V5V_STATUS) != 0)
        {
            gl_ccg_supply_changed_cb (port, CCG_SUPPLY_V5V, true);
        }
        else
        {
            ccg5_v5v_supply_present[port] = false;
            timer_start (port, id, 500, ccg5_v5v_supply_debounce_cb);
        }
    }
    else
    {
        if ((pd->intr1_status & PDSS_INTR1_STATUS_V5V_STATUS) == 0)
        {
            gl_ccg_supply_changed_cb (port, CCG_SUPPLY_V5V, false);
        }
        else
        {
            ccg5_v5v_supply_present[port] = true;
            timer_start (port, id, 500, ccg5_v5v_supply_debounce_cb);
        }
    }
}
#endif /* CCGX_V5V_CHANGE_DETECT */

#if VBUS_OCP_ENABLE
/* Defining macros for registers and fields used in common OCP interrupt handler for CCG5, CCG5C and CCG6. */


#define CCG_OCP_INTR_REQ                PDSS_INTR3_CSA_OC_CHANGED
#define CCG_OCP_INTR_MASK               PDSS_INTR3_MASK_CSA_OC_CHANGED_MASK
#define CCG_OCP_INTR_SET                PDSS_INTR3_SET_CSA_OC_CHANGED
#define CCG_OCP_LIVE_STATUS             PDSS_INTR3_STATUS_0_CSA_OC_FILT
#define CCG_OCP_INTR_CFG_MASK           PDSS_INTR3_CFG_CSA_OC_HS_FILT_CFG_MASK
#define CCG_OCP_INTR_CFG_POS            PDSS_INTR3_CFG_CSA_OC_HS_FILT_CFG_POS

#define CCG_OCP_INT_ACT_REG(pd)         (pd)->intr3_masked
#define CCG_OCP_INT_REQ_REG(pd)         (pd)->intr3
#define CCG_OCP_INT_MSK_REG(pd)         (pd)->intr3_mask
#define CCG_OCP_INT_SET_REG(pd)         (pd)->intr3_set
#define CCG_OCP_STATUS_REG(pd)          (pd)->intr3_status_0
#define CCG_OCP_CFG_REG(pd)             (pd)->intr3_cfg_csa_oc_hs


#endif /* VBUS_OCP_ENABLE */

/*
 * Handle all wake-up interrupt sources.
 * INTR1/INTR3/INTR5 etc are mapped to the wake-up interrupt vector.
 */
void pdss_intr1_handler(uint8_t port)
{
    bool comp_out = true;
    PPDSS_REGS_T pd = gl_pdss[port];
    pdss_status_t* pdss_stat = &gl_pdss_status[port];
    uint32_t intr1_cause = pd->intr1_masked;
    pd->intr1_mask &= ~intr1_cause;
    pd->intr1 = intr1_cause;


    /*
     * This routine expects all interrupts which are triggered to be disabled
     * once they are fired, otherwise it can cause problems.
     */
    if (intr1_cause)
    {
#if CCG_HPD_RX_ENABLE
        if (intr1_cause & PDSS_INTR1_HPDIN_CHANGED)
        {
            /*
             * Start HPD ACTIVITY TIMER to prevent re-entry into deepsleep.
             * HPD RX hardware block can't detect HPD events if device enters
             * deepsleep while HPD state is changing (or if HPD is HIGH).
             * If HPD is not connected, timer period shall be 100ms
             * (this is the default minimum HPD Connect debounce time).
             * Otherwise, timer period is 5ms (this is large enough
             * to capture HPD LOW and IRQ events.
             */
            if (gl_hpd_state == false)
            {
                /* Start a timer of 100ms to prevent deep sleep entry. */
                timer_start_wocb(port, HPD_RX_ACTIVITY_TIMER_ID,
                        HPD_RX_ACTIVITY_TIMER_PERIOD_MAX);
            }
            else
            {
                timer_start_wocb(port, HPD_RX_ACTIVITY_TIMER_ID,
                        HPD_RX_ACTIVITY_TIMER_PERIOD_MIN);
            }
        }
#endif /* CCG_HPD_RX_ENABLE */

#if (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE)
        if (intr1_cause & PDSS_INTR1_VSWAP_VBUS_LESS_5_DONE)
        {
            /*
               Clear the AUTO mode on the FETs without affecting their current state. We can
               only do this by assuming that the consumer FET is OFF and the provider FET is ON.
               Please note that it is not possible to handle OV/OC errors while going through
               the Fast Role Transition.
             */
            pd->pgdo_1_cfg[0] &= ~(PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE | PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE);
            pd->pgdo_1_cfg[0] &= ~PDSS_PGDO_1_CFG_AUTO_MODE;
            pd_reset_edge_det(port, false);

            pd->pgdo_1_cfg[1] |= (PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE | PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE);
            CyDelayUs (1);
            pd_reset_edge_det(port, true);

            pd->pgdo_1_cfg[1] |= PDSS_PGDO_1_CFG_SEL_ON_OFF;
            CyDelayUs (1);
            pd->pgdo_1_cfg[1] &= ~PDSS_PGDO_1_CFG_AUTO_MODE;
            CyDelayUs (1);
            pd->pgdo_1_cfg[1] &= ~PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE;


            /*
             * Remember the fact that the provider FET is on so that a subsequent
             * soft start does not cause supply to be turned off.
             */
            gl_ccgx_pfet_on[port] = true;

            CyDelayUs (1);
            pd_frs_rx_disable(port);
        }
#endif /* (CCG_PD_REV3_ENABLE & CCG_FRS_RX_ENABLE) */

#if ((SYS_DEEPSLEEP_ENABLE) && (CCG_HW_DRP_TOGGLE_ENABLE))
        if(intr1_cause & PDSS_INTR1_DRP_ATTACHED_DETECTED)
        {
            /* Auto toggle has been stopped. Also, mark Type-C restart pending. */
            gl_pdss_status[port].auto_toggle_act     = false;
            gl_pdss_status[port].typec_start_pending = true;
        }
#endif /* ((SYS_DEEPSLEEP_ENABLE) && (CCG_HW_DRP_TOGGLE_ENABLE)) */

#if VCONN_OCP_ENABLE
        if (intr1_cause & (PDSS_INTR1_CC1_OCP_CHANGED | PDSS_INTR1_CC2_OCP_CHANGED))
        {
            uint32_t cfg_mask, cfg_pos;
            uint32_t stat_mask;

            /* Disable the interrupt to start with. */
            pd->intr1_mask &= ~(PDSS_INTR1_CC1_OCP_CHANGED | PDSS_INTR1_CC2_OCP_CHANGED);

            /* Identify the register fields of interest. */
            if (gl_vconn_channel[port])
            {
                cfg_mask  = PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_FILT_CFG_MASK;
                cfg_pos   = PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_FILT_CFG_POS;
                stat_mask = PDSS_INTR1_STATUS_CC2_OCP_FILT;
            }
            else
            {
                cfg_mask  = PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_FILT_CFG_MASK;
                cfg_pos   = PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_FILT_CFG_POS;
                stat_mask = PDSS_INTR1_STATUS_CC1_OCP_FILT;
            }

            /* If positive edge interrupt: Current exceeded positive threshold. */
            if (((pd->intr1_cfg_cc12_ocp_hs & cfg_mask) >> cfg_pos) == FILTER_CFG_POS_EN_NEG_DIS)
            {
                /* Look for negative edge of comparator. */
                pd->intr1_cfg_cc12_ocp_hs = pd_hal_mmio_reg_update_field(pd->intr1_cfg_cc12_ocp_hs,
                        FILTER_CFG_POS_DIS_NEG_EN, cfg_mask, cfg_pos);

                /* If the negative edge happened already, queue the interrupt. */
                if ((pd->intr1_status & stat_mask) == 0)
                {
                    pd->intr1_set = (gl_vconn_channel[port] ?
                            PDSS_INTR1_SET_CC2_OCP_CHANGED : PDSS_INTR1_SET_CC1_OCP_CHANGED);
                }

                /* Start the debounce timer. */
                timer_start(port, PD_VCONN_OCP_DEBOUNCE_TIMER, gl_vconn_ocp_debounce[port], vconn_ocp_timer_cb);
            }
            /* If negative edge interrupt: Current is back within limit. */
            else
            {
                if (timer_is_running (port, PD_VCONN_OCP_DEBOUNCE_TIMER))
                {
                    /* Stop the debounce timer. */
                    timer_stop(port, PD_VCONN_OCP_DEBOUNCE_TIMER);

                    /* Look for positive edge of comparator. */
                    pd->intr1_cfg_cc12_ocp_hs = pd_hal_mmio_reg_update_field(pd->intr1_cfg_cc12_ocp_hs,
                            FILTER_CFG_POS_EN_NEG_DIS, cfg_mask, cfg_pos);

                    /* If the positive edge happened already, queue the interrupt. */
                    if ((pd->intr1_status & stat_mask) != 0)
                    {
                        pd->intr1_set = (gl_vconn_channel[port] ?
                                PDSS_INTR1_SET_CC2_OCP_CHANGED : PDSS_INTR1_SET_CC1_OCP_CHANGED);
                    }
                }
            }

            /* Enable interrupt. */
            pd->intr1_mask |= (gl_vconn_channel[port] ? PDSS_INTR1_CC2_OCP_CHANGED : PDSS_INTR1_CC1_OCP_CHANGED);
        }
#endif /* VCONN_OCP_ENABLE */

        /* CC1/2 OVP (VBus short) handler. */
        if ((intr1_cause & (PDSS_INTR1_CC1_OVP_CHANGED | PDSS_INTR1_CC2_OVP_CHANGED)) != 0)
        {
            /* No need to check current status as we only enable positive edge on the interrupt. */
            if (gl_ccg_fault_cb != NULL)
            {
                /* Passing false to indicate CC1/2 fault. */
                gl_ccg_fault_cb (port, false);
            }

            /* Re-enable the interrupts. */
            pd->intr1_mask |= (PDSS_INTR1_MASK_CC1_OVP_CHANGED_MASK | PDSS_INTR1_MASK_CC2_OVP_CHANGED_MASK);
        }

#if CCGX_V5V_CHANGE_DETECT
        if ((intr1_cause & PDSS_INTR1_MASK_V5V_CHANGED_MASK) != 0)
        {
            if (gl_ccg_supply_changed_cb != NULL)
            {
                /* Store the current status of the V5V supply and (re)start a timer for debounce. */
                if (pd->intr1_status & PDSS_INTR1_STATUS_V5V_STATUS)
                {
                    ccg5_v5v_supply_present[port] = true;
                }
                else
                {
                    ccg5_v5v_supply_present[port] = false;
                }

                timer_start (port, APP_V5V_CHANGE_DEBOUNCE_TIMER, 500, ccg5_v5v_supply_debounce_cb);
            }

            /* Re-enable the interrupt. */
            pd->intr1_mask |= PDSS_INTR1_MASK_V5V_CHANGED_MASK;
        }
#endif /* CCGX_V5V_CHANGE_DETECT */
    }


    if (pd->intr5_masked != 0)
    {

#if VBUS_OVP_ENABLE
        if (pd->intr5_masked & (1 << gl_vbus_ovp_filter_id[port]))
        {
            /* Disable and clear OV interrupt. */
            pd->intr5_mask &= ~(1 << gl_vbus_ovp_filter_id[port]);
            pd->intr5 = 1 << gl_vbus_ovp_filter_id[port];

            /* Invoke OVP callback. */
            if (gl_ovp_cb[port] != NULL)
            {
                gl_ovp_cb[port] (port, true);
            }
        }
#endif /* VBUS_OVP_ENABLE */

#if VBUS_UVP_ENABLE
        if (pd->intr5_masked & (1 << FILTER_ID_UV))
        {
            /* Disable and clear UV interrupt. */
            pd->intr5_mask &= ~(1 << FILTER_ID_UV);
            pd->intr5 = 1 << FILTER_ID_UV;

            /* Invoke UVP callback. */
            if (gl_uvp_cb != NULL)
            {
                gl_uvp_cb (port, false);
            }
        }
#endif /* VBUS_UVP_ENABLE */

    }

    if (pd->intr7_masked != 0)
    {
        /* Clear all interrupts. */
        pd->intr7 = pd->intr7;

        /* VSYS detection interrupt. */
        if ((pd->intr7_status & (2 << PDSS_INTR7_STATUS_FILT_8_POS)) != 0)
        {
            /* VSYS is now present: Enable switch and disable regulator. */
            pd->vreg_vsys_ctrl |= PDSS_VREG_VSYS_CTRL_ENABLE_VDDD_SWITCH;
            CyDelayUs (100);

            pd->vreg_vsys_ctrl &= ~PDSS_VREG_VSYS_CTRL_VREG20_1_EN;

#if CCG_PD_DUALPORT_ENABLE
            /* Disable regulator on the second port if applicable. */
            gl_pdss[1]->vreg_vsys_ctrl &= ~PDSS_VREG_VSYS_CTRL_VREG20_1_EN;
#endif /* CCG_PD_DUALPORT_ENABLE */

            /* Notify application about presence of VSYS supply. */
            if (gl_ccg_supply_changed_cb != NULL)
            {
                gl_ccg_supply_changed_cb (port, CCG_SUPPLY_VSYS, true);
            }
        }
        else
        {
            /* Disable the VSYS-VDDD Switch. */
            pd->vreg_vsys_ctrl &= ~PDSS_VREG_VSYS_CTRL_ENABLE_VDDD_SWITCH;

            /* Notify application about absence of VSYS supply. */
            if (gl_ccg_supply_changed_cb != NULL)
            {
                gl_ccg_supply_changed_cb (port, CCG_SUPPLY_VSYS, false);
            }
        }
    }

#if BATTERY_CHARGING_ENABLE


    if (pd->intr3_masked & PDSS_INTR3_CHGDET_CHANGED)
    {
        /* Clear and disable the interrupt. Handling will be done as part of CDP state machine. */
        pd->intr3       = PDSS_INTR3_CHGDET_CHANGED;
        pd->intr3_mask &= ~PDSS_INTR3_MASK_CHGDET_CHANGED_MASK;
        /* Clear interrupt configuration. */
        pd->intr3_cfg_chgdet &= ~PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_MASK;

        /* Notify the charger detect logic that the comparator match has occured. */
        if (pdss_stat->bc_phy_cbk != NULL)
        {
            pdss_stat->bc_phy_cbk(port, BC_EVT_CMP1_FIRE);
        }

    }
#endif /* BATTERY_CHARGING_ENABLE */


    /* SBU1/2 OVP change interrupt. */
    if ((pd->intr3_masked & PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK) != 0)
    {
        /* Clear the interrupt. */
        pd->intr3 = PDSS_INTR3_SBU1_SBU2_OVP_CHANGED_MASK;

        /* We don't need to check status as only positive edge triggered interrupts are enabled. */
        if (gl_ccg_fault_cb != NULL)
        {
            /* Parameter true indicates SBU fault. */
            gl_ccg_fault_cb (port, true);
        }
    }

    /* Comparator (ADC) output change interrupt. */
    if (pd->intr3_masked & PDSS_INTR3_CMP_OUT_CHANGED)
    {
        pd->intr3_mask &= ~PDSS_INTR3_CMP_OUT_CHANGED;
        pd->intr3       =  PDSS_INTR3_CMP_OUT_CHANGED;

        /* Check status. */
        if (pd->adc_ctrl & PDSS_ADC_CTRL_CMP_OUT)
        {
            comp_out = false;
        }

        /* Report status. */
        if (pdss_stat->adc_cb[PD_ADC_ID_0] != NULL)
        {
            pdss_stat->adc_cb[PD_ADC_ID_0](port, comp_out);
        }
    }

#if VBUS_OCP_ENABLE
    /*
     * CCG5 uses INTR3.CSA_OC_CHANGED interrupt to indicate OCP condition.
     * CCG5C and CCG6 use INTR13.CSA_OCP_CHANGED interrupt to indicate OCP condition.
     */
    if ((CCG_OCP_INT_ACT_REG(pd) & CCG_OCP_INTR_REQ) != 0)
    {
        /* If positive edge interrupt. */
        if (((CCG_OCP_CFG_REG(pd) & CCG_OCP_INTR_CFG_MASK) >> CCG_OCP_INTR_CFG_POS) == FILTER_CFG_POS_EN_NEG_DIS)
        {
            /* Clear and disable interrupt. */
            CCG_OCP_INT_MSK_REG(pd) &= ~CCG_OCP_INTR_MASK;
            CCG_OCP_INT_REQ_REG(pd)  = CCG_OCP_INTR_REQ;

            /* Look for negative edge of comparator. */
            CCG_OCP_CFG_REG(pd) = pd_hal_mmio_reg_update_field(CCG_OCP_CFG_REG(pd), FILTER_CFG_POS_DIS_NEG_EN,
                    CCG_OCP_INTR_CFG_MASK, CCG_OCP_INTR_CFG_POS);

            /* Enable interrupt. */
            CCG_OCP_INT_MSK_REG(pd) |= CCG_OCP_INTR_MASK;

            /* Start the debounce timer. */
            timer_start(port, PD_OCP_DEBOUNCE_TIMER, gl_ocp_sw_db_ms[port], ocp_handler_wrapper);

            /* If the negative edge has already happened, raise an interrupt. */
            if ((CCG_OCP_STATUS_REG(pd) & CCG_OCP_LIVE_STATUS) == 0)
            {
                CCG_OCP_INT_SET_REG(pd) = CCG_OCP_INTR_SET;
            }
        }
        /* If negative edge interrupt. */
        else
        {
            /* Clear the interrupt. */
            CCG_OCP_INT_REQ_REG(pd) = CCG_OCP_INTR_REQ;

            if (timer_is_running (port, PD_OCP_DEBOUNCE_TIMER))
            {
                /* Stop the debounce timer. */
                timer_stop (port, PD_OCP_DEBOUNCE_TIMER);

                /* Look for positive edge of comparator. */
                CCG_OCP_CFG_REG(pd) = pd_hal_mmio_reg_update_field(CCG_OCP_CFG_REG(pd),
                        FILTER_CFG_POS_EN_NEG_DIS, CCG_OCP_INTR_CFG_MASK, CCG_OCP_INTR_CFG_POS);

                /* If the positive edge has already happened, raise an interrupt. */
                if ((CCG_OCP_STATUS_REG(pd) & CCG_OCP_LIVE_STATUS) != 0)
                {
                    CCG_OCP_INT_SET_REG(pd) = CCG_OCP_INTR_SET;
                }
            }
            else
            {
                /* Disable the interrupt here as it is no longer of interest. */
                CCG_OCP_INT_MSK_REG(pd) &= ~CCG_OCP_INTR_MASK;
            }
        }
    }
#endif /* VBUS_OCP_ENABLE */

}

void pd_reset_edge_det(uint8_t port, bool pgdo_type)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (pgdo_type)
    {
        /* Reset edge detector. */
        pd->pgdo_1_cfg[1] |= PDSS_PGDO_1_CFG_RST_EDGE_DET;
        pd->pgdo_1_cfg[1] &= ~PDSS_PGDO_1_CFG_RST_EDGE_DET;
    }
    else
    {
        /* Reset edge detector. */
        pd->pgdo_1_cfg[0] |= PDSS_PGDO_1_CFG_RST_EDGE_DET;
        pd->pgdo_1_cfg[0] &= ~PDSS_PGDO_1_CFG_RST_EDGE_DET;
    }
}



void pd_internal_pfet_on(uint8_t port, bool turn_on_seq)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval = 0;
    (void)turn_on_seq;

    /* We can turn sink FET OFF if source FET is being turned ON. */
    pd_internal_cfet_off(port, turn_on_seq);

    /* Reset the edge detector. */
    pd_reset_edge_det(port, true);



    gl_ccgx_pfet_on[port] = true;


    /* Turn on the fet. */
    regval = pd->pgdo_1_cfg[1];
    regval |= (PDSS_PGDO_1_CFG_SEL_ON_OFF | PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE);
    pd->pgdo_1_cfg[1] = regval;
}

void pd_internal_pfet_off(uint8_t port, bool turn_off_seq)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    /* Legacy parameter - Not used. */
    (void)turn_off_seq;


    gl_ccgx_pfet_on[port] = false;


    /* Disable all auto mode configuration. */
    pd->pgdo_2_cfg[1]  = 0;
    pd->pgdo_1_cfg[1] &= ~(PGDO_1_CFG_AUTO_SEL_MASK | PDSS_PGDO_1_CFG_AUTO_MODE);

    /* Program PGDO back to its default (OFF) state. */
    pd->pgdo_1_cfg[1] &= ~(PDSS_PGDO_1_CFG_SEL_ON_OFF |
            PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE | PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE);

    /*
     * The edge detector may have triggered later than previous fault.
     * In this case, this needs to be cleared.
     */
    pd_reset_edge_det(port, true);
}

void pd_internal_cfet_on(uint8_t port, bool turn_on_seq)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;
    uint8_t  mask;
    (void)turn_on_seq;

    /* We can turn source FET OFF when turning sink FET ON. */
    pd_internal_pfet_off(port, turn_on_seq);

    /* Reset the edge detector. */
    pd_reset_edge_det(port, false);

    mask = CyEnterCriticalSection ();

#if CCG_PD_DUALPORT_ENABLE
    /* Make sure both PD ports are idle before enabling the FET. */
    while (
            ((gl_pdss[0]->status & (PDSS_STATUS_RX_BUSY | PDSS_STATUS_CC_DATA_VALID)) != 0) ||
            ((gl_pdss[1]->status & (PDSS_STATUS_RX_BUSY | PDSS_STATUS_CC_DATA_VALID)) != 0)
          );
#else
    /* Make sure the PD port is idle before enabling the FET. */
    while ((pd->status & (PDSS_STATUS_RX_BUSY | PDSS_STATUS_CC_DATA_VALID)) != 0);
#endif /* CCG_PD_DUALPORT_ENABLE */



    gl_ccgx_cfet_on[port] = true;

    /* Turn on the fet by setting ENABLE_ON bit. */
    regval = pd->pgdo_1_cfg[0];
    regval |= (PDSS_PGDO_1_CFG_SEL_ON_OFF | PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE);
    pd->pgdo_1_cfg[0] |= regval;

    CyExitCriticalSection (mask);
}

void pd_internal_cfet_off(uint8_t port, bool turn_off_seq)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Legacy parameter - Not used. */
    (void)turn_off_seq;

    /* Disable all auto mode configuration. */
    pd->pgdo_2_cfg[0]  = 0;
    pd->pgdo_1_cfg[0] &= ~(PGDO_1_CFG_AUTO_SEL_MASK | PDSS_PGDO_1_CFG_AUTO_MODE);

    /* Program PGDO back to its default (OFF) state. */
    pd->pgdo_1_cfg[0] &= ~(PDSS_PGDO_1_CFG_SEL_ON_OFF |
           PDSS_PGDO_1_CFG_PGDO_EN_LV_ON_VALUE | PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE);


    gl_ccgx_cfet_on[port] = false;
}

/*
 * CCG5 VBus Discharge implementation:
 * -----------------------------------
 * We use a high resistance (~2 KOhms) when the voltage is above 6 V; and a lower resistance (~500 Ohms)
 * at lower voltages. Also, the circuit is left on continuously until turned off by the app. logic.
 */

/* Vbus discharge drive strength at high voltages for CCG5/CCG5C/CCG6 Silicon. */
#define DISCHG_DRIVE_STRENGTH_VBUS_HI_REVA      (0x03)

/* Vbus discharge drive strength at low voltages for CCG5/CCG5C/CCG6 Silicon. */
#define DISCHG_DRIVE_STRENGTH_VBUS_LO_REVA      (0x0F)

/* Vbus discharge monitoring period in ms. */
#define DISCHG_MONITOR_PERIOD                   (1u)

/*
 * Safe voltage level that can be allowed on VBus while discharge is in progress.
 * This value is equivalent to about 6 V assuming ADC reference voltage of 2 V.
 */
#define VBUS_SAFE_LEVEL                         (0x3D)

/*
 * This function implements a discharge monitoring task.
 * This is used to reduce the resistance on the discharge path once voltage has dropped to a safe region.
 */
void pd_discharge_monitor_cb(uint8_t port, timer_id_t id)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;
    uint8_t  vbus_val;

    /*
     * Measure the VBus voltage and set the discharge path strength based on the voltage.
     */
    vbus_val = pd_adc_sample(port, APP_VBUS_POLL_ADC_ID, APP_VBUS_POLL_ADC_INPUT);

    /*
     * Update discharge series resistance if voltage is in the SAFE range.
     */
    if (vbus_val < VBUS_SAFE_LEVEL)
    {
        regval = pd->dischg_shv_ctrl;
        regval &= ~PDSS_DISCHG_SHV_CTRL_DISCHG_DS_MASK;

        regval |= (PDSS_DISCHG_SHV_CTRL_DISCHG_EN | PDSS_DISCHG_SHV_CTRL_DISCHG_EN_CFG |
                  (DISCHG_DRIVE_STRENGTH_VBUS_LO_REVA << PDSS_DISCHG_SHV_CTRL_DISCHG_DS_POS));

        pd->dischg_shv_ctrl = regval;
    }
    else
    {
        /* Start ON timer so that discharge monitoring can be continued. */
        timer_start(port, id, DISCHG_MONITOR_PERIOD, pd_discharge_monitor_cb);
    }
}

void pd_internal_vbus_discharge_on(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t regval;

    /* Enable the VBus discharge circuit. */
    regval = pd->dischg_shv_ctrl;
    regval &= ~PDSS_DISCHG_SHV_CTRL_DISCHG_DS_MASK;
    regval |= (PDSS_DISCHG_SHV_CTRL_DISCHG_EN | PDSS_DISCHG_SHV_CTRL_DISCHG_EN_CFG |
              (DISCHG_DRIVE_STRENGTH_VBUS_HI_REVA << PDSS_DISCHG_SHV_CTRL_DISCHG_DS_POS));
    pd->dischg_shv_ctrl = regval;

    /* Start a timer to monitor the VBus discharge progress. */
    timer_start(port, VBUS_DISCHARGE_SCHEDULE_TIMER, DISCHG_MONITOR_PERIOD, pd_discharge_monitor_cb);
}

void pd_internal_vbus_discharge_off(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Stop the discharge schedule update timer. */
    timer_stop(port, VBUS_DISCHARGE_SCHEDULE_TIMER);

    /* Disable the discharge circuit. */
    pd->dischg_shv_ctrl &= ~PDSS_DISCHG_SHV_CTRL_DISCHG_EN;
}

#if BATTERY_CHARGING_ENABLE

/* BC 1.2 source implementation for CCG5. */

/* Structure holding CDP state machine variables. */
typedef struct cdp_sm_vars {
    bool     is_active;                 /* Whether the state machine is active. */
    bool     vdmsrc_on;                 /* Whether the VDM_SRC supply has been turned ON. */
    uint8_t  vdmsrc_lv_cnt;             /* Number of times the VDM_SRC output has been detected as low. */

#if (CCG5_CDP_WAIT_DURATION != 0)
    uint32_t time_remaining;            /* Remaining time for which CDP state machine should be active. */
#endif /* (CCG5_CDP_WAIT_DURATION != 0) */
} cdp_sm_vars;

cdp_sm_vars cdp_state[NO_OF_TYPEC_PORTS];

#define CCG5_CHGDET_VREF_325mV          (0)     /* VRef selection: 325 mV */
#define CCG5_CHGDET_VREF_600mV          (1)     /* VRef selection: 600 mV */
#define CCG5_CHGDET_VREF_850mV          (2)     /* VRef selection: 850 mV */

#define CCG5_CHGDET_COMP_INP_DM         (0)     /* Chg.Det. comparator input selection: D- */
#define CCG5_CHGDET_COMP_INP_VREF       (1)     /* Chg.Det. comparator input selection: VRef */
#define CCG5_CHGDET_COMP_INP_DP         (2)     /* Chg.Det. comparator input selection: D+ */

#define CDP_DX_VOLTAGE_CHECK_PERIOD     (15)    /* Frequency of D+/D- voltage checks in CDP state machine. */
#define CDP_VDMSRC_FAULT_CHECK_PERIOD   (2)     /* Frequency of D- voltage checks once a fault has been detected. */
#define MAX_CDP_VDMSRC_FAULT_COUNT      (3)     /* Max. number of faulty D- voltage readings allowed. */

static bool ccg_bc_compare_volt(uint8_t port, uint8_t inp, uint8_t vref)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t val;

    uint8_t  intr_state = CyEnterCriticalSection ();

    /* Configure the comparator for voltage measurement. */
    val = pd->chgdet_0_ctrl;
    val &= ~(PDSS_CHGDET_0_CTRL_CMP_INP_SEL_MASK | PDSS_CHGDET_0_CTRL_CMP_INN_SEL_MASK |
            PDSS_CHGDET_0_CTRL_VREF_SEL_MASK);
    val |= (
            (inp << PDSS_CHGDET_0_CTRL_CMP_INP_SEL_POS) |
            (CCG5_CHGDET_COMP_INP_VREF << PDSS_CHGDET_0_CTRL_CMP_INN_SEL_POS) |
            (vref << PDSS_CHGDET_0_CTRL_VREF_SEL_POS)
           );
    pd->chgdet_0_ctrl = val | PDSS_CHGDET_0_CTRL_EN_COMP_CHGDET;

    /* Wait for 5 us and read the comparator output. */
    CyDelayUs (5);
    val = pd->intr3_status_0;

    CyExitCriticalSection (intr_state);
    return ((bool)(val & PDSS_INTR3_STATUS_0_CHGDET_STATUS));
}

/* Timer callback to poll the D- voltage and ensure that it is in the expected range. */
static void cdp_dm_volt_poll_cb (uint8_t port, timer_id_t id)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if ((pd->chgdet_0_ctrl & PDSS_CHGDET_0_CTRL_VDM_SRC_EN) != 0)
    {
        /* Make sure that D- voltage is actually above 325 mV. Otherwise, turn off VDM-SRC supply. */
        if (!ccg_bc_compare_volt(port, CCG5_CHGDET_COMP_INP_DM, CCG5_CHGDET_VREF_325mV))
        {
            cdp_state[port].vdmsrc_lv_cnt++;
            if (cdp_state[port].vdmsrc_lv_cnt >= MAX_CDP_VDMSRC_FAULT_COUNT)
            {
                /* Not updating the vdmsrc_on variable here to prevent repeated OFF/ON activity. */
                pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_VDM_SRC_EN;
                cdp_state[port].vdmsrc_lv_cnt = 0;
            }
        }
        else
        {
            cdp_state[port].vdmsrc_lv_cnt = 0;
        }
    }
}

/* Check if CDP state machine is busy. */
bool ccg_is_cdp_sm_busy(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    bool cdp_busy = false;

    if (cdp_state[port].is_active)
    {
        if ((pd->chgdet_0_ctrl & PDSS_CHGDET_0_CTRL_VDM_SRC_EN) != 0)
        {
            /* We cannot go to sleep while VDM_SRC supply is enabled. */
            cdp_busy = true;
        }

        /* Wake periodically to check voltage while the CDP state machine is running. */
        if (!timer_is_running (port, APP_BC_GENERIC_TIMER1))
        {
            if (cdp_state[port].vdmsrc_lv_cnt != 0)
            {
                timer_start (port, APP_BC_GENERIC_TIMER1, CDP_VDMSRC_FAULT_CHECK_PERIOD, cdp_dm_volt_poll_cb);
            }
            else
            {
                timer_start (port, APP_BC_GENERIC_TIMER1, CDP_DX_VOLTAGE_CHECK_PERIOD, cdp_dm_volt_poll_cb);
            }
        }
    }

    return (cdp_busy);
}

/* Enable BC 1.2 operation as DCP. */
void ccg_bc_dcp_en(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Enable charger detect isolation switch. */
    pd->dpdm_ctrl = (pd->dpdm_ctrl & ~PDSS_DPDM_CTRL_DPDM_T_DPDM_MASK) | (8 << PDSS_DPDM_CTRL_DPDM_T_DPDM_POS);
    CyDelayUs(10);

    pd->chgdet_0_ctrl = 0;
    pd->chgdet_0_ctrl = PDSS_CHGDET_0_CTRL_EN_CHGDET | PDSS_CHGDET_0_CTRL_DCP_EN;
    pd->chgdet_1_ctrl = PDSS_CHGDET_1_CTRL_CHGDET_ISO_N;
}

/* Disable BC 1.2 operation. */
void ccg_bc_dis(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Disable charger detect interrupt. */
    pd->intr3_mask &= ~PDSS_INTR3_MASK_CHGDET_CHANGED_MASK;

    /* Disable outputs from the CHGDET block. */
    pd->chgdet_1_ctrl = 0;

    /* Disable voltage source of D- pin. */
    pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_VDM_SRC_EN;

    /* Disable current sink on the D+ pin. */
    pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_IDP_SNK_EN;

    pd->chgdet_0_ctrl = 0;
    pd->chgdet_0_ctrl = PDSS_CHGDET_0_CTRL_PD;

    /* Make sure charger detect block is isolated from DP/DM connections. */
    pd->dpdm_ctrl &= ~PDSS_DPDM_CTRL_DPDM_T_DPDM_MASK;

    /* Move all state machines to idle state. */
    cdp_state[port].is_active     = false;
    cdp_state[port].vdmsrc_on     = false;
    cdp_state[port].vdmsrc_lv_cnt = 0;
}

/* BC 1.2 CDP state machine. */
bool ccg_bc_cdp_sm(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (cdp_state[port].is_active == false)
        return false;

    /* Clear any pending charger detect block interrupt. */
    pd->intr3 = PDSS_INTR3_CHGDET_CHANGED;

    /* Check whether D+ voltage is in the 0.325 - 0.85 V window. */
    if (ccg_bc_compare_volt(port, CCG5_CHGDET_COMP_INP_DP, CCG5_CHGDET_VREF_325mV))
    {
        /* D+ voltage is above 0.325 V. */

        if (!ccg_bc_compare_volt(port, CCG5_CHGDET_COMP_INP_DP, CCG5_CHGDET_VREF_850mV))
        {
            /* D+ voltage is in the correct window. Enable voltage source on D-. */
            if (!cdp_state[port].vdmsrc_on)
            {
                pd->chgdet_0_ctrl |= PDSS_CHGDET_0_CTRL_VDM_SRC_EN;
                cdp_state[port].vdmsrc_on     = true;
                cdp_state[port].vdmsrc_lv_cnt = 0;

                /* Make sure the first D- voltage check is done 15 ms later. */
                timer_stop (port, APP_BC_GENERIC_TIMER1);
            }
        }
        else
        {
            /* Voltage has gone beyond 0.8 V. Turn off Vdm_src, and return to idle state. */
            ccg_bc_dis (port);
            return false;
        }
    }
    else
    {
        /* D+ Voltage has fallen below 0.325 V again. Disable voltage source on D-. */
        if (cdp_state[port].vdmsrc_on)
        {
            pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_VDM_SRC_EN;
            cdp_state[port].vdmsrc_on = false;
        }
    }

    /* Leave the comparator configured for D+ comparison against 325 mV. */
    pd->intr3 = PDSS_INTR3_CHGDET_CHANGED;
    ccg_bc_compare_volt(port, CCG5_CHGDET_COMP_INP_DP, CCG5_CHGDET_VREF_325mV);

    /* Configure the charger detect interrupt to fire on any change in voltage. */
    pd->intr3_cfg_chgdet |= (3 << PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_POS);
    pd->intr3_mask       |= PDSS_INTR3_MASK_CHGDET_CHANGED_MASK;

    /* State machine has more work to do. */
    return true;
}

#if (CCG5_CDP_WAIT_DURATION != 0)

static void cdp_timeout_timer_cb (uint8_t port, timer_id_t id)
{
    /* Stop and disable the CDP state machine. */
    if (cdp_state[port].is_active)
    {
        cdp_state[port].time_remaining--;
        if (cdp_state[port].time_remaining == 0)
        {
            ccg_bc_dis (port);
        }
        else
        {
            timer_start (port, id, 1000, cdp_timeout_timer_cb);
        }
    }
    else
    {
        cdp_state[port].time_remaining = 0;
    }
}

#endif /* (CCG5_CDP_WAIT_DURATION != 0) */

/* Enable BC 1.2 operation as CDP. */
void ccg_bc_cdp_en(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Enable charger detect isolation switch. */
    pd->dpdm_ctrl = (pd->dpdm_ctrl & ~PDSS_DPDM_CTRL_DPDM_T_DPDM_MASK) | (8 << PDSS_DPDM_CTRL_DPDM_T_DPDM_POS);
    CyDelayUs(10);

    /* Enable the charger detect block. */
    pd->chgdet_0_ctrl = 0;
    pd->chgdet_0_ctrl = PDSS_CHGDET_0_CTRL_EN_CHGDET;
    pd->chgdet_1_ctrl = PDSS_CHGDET_1_CTRL_CHGDET_ISO_N;

    /* Enable current sink on the D+ pin. */
    pd->chgdet_0_ctrl |= PDSS_CHGDET_0_CTRL_IDP_SNK_EN;

    /* Disable the filtering of the chgdet comparator output and enable bypass. */
    pd->intr3_cfg_chgdet &= ~PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_EN;
    pd->intr3_cfg_chgdet |= PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_BYPASS;

    /* Configure the comparator to check whether D+ voltage is higher than 325 mV. */
    ccg_bc_compare_volt(port, CCG5_CHGDET_COMP_INP_DP, CCG5_CHGDET_VREF_325mV);

    cdp_state[port].is_active = true;
    CyDelayUs (1);
    ccg_bc_cdp_sm (port);

#if (CCG5_CDP_WAIT_DURATION != 0)
    /* Use a 1 second timer to count the user-defined CDP wait duration out. */
    cdp_state[port].time_remaining = CCG5_CDP_WAIT_DURATION;
    timer_start (port, APP_BC_GENERIC_TIMER2, 1000, cdp_timeout_timer_cb);
#endif /* (CCG5_CDP_WAIT_DURATION != 0) */
}

#endif /* ((BATTERY_CHARGING_ENABLE) && (defined(CCG5))) */

#if CCG_PD_DUALPORT_ENABLE
static dpdm_mux_cfg_t gl_cur_dpdm_cfg[NO_OF_TYPEC_PORTS] = {
    DPDM_MUX_CONN_NONE,
    DPDM_MUX_CONN_NONE
};
#else
static dpdm_mux_cfg_t gl_cur_dpdm_cfg = DPDM_MUX_CONN_NONE;
#endif /* CCG_PD_DUALPORT_ENABLE */

/* Configure DP/DM MUX. */
void ccg_config_dp_dm_mux(uint8_t port, dpdm_mux_cfg_t conf)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Do nothing if the configuration is already correct. */
#if CCG_PD_DUALPORT_ENABLE
    if (gl_cur_dpdm_cfg[port] == conf)
    {
        return;
    }
    gl_cur_dpdm_cfg[port] = conf;
#else
    if (gl_cur_dpdm_cfg == conf)
    {
        return;
    }
    gl_cur_dpdm_cfg = conf;
#endif /* CCG_PD_DUALPORT_ENABLE */

    if (conf == DPDM_MUX_CONN_NONE)
    {
        /* Disable pump first. PUMP[3] is for Port 0, and PUMP[2] is for Port 1. */
        ccg5_pump_disable (port, 2 - port);
        CyDelayUs (2);

        /* Turn off all switches and isolate outputs. */
        pd->dpdm_ctrl &= ((PDSS_DPDM_CTRL_DPDM_T_DPDM_MASK)
                );
    }
    else
    {
        /* Enable the output switch and configure required bits. */
        pd->dpdm_ctrl = (pd->dpdm_ctrl & PDSS_DPDM_CTRL_DPDM_T_DPDM_MASK) |
            ((uint32_t)conf | PDSS_DPDM_CTRL_DPDM_ISO_N);
        CyDelayUs (2);

        /* Now enable pump for slow ramp of signals. */
        ccg5_pump_enable (port, 2 - port);
    }
}

/* SBU1 and SBU2 switch state. */
sbu_switch_state_t gl_sbu1_state[NO_OF_TYPEC_PORTS];
sbu_switch_state_t gl_sbu2_state[NO_OF_TYPEC_PORTS];

/* AUX1 and AUX2 resistor configuration. */
aux_resistor_config_t gl_aux1_config[NO_OF_TYPEC_PORTS];
aux_resistor_config_t gl_aux2_config[NO_OF_TYPEC_PORTS];

ccg_status_t sbu_switch_configure(uint8_t port, sbu_switch_state_t sbu1_state, sbu_switch_state_t sbu2_state)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint32_t sbu1val;
    uint32_t sbu2val;
    uint8_t  intstate;

    /* Check that state values are withing allowed range. */
    if ((sbu1_state >= SBU_MAX_STATE) || (sbu2_state >= SBU_MAX_STATE))
    {
        /* Don't service the request. */
        return CCG_STAT_INVALID_ARGUMENT;
    }

    intstate = CyEnterCriticalSection();
    if ((sbu1_state == SBU_NOT_CONNECTED) && (sbu2_state == SBU_NOT_CONNECTED))
    {
        /* Turn off pump first and then disable all switches. */
        ccg5_pump_disable (port, 1 - port);
        CyDelayUs (2);

        pd->sbu20_sbu1_en_1_ctrl = 0;
        pd->sbu20_sbu2_en_1_ctrl = 0;
    }
    else
    {
        /* SBU1 connection. */
        /* Turn the switch off when OVP is detected on any of the CC or SBU lines. */
        sbu1val = PDSS_SBU20_SBU1_EN_1_CTRL_SEL_ON_OFF |
            PDSS_SBU20_SBU1_EN_1_CTRL_SEL_CC1_OVP | PDSS_SBU20_SBU1_EN_1_CTRL_SEL_CC2_OVP |
            PDSS_SBU20_SBU1_EN_1_CTRL_SBU1_SEL_SBU1_OVP | PDSS_SBU20_SBU1_EN_1_CTRL_SBU1_SEL_SBU2_OVP;

        switch (sbu1_state)
        {
            case SBU_CONNECT_AUX1:
                sbu1val |= PDSS_SBU20_SBU1_EN_1_CTRL_AUXP_SBU1_EN_ON_VALUE;
                break;

            case SBU_CONNECT_AUX2:
                sbu1val |= PDSS_SBU20_SBU1_EN_1_CTRL_AUXN_SBU1_EN_ON_VALUE;
                break;

            case SBU_CONNECT_LSTX:
                sbu1val |= PDSS_SBU20_SBU1_EN_1_CTRL_LSTX_SBU1_EN_ON_VALUE;
                break;

            case SBU_CONNECT_LSRX:
                sbu1val |= PDSS_SBU20_SBU1_EN_1_CTRL_LSRX_SBU1_EN_ON_VALUE;
                break;

            default:
                sbu1val = 0;
                break;
        }

        /* SBU2 connection. */
        /* Turn the switch off when OVP is detected on any of the CC or SBU lines. */
        sbu2val = PDSS_SBU20_SBU2_EN_1_CTRL_SEL_ON_OFF |
            PDSS_SBU20_SBU2_EN_1_CTRL_SEL_CC1_OVP | PDSS_SBU20_SBU2_EN_1_CTRL_SEL_CC2_OVP |
            PDSS_SBU20_SBU2_EN_1_CTRL_SBU2_SEL_SBU1_OVP | PDSS_SBU20_SBU2_EN_1_CTRL_SBU2_SEL_SBU2_OVP;

        switch (sbu2_state)
        {
            case SBU_CONNECT_AUX1:
                sbu2val |= PDSS_SBU20_SBU2_EN_1_CTRL_AUXP_SBU2_EN_ON_VALUE;
                break;

            case SBU_CONNECT_AUX2:
                sbu2val |= PDSS_SBU20_SBU2_EN_1_CTRL_AUXN_SBU2_EN_ON_VALUE;
                break;

            case SBU_CONNECT_LSTX:
                sbu2val |= PDSS_SBU20_SBU2_EN_1_CTRL_LSTX_SBU2_EN_ON_VALUE;
                break;

            case SBU_CONNECT_LSRX:
                sbu2val |= PDSS_SBU20_SBU2_EN_1_CTRL_LSRX_SBU2_EN_ON_VALUE;
                break;

            default:
                sbu2val = 0;
                break;
        }

        pd->sbu20_sbu1_en_1_ctrl = sbu1val;
        pd->sbu20_sbu2_en_1_ctrl = sbu2val;

        /* Provide some delay and turn the pump on. */
        CyDelayUs (5);
        ccg5_pump_enable (port, 1 - port);
    }

    /* Store SBU1 and SBU2 states. */
    gl_sbu1_state[port] = sbu1_state;
    gl_sbu2_state[port] = sbu2_state;

    CyExitCriticalSection(intstate);
    return CCG_STAT_SUCCESS;
}

sbu_switch_state_t get_sbu1_switch_state(uint8_t port)
{
    return gl_sbu1_state[port];
}

sbu_switch_state_t get_sbu2_switch_state(uint8_t port)
{
    return gl_sbu2_state[port];
}


#if BATTERY_CHARGING_ENABLE

ccg_status_t chgb_init(uint8_t cport, bc_phy_cbk_t cbk)
{
    pdss_status_t* pdss_stat = &gl_pdss_status[cport];
    PPDSS_REGS_T pd = gl_pdss[cport];

    if (cbk == NULL)
    {
        return CCG_STAT_BAD_PARAM;
    }

    pdss_stat->bc_phy_cbk = cbk;

    pd->intr3_cfg_chgdet &= ~(PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_EN|
                PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_MASK |
                PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_SEL_MASK |
                PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_EN  |
                PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_MASK |
                PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_SEL_MASK);

    return CCG_STAT_SUCCESS;
}

ccg_status_t chgb_enable(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    /* Enable Charger detect block */
    pd->chgdet_0_ctrl = PDSS_CHGDET_0_CTRL_EN_CHGDET;
    pd->chgdet_1_ctrl = PDSS_CHGDET_1_CTRL_CHGDET_ISO_N;

    CyDelayUs(50);
    return CCG_STAT_SUCCESS;
}

ccg_status_t chgb_disable(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_1_ctrl = 0;
    pd->chgdet_0_ctrl = PDSS_CHGDET_0_CTRL_PD;

    /* Disable all interrupts. */
    pd->intr3_mask &= ~PDSS_INTR3_CHGDET_CHANGED;
    pd->intr3 = PDSS_INTR3_CHGDET_CHANGED;

    return CCG_STAT_SUCCESS;
}

void chgb_deepsleep(uint8_t cport)
{

    /* TODO: Update this code for CCG5 support. */
}

void chgb_wakeup(uint8_t cport)
{
    /* Nothing to do. */
}


ccg_status_t chgb_apply_src_term(uint8_t cport, chgb_src_term_t charger_term)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    /* Remove any existing terminations. */
    chgb_remove_term(cport);

    switch(charger_term)
    {
        case CHGB_SRC_TERM_APPLE_1A:
            pd->chgdet_1_ctrl |= (1u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS)|
                (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_1A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS) |
                (1u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_4A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS) |
                (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        case CHGB_SRC_TERM_DCP:
            pd->chgdet_0_ctrl |= (PDSS_CHGDET_0_CTRL_DCP_EN |
                    PDSS_CHGDET_0_CTRL_RDAT_LKG_DP_EN |
                    PDSS_CHGDET_0_CTRL_RDAT_LKG_DM_EN);
            break;
        default:
            break;
    }

    return CCG_STAT_SUCCESS;
}


ccg_status_t chgb_apply_dp_pd(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl |= PDSS_CHGDET_0_CTRL_RDP_PD_EN;
    return CCG_STAT_SUCCESS;
}

ccg_status_t chgb_remove_dp_pd(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_RDP_PD_EN;
    return CCG_STAT_SUCCESS;
}

void chgb_apply_rdat_lkg_dp(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl |= PDSS_CHGDET_0_CTRL_RDAT_LKG_DP_EN;
}

void chgb_apply_rdat_lkg_dm(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl |= PDSS_CHGDET_0_CTRL_RDAT_LKG_DM_EN;
}

void chgb_remove_rdat_lkg_dp(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_RDAT_LKG_DP_EN;
}

void chgb_remove_rdat_lkg_dm(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_RDAT_LKG_DM_EN;
}

void chgb_apply_apple_src_dp(uint8_t cport, chgb_src_term_t apple_term_id)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    switch(apple_term_id)
    {
        case CHGB_SRC_TERM_APPLE_1A:
            pd->chgdet_1_ctrl |= (1u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_1A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_4A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DP_POS);
            break;
        default:
            break;
    }
}

void chgb_apply_apple_src_dm(uint8_t cport, chgb_src_term_t apple_term_id)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    switch(apple_term_id)
    {
        case CHGB_SRC_TERM_APPLE_1A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_1A:
            pd->chgdet_1_ctrl |= (1u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        case CHGB_SRC_TERM_APPLE_2_4A:
            pd->chgdet_1_ctrl |= (2u << PDSS_CHGDET_1_CTRL_CHGDET_APPLE_MODE_DM_POS);
            break;
        default:
            break;
    }
}


ccg_status_t chgb_remove_term(uint8_t cport)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    pd->chgdet_0_ctrl &= ~(PDSS_CHGDET_0_CTRL_IDP_SNK_EN |
            PDSS_CHGDET_0_CTRL_IDM_SNK_EN |
            PDSS_CHGDET_0_CTRL_VDP_SRC_EN |
            PDSS_CHGDET_0_CTRL_VDM_SRC_EN |
            PDSS_CHGDET_0_CTRL_IDP_SRC_EN |
            PDSS_CHGDET_0_CTRL_DCP_EN |
            PDSS_CHGDET_0_CTRL_RDM_PD_EN |
            PDSS_CHGDET_0_CTRL_RDM_PU_EN |
            PDSS_CHGDET_0_CTRL_RDP_PD_EN |
            PDSS_CHGDET_0_CTRL_RDP_PU_EN |
            PDSS_CHGDET_0_CTRL_RDAT_LKG_DP_EN |
            PDSS_CHGDET_0_CTRL_RDAT_LKG_DM_EN );
    pd->chgdet_1_ctrl = PDSS_CHGDET_1_CTRL_CHGDET_ISO_N;


    return CCG_STAT_SUCCESS;
}

bool chgb_set_comp(uint8_t cport, uint8_t comp_idx, chgb_comp_pinput_t p_input,
    chgb_comp_ninput_t n_input, chgb_vref_t vref, chgb_comp_edge_t edge)
{
    PPDSS_REGS_T pd = gl_pdss[cport];


    uint32_t regVal;
    uint32_t temp_chgdet_ctrl_0;
    uint32_t temp_intr3_cfg_0;
    uint32_t temp_intr3_mask;
    bool out = false;
    bool result = false;
    uint8_t intr_state;

    intr_state = CyEnterCriticalSection();
    if(comp_idx == 0)
    {
        temp_chgdet_ctrl_0 = pd->chgdet_0_ctrl;
        temp_intr3_cfg_0 = pd->intr3_cfg_chgdet;
        temp_intr3_mask =  pd->intr3_mask;

        pd->intr3_mask &= ~PDSS_INTR3_CHGDET_CHANGED;

        regVal = pd->chgdet_0_ctrl;
        regVal &= ~(PDSS_CHGDET_0_CTRL_CMP_INN_SEL_MASK |
                PDSS_CHGDET_0_CTRL_CMP_INP_SEL_MASK |
                PDSS_CHGDET_0_CTRL_VREF_SEL_MASK);
        regVal |= ((n_input << PDSS_CHGDET_0_CTRL_CMP_INN_SEL_POS) |
                (p_input << PDSS_CHGDET_0_CTRL_CMP_INP_SEL_POS) |
                (vref << PDSS_CHGDET_0_CTRL_VREF_SEL_POS)|
                PDSS_CHGDET_0_CTRL_EN_COMP_CHGDET );


        /* Enable comparator */
        pd->chgdet_0_ctrl = regVal;

        CyDelayUs(10);

        if (pd->intr3_status_0 & PDSS_INTR3_STATUS_0_CHGDET_STATUS)
        {
            result = true;
        }

        /* Enable Interrupt and check if condition already exists */
        if(edge == CHGB_COMP_NO_INTR)
        {
            pd->chgdet_0_ctrl = temp_chgdet_ctrl_0;
            pd->intr3_cfg_chgdet = temp_intr3_cfg_0;
            pd->intr3_mask = temp_intr3_mask;
            CyDelayUs(10);
        }
        else
        {
            pd->intr3_cfg_chgdet &= ~(PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_MASK | PDSS_INTR3_CFG_CHGDET_CHGDET_FILT_EN);
            pd->intr3_cfg_chgdet |= (edge << PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_POS);

            /* Enable comparator interrupts. */
            pd->intr3_mask |= PDSS_INTR3_CHGDET_CHANGED;
        }

        /* Clear comparator interrupt. */
        pd->intr3 = PDSS_INTR3_CHGDET_CHANGED;

        if(pd->intr3_mask & PDSS_INTR3_CHGDET_CHANGED)
        {
            if (pd->intr3_status_0 & PDSS_INTR3_STATUS_0_CHGDET_STATUS)
            {
                out = true;
            }

            regVal = (pd->intr3_cfg_chgdet & PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_MASK)
                >> PDSS_INTR3_CFG_CHGDET_CHGDET_CFG_POS;

            if (((regVal == CHGB_COMP_EDGE_FALLING) && (out == false)) ||
                ((regVal == CHGB_COMP_EDGE_RISING) && (out == true)))
            {
                /* Raise an interrupt. */
                pd->intr3_set |= PDSS_INTR3_CHGDET_CHANGED;
            }
        }

    }
    else
    {
        /* TODO: Same settings for Comp1 for CCG3PA */
    }

    CyExitCriticalSection(intr_state);
    return result;

}

ccg_status_t chgb_stop_comp(uint8_t cport, uint8_t comp_idx)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    if(comp_idx == 0)
    {
        pd->chgdet_0_ctrl &= ~PDSS_CHGDET_0_CTRL_EN_COMP_CHGDET;
        pd->intr3_mask &= ~PDSS_INTR3_CHGDET_CHANGED;
        pd->intr3 = PDSS_INTR3_CHGDET_CHANGED;
    }

    return CCG_STAT_SUCCESS;
}

bool chgb_get_comp_result(uint8_t cport, uint8_t comp_idx)
{
    PPDSS_REGS_T pd = gl_pdss[cport];

    if(comp_idx == 0)
    {
        if(pd->intr3_status_0 & PDSS_INTR3_STATUS_0_CHGDET_STATUS)
        {
            return true;
        }
    }

    return false;
}

#endif /* BATTERY_CHARGING_ENABLE */

#if ((VBUS_OCP_ENABLE) | (VBUS_SCP_ENABLE) | (VBUS_OVP_ENABLE) | (VBUS_UVP_ENABLE) | (VBUS_RCP_ENABLE))

void pd_fet_automode_enable(uint8_t port, bool pctrl, filter_id_t filter_index)
{
    uint32_t regval;
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Provider FET. */
    if (pctrl)
    {
        regval = pd->pgdo_1_cfg[1];
        /* Enable auto mode. */
        regval |= PDSS_PGDO_1_CFG_AUTO_MODE;
        /* Program the off value to turn off the PFET. */
        regval &= ~PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE;
        pd->pgdo_1_cfg[1] = regval;
        /* Select source. */
        pd->pgdo_2_cfg[1] |= 1 << filter_index;
    }
    /* Consumer FET. */
    else
    {
        regval = pd->pgdo_1_cfg[0];
        /* Enable auto mode. */
        regval |= PDSS_PGDO_1_CFG_AUTO_MODE;
        /* Program the off value to turn off the PFET. */
        regval &= ~PDSS_PGDO_1_CFG_PGDO_EN_LV_OFF_VALUE;
        pd->pgdo_1_cfg[0] = regval;
        /* Select source. */
        pd->pgdo_2_cfg[0] |= 1 << filter_index;
    }
}

void pd_fet_automode_disable(uint8_t port, bool pctrl, filter_id_t filter_index)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    if (pctrl)
    {
        /* Remove source. */
        pd->pgdo_2_cfg[1] &= ~(1 << filter_index);
        /* Disable Auto mode if no other source is active. */
        if ((pd->pgdo_2_cfg[1] == 0) && ((pd->pgdo_1_cfg[1] & PGDO_1_CFG_AUTO_SEL_MASK) == 0))
        {
            pd->pgdo_1_cfg[1] &= ~PDSS_PGDO_1_CFG_AUTO_MODE;
        }
    }
    else
    {
        /* Remove source. */
        pd->pgdo_2_cfg[0] &= ~(1 << filter_index);
        /* Disable Auto mode if no other source is active. */
        if ((pd->pgdo_2_cfg[0] == 0) && ((pd->pgdo_1_cfg[0] & PGDO_1_CFG_AUTO_SEL_MASK) == 0))
        {
            pd->pgdo_1_cfg[0] &= ~PDSS_PGDO_1_CFG_AUTO_MODE;
        }
    }

}
#endif /* ((VBUS_OCP_ENABLE) | (VBUS_SCP_ENABLE) | (VBUS_OVP_ENABLE) | (VBUS_UVP_ENABLE) | (VBUS_RCP_ENABLE)) */


#if VBUS_OCP_ENABLE

void pd_internal_vbus_ocp_en(uint8_t port, uint8_t av_bw, uint8_t vref_sel, bool pctrl,
        uint8_t mode, uint8_t debounce_ms)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;
    uint32_t regval;

    /* Note: Assuming this function only gets called for P-CTRL and the mode is set to FW debounce. */

    state = CyEnterCriticalSection();

    gl_vbus_ocp_mode[port]      = mode;
    gl_ocp_sw_db_ms[port]       = debounce_ms;
    gl_vbus_ocp_pgdo_type[port] = pctrl;                /* OCP only gets called for P-CTRL. */

    regval = pd->csa_ctrl;

    /* Power up the CSA block. */
    regval &= ~PDSS_CSA_CTRL_PD_CSA;
    /* Default operational settings. */
    regval |= PDSS_CSA_CTRL_SEL_OUT_D | PDSS_CSA_CTRL_CSA_ISO_N;
    /* Clear the gain, bw and vref settings. */
    regval &= ~(PDSS_CSA_CTRL_AV1_MASK | PDSS_CSA_CTRL_CSA_VREF_SEL_MASK | PDSS_CSA_CTRL_BW_MASK);

    /* Set CSA gain. */
    regval |=  (av_bw >> 2) << PDSS_CSA_CTRL_AV1_POS;
    /* Set analog bandwidth. */
    regval |= ((av_bw & 0x03) << PDSS_CSA_CTRL_BW_POS);

    /* Set Vref trim select. */
    regval |= vref_sel << PDSS_CSA_CTRL_CSA_VREF_SEL_POS;

    /* Write out CSA_CTRL. */
    pd->csa_ctrl = regval;

    /* Bypassing filter is causing false OC triggers. Leaving filter enabled with a 5 us debounce period. */
    regval = pd->intr3_cfg_csa_oc_hs;
    regval &= ~(PDSS_INTR3_CFG_CSA_OC_HS_FILT_EN | PDSS_INTR3_CFG_CSA_OC_HS_FILT_CFG_MASK |
            PDSS_INTR3_CFG_CSA_OC_HS_FILT_SEL_MASK | PDSS_INTR3_CFG_CSA_OC_HS_FILT_RESET |
            PDSS_INTR3_CFG_CSA_OC_HS_FILT_BYPASS);

    /* Set edge detection. */
    regval |= (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR3_CFG_CSA_OC_HS_FILT_CFG_POS);
    regval |= (10 << PDSS_INTR3_CFG_CSA_OC_HS_FILT_SEL_POS) | PDSS_INTR3_CFG_CSA_OC_HS_FILT_EN |
        PDSS_INTR3_CFG_CSA_OC_HS_DPSLP_MODE;
    pd->intr3_cfg_csa_oc_hs = regval;

    /* Clear and enable the OC detect interrupt. */
    pd->intr3 = PDSS_INTR3_CSA_OC_CHANGED;
    pd->intr3_mask |= PDSS_INTR3_MASK_CSA_OC_CHANGED_MASK;

    CyExitCriticalSection(state);
}

void pd_internal_vbus_ocp_dis(uint8_t port, bool pctrl)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;

    state = CyEnterCriticalSection();

    /* Default settings and power down. */
    pd->csa_ctrl = PDSS_CSA_CTRL_SEL_OUT_D | PDSS_CSA_CTRL_PD_CSA;

    /* Disable and clear interrupts. */
    pd->intr3_mask &= ~(PDSS_INTR3_CSA_OC_CHANGED);
    pd->intr3 = PDSS_INTR3_CSA_OC_CHANGED;

    /* Make sure any debounce timer is stopped. */
    timer_stop(port, PD_OCP_DEBOUNCE_TIMER);

    CyExitCriticalSection(state);
}

#endif /* VBUS_OCP_ENABLE */


#if VBUS_OVP_ENABLE

/* OVP min reference voltage in mV. */
#define OVP_REF_VOLT_MIN            (200u)

/* Minimum voltage for VREF8 in mV. */
#define OVP_REF8_VOLT_MIN           (130u)

/* OVP reference voltage step size in mV. */
#define OVP_REF_VOLT_STEP           (10u)

/* Min OVP detection level for VBus. */
#define VBUS_OVP_DETECT_MIN         (6000u)

/* VBUS max voltage in mV. */
#define VBUS_VOLT_MAX               (24000u)

/* Max. VREF setting. */
#define VREF_MAX_SETTING            (199u)

void pd_internal_vbus_ovp_en(uint8_t port, uint16_t volt, int8_t per, PD_ADC_CB_T cb, bool pctrl,
        vbus_ovp_mode_t mode, uint8_t filter_sel)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint16_t threshold, vref;
    uint32_t regval;
    uint32_t comp_id      = COMP_ID_OV;
    filter_id_t filter_id = FILTER_ID_OV;
    uint32_t div_pos      = AMUX_OV_DIV_SEL_BIT_POS;

#if CCG_PD_DUALPORT_ENABLE
    if (port != 0)
    {
        div_pos = CCG5_P1_OV_DIV_SEL_BIT_POS;
    }
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */

    /* Clear AUTO MODE OVP detect to avoid false auto off during reference change */
    if (gl_vbus_ovp_mode[port] == VBUS_OVP_MODE_UVOV_AUTOCTRL)
    {
        pd_fet_automode_disable (port, pctrl, filter_id);
    }

    /* Store OVP parameters. */
    gl_vbus_ovp_mode[port]      = mode;
    gl_ovp_cb[port]             = cb;
    gl_vbus_ovp_pgdo_type[port] = pctrl;
    gl_vbus_ovp_filter_id[port] = filter_id;

    /* Calculate required VBUS for OVP. */
    threshold = apply_threshold(volt, per);

    /* Cap the maximum voltage to be measured. */
    if (threshold > VBUS_VOLT_MAX)
        threshold = VBUS_VOLT_MAX;
    /* Make sure threshold is above the minimum trip point to avoid false triggers. */
    if (threshold < VBUS_OVP_DETECT_MIN)
        threshold = VBUS_OVP_DETECT_MIN;

    regval = pd->amux_nhv_ctrl;

    /*
     * Internal divider to be used depends on VBUS to be measured. For VBUS <
     * VBUS_DIV_20_PER_MAX_VOLT, use 20% divider(CCG3PA) and for greater,
     * use 8% divider. For CCG5, always use 8% divider.
     */

    {
#if CCG_PD_DUALPORT_ENABLE
        if (port == 1)
        {
            /* Get 8% of threshold. */
            vref = (threshold * 10) / 125;
        }
        else
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */
        {
            /* Get 8% of threshold. */
            vref = (threshold * 10) / 125;
        }

        /* Connect output to 8% */
        regval &= ~(1 << div_pos);
    }

    pd->amux_nhv_ctrl = regval;

    /* Calculate the actual reference voltage. Cap the value to the max. supported. */
    vref = ((vref - OVP_REF_VOLT_MIN) / OVP_REF_VOLT_STEP);
    if (vref > VREF_MAX_SETTING)
        vref = VREF_MAX_SETTING;

    /* Program reference voltage for OV comparator. */
#if CCG_PD_DUALPORT_ENABLE
    if (port == 1)
    {
        vref += ((OVP_REF_VOLT_MIN - OVP_REF8_VOLT_MIN) / OVP_REF_VOLT_STEP);
        if (vref > VREF_MAX_SETTING)
            vref = VREF_MAX_SETTING;

        /* OV comparator for Port 1 uses VREF[8]. */
        regval = gl_pdss[0]->refgen_3_ctrl;
        regval = (regval & ~PDSS_REFGEN_3_CTRL_SEL8_MASK) | (vref << PDSS_REFGEN_3_CTRL_SEL8_POS);
        gl_pdss[0]->refgen_3_ctrl = regval;
    }
    else
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */
    {
        /* OV comparator for Port 0 uses VREF[3]. */
        regval = pd->refgen_1_ctrl;
        regval &= ~(PDSS_REFGEN_1_CTRL_SEL3_MASK);
        regval |= (vref << PDSS_REFGEN_1_CTRL_SEL3_POS);
        pd->refgen_1_ctrl = regval;
    }

    /* Turn on comparator. */
    pd->comp_ctrl[comp_id] |= PDSS_COMP_CTRL_COMP_ISO_N;
    pd->comp_ctrl[comp_id] &= ~PDSS_COMP_CTRL_COMP_PD;

    CyDelayUs(10);

    /* Filter configuration. */
    pd->intr5_filter_cfg[filter_id] &= ~PDSS_INTR5_FILTER_CFG_FILT_EN;
    regval = pd->intr5_filter_cfg[filter_id] & ~(PDSS_INTR5_FILTER_CFG_FILT_CFG_MASK
            | PDSS_INTR5_FILTER_CFG_FILT_SEL_MASK | PDSS_INTR5_FILTER_CFG_DPSLP_MODE |
            PDSS_INTR5_FILTER_CFG_FILT_BYPASS | PDSS_INTR5_FILTER_CFG_FILT_RESET);

    /* Set filter clock cycles if filter is required. */
    if (filter_sel)
    {
        /* Subtracting 1 from filter clock cycle value as 0 translates to 1-2 clock cycles. */
        regval |= (((filter_sel - 1) & 0x1F) << PDSS_INTR5_FILTER_CFG_FILT_SEL_POS);

        /* Set edge detection. */
        regval |= (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR5_FILTER_CFG_FILT_CFG_POS);
        regval |= PDSS_INTR5_FILTER_CFG_FILT_EN | PDSS_INTR5_FILTER_CFG_DPSLP_MODE;
    }
    else
    {
        regval |= PDSS_INTR5_FILTER_CFG_FILT_BYPASS;
    }

    pd->intr5_filter_cfg[filter_id] = regval;

    /* Clear interrupt. */
    pd->intr5 = (1 << filter_id);

    /* Enable Interrupt. */
    pd->intr5_mask |= (1 << filter_id);

    /* Handle Auto mode. */
    /* For PB application, P_CTRL and C_CTRL are flipped. Take care of this. */
    if (gl_vbus_ovp_mode[port] == VBUS_OVP_MODE_UVOV_AUTOCTRL)
    {
        pd_fet_automode_enable (port, pctrl, filter_id);
    }
}

void pd_internal_vbus_ovp_dis(uint8_t port, bool pctrl)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;
    uint16_t vref;
    uint32_t comp_id      = COMP_ID_OV;
    filter_id_t filter_id = FILTER_ID_OV;
    uint32_t div_pos      = AMUX_OV_DIV_SEL_BIT_POS;

#if CCG_PD_DUALPORT_ENABLE
    if (port == 1)
    {
        div_pos   = CCG5_P1_OV_DIV_SEL_BIT_POS;
    }
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */

    state = CyEnterCriticalSection();

    /* Clear AUTO MODE OVP detect. */
    if (gl_vbus_ovp_mode[port] == VBUS_OVP_MODE_UVOV_AUTOCTRL)
    {
        pd_fet_automode_disable (port, pctrl, filter_id);
    }

    /* Disable comparator. */
    pd->comp_ctrl[comp_id] &= ~PDSS_COMP_CTRL_COMP_ISO_N;
    pd->comp_ctrl[comp_id] |= PDSS_COMP_CTRL_COMP_PD;

     /* Disable filter. */
    pd->intr5_filter_cfg[filter_id] &= ~(PDSS_INTR5_FILTER_CFG_FILT_EN |
        PDSS_INTR5_FILTER_CFG_FILT_CFG_MASK | PDSS_INTR5_FILTER_CFG_FILT_SEL_MASK |
        PDSS_INTR5_FILTER_CFG_FILT_BYPASS | PDSS_INTR5_FILTER_CFG_DPSLP_MODE);

    /* Disable and clear OV interrupts. */
    pd->intr5_mask &= ~(1 << filter_id);
    pd->intr5 = 1 << filter_id;

    /* Connect OV comparator input to 20% / 10% of VBus. */
    pd->amux_nhv_ctrl |= (1 << div_pos);

    /* Restore reference voltage for OV comparator to 6V equivalent. */
    vref = VBUS_OVP_DETECT_MIN / VBUS_C_10_PER_DIV;
    vref = (vref - OVP_REF_VOLT_MIN) / OVP_REF_VOLT_STEP;

#if CCG_PD_DUALPORT_ENABLE
    if (port == 1)
    {
        /* OV comparator on port 1 uses VREF[8]. */
        gl_pdss[0]->refgen_3_ctrl = (gl_pdss[0]->refgen_3_ctrl & ~PDSS_REFGEN_3_CTRL_SEL8_MASK) |
            (vref << PDSS_REFGEN_3_CTRL_SEL8_POS);
    }
    else
#endif /* ((defined(CCG5)) && (CCG_PD_DUALPORT_ENABLE)) */
    {
        /* OV comparator on port 0 uses VREF[3]. */
        pd->refgen_1_ctrl = (pd->refgen_1_ctrl & ~PDSS_REFGEN_1_CTRL_SEL3_MASK) | (vref << PDSS_REFGEN_1_CTRL_SEL3_POS);
    }

    /* Clear callback. */
    gl_ovp_cb[port] = NULL;

    CyExitCriticalSection(state);
}

#endif /* VBUS_OVP_ENABLE */

#if VBUS_UVP_ENABLE

/* UVP min reference voltage in mV. */
#define UVP_REF_VOLT_MIN            (200)

/* UVP min reference voltage on Port #1 of CCG5. */
#define UVP_REF_VOLT_MIN_P1         (130)

/* UVP Reference voltage step size in mV. */
#define UVP_REF_VOLT_STEP           (10)

/*
 * Minimum supported voltage for UVP. Any voltage lower may cause system to
 * not work as expected; the block references can get affected. This is now
 * limited to 3.15V.
 */
#define UVP_MIN_VOLT                (3100)

void pd_internal_vbus_uvp_en(uint8_t port, uint16_t volt, int8_t per, PD_ADC_CB_T cb, bool pctrl,
        vbus_uvp_mode_t mode, uint8_t filter_sel)
{
    uint16_t threshold, vref;
    uint32_t regval;
    PPDSS_REGS_T pd = gl_pdss[port];

    if (gl_vbus_uvp_mode == VBUS_UVP_MODE_INT_COMP_AUTOCTRL)
    {
        pd_fet_automode_disable (port, pctrl, FILTER_ID_UV);
    }

    /* Store UVP mode. */
    gl_vbus_uvp_mode = mode;
    /* Set up UVP callback. */
    gl_uvp_cb = cb;
    /* Store PGDO type. */
    gl_vbus_uvp_pgdo_type = pctrl;

    /* Calculate required VBUS for UVP. */
    threshold = ((volt * per) / 100);

    /* Ensure that we are within the limits. */
    if (threshold < UVP_MIN_VOLT)
    {
        threshold = UVP_MIN_VOLT;
    }

    regval = pd->amux_nhv_ctrl;


    /* Use 10% of VBus as input to UVP comparator. */
    regval &= 0xFFFFFFFD;

    vref = threshold / VBUS_C_10_PER_DIV;

    pd->amux_nhv_ctrl = regval;

#if CCG_PD_DUALPORT_ENABLE
    if (port != 0)
    {
        /* UV comparator on Port #1 uses VREF_OUT[7]. */
        vref = ((vref - UVP_REF_VOLT_MIN_P1) / UVP_REF_VOLT_STEP);
        regval = pd->refgen_2_ctrl;
        regval &= ~(PDSS_REFGEN_2_CTRL_SEL7_MASK);
        regval |= (vref << PDSS_REFGEN_2_CTRL_SEL7_POS);
        pd->refgen_2_ctrl = regval;
    }
    else
#endif /* CCG_PD_DUALPORT_ENABLE */
    {
        /* Program reference voltage for UV comparator. */
        vref = ((vref - UVP_REF_VOLT_MIN) / UVP_REF_VOLT_STEP);
        regval = pd->refgen_1_ctrl;
        regval &= ~(PDSS_REFGEN_1_CTRL_SEL2_MASK);
        regval |= (vref << PDSS_REFGEN_1_CTRL_SEL2_POS);
        pd->refgen_1_ctrl = regval;
    }

    /* Turn on comparator. */
    pd->comp_ctrl[COMP_ID_UV] |= PDSS_COMP_CTRL_COMP_ISO_N;
    pd->comp_ctrl[COMP_ID_UV] &= ~PDSS_COMP_CTRL_COMP_PD;

    CyDelayUs(10);

    /* Filter configuration. */
    pd->intr5_filter_cfg[FILTER_ID_UV] &= ~PDSS_INTR5_FILTER_CFG_FILT_EN;
    /* Reset filter to 1. */
    regval = pd->intr5_filter_cfg[FILTER_ID_UV] & ~(PDSS_INTR5_FILTER_CFG_FILT_CFG_MASK
            | PDSS_INTR5_FILTER_CFG_FILT_SEL_MASK | PDSS_INTR5_FILTER_CFG_DPSLP_MODE |
            PDSS_INTR5_FILTER_CFG_FILT_BYPASS);
    regval |= PDSS_INTR5_FILTER_CFG_FILT_RESET;

    /* Set filter clock cycles if filter is required. */
    if (filter_sel)
    {
        /* Subtracting 1 from filter clock cycle value as 0 translates to 1-2 clock cycles. */
        regval |= (((filter_sel - 1) & 0x1F) << PDSS_INTR5_FILTER_CFG_FILT_SEL_POS);
        /* Set edge detection. */
        regval |= (FILTER_CFG_POS_DIS_NEG_EN << PDSS_INTR5_FILTER_CFG_FILT_CFG_POS);
        regval |= PDSS_INTR5_FILTER_CFG_FILT_EN | PDSS_INTR5_FILTER_CFG_DPSLP_MODE;
    }
    else
    {
        regval |= PDSS_INTR5_FILTER_CFG_FILT_BYPASS;
    }

    pd->intr5_filter_cfg[FILTER_ID_UV] =  regval;

    /* Clear interrupt. */
    pd->intr5 = (1 << FILTER_ID_UV);

    /* Enable Interrupt. */
    pd->intr5_mask |= (1 << FILTER_ID_UV);

    /* Handle Auto mode. */
    if (gl_vbus_uvp_mode == VBUS_UVP_MODE_INT_COMP_AUTOCTRL)
    {
        pd_fet_automode_enable (port, pctrl, FILTER_ID_UV);
    }
}

void pd_internal_vbus_uvp_dis(uint8_t port, bool pctrl)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;

    state = CyEnterCriticalSection ();

    /* Clear AUTO MODE OVP detect. */
    if (gl_vbus_uvp_mode == VBUS_UVP_MODE_INT_COMP_AUTOCTRL)
    {
        pd_fet_automode_disable (port, pctrl, FILTER_ID_UV);
    }

    /* Disable comparator. */
    pd->comp_ctrl[COMP_ID_UV] &= ~PDSS_COMP_CTRL_COMP_ISO_N;
    pd->comp_ctrl[COMP_ID_UV] |= PDSS_COMP_CTRL_COMP_PD;

    /* Disable filter. */
    pd->intr5_filter_cfg[FILTER_ID_UV] &= ~(PDSS_INTR5_FILTER_CFG_FILT_EN |
        PDSS_INTR5_FILTER_CFG_FILT_CFG_MASK | PDSS_INTR5_FILTER_CFG_FILT_SEL_MASK |
        PDSS_INTR5_FILTER_CFG_FILT_BYPASS);

    /* Disable and clear UV interrupts. */
    pd->intr5_mask &= ~(1 << FILTER_ID_UV);
    pd->intr5 = 1 << FILTER_ID_UV;

    /* Clear callback. */
    gl_uvp_cb = NULL;

    CyExitCriticalSection (state);
}

#endif /* VBUS_UVP_ENABLE */

void pd_cf_enable(uint8_t port, uint32_t cur, vbus_cf_cbk_t cbk)
{
    (void)port;
    (void)cur;
    (void)cbk;
}

void pd_cf_disable(uint8_t port)
{
    (void)port;
}

bool pd_cf_get_status(uint8_t port)
{
    {
        (void)port;
        return false;
    }
}

#if VCONN_OCP_ENABLE
void pd_hal_vconn_ocp_enable(uint8_t port, uint8_t debounce, PD_ADC_CB_T cb)
{
    PPDSS_REGS_T pd = gl_pdss[port];
    uint8_t state;
    uint32_t regval, ccint;

    state = CyEnterCriticalSection();

    /* Store the parameters. */
    gl_vconn_ocp_debounce[port] = debounce;
    gl_vconn_ocp_cb[port]       = cb;

    /* Configure the filter on the appropriate CC line. */
    pd->intr1_cfg_cc12_ocp_hs = 0;
    regval = 0;

    if (dpm_get_status(port)->polarity == CC_CHANNEL_1)
    {
        /* Enable filter with positive edge detection with 4 HF clock cycle period. */
        regval = (
                (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_FILT_CFG_POS) |
                (4 << PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_FILT_SEL_POS) |
                PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_DPSLP_MODE |
                PDSS_INTR1_CFG_CC12_OCP_HS_CC2_OCP_FILT_EN
                );
        gl_vconn_channel[port] = CC_CHANNEL_2;
        ccint = PDSS_INTR1_CC2_OCP_CHANGED;

        /* Enable OC detection on CC2 pin. */
        pd->vconn20_ctrl |= PDSS_VCONN20_CTRL_EN_OCP_CC2;
    }
    else
    {
        regval = (
                (FILTER_CFG_POS_EN_NEG_DIS << PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_FILT_CFG_POS) |
                (4 << PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_FILT_SEL_POS) |
                PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_DPSLP_MODE |
                PDSS_INTR1_CFG_CC12_OCP_HS_CC1_OCP_FILT_EN
                );
        gl_vconn_channel[port] = CC_CHANNEL_1;
        ccint = PDSS_INTR1_CC1_OCP_CHANGED;

        /* Enable OC detection on CC1 pin. */
        pd->vconn20_ctrl |= PDSS_VCONN20_CTRL_EN_OCP_CC1;
    }

    /* Set the VConn OCP configuration. */
    pd->intr1_cfg_cc12_ocp_hs = regval;

    /* Make sure VConn OCP debounce timer is not running. */
    timer_stop (port, PD_VCONN_OCP_DEBOUNCE_TIMER);

    /* Clear and enable the interrupt associated with OC detection on CC lines. */
    pd->intr1 = (PDSS_INTR1_CC1_OCP_CHANGED | PDSS_INTR1_CC2_OCP_CHANGED);

    /* Enable the interrupt. */
    pd->intr1_mask |= ccint;

    CyExitCriticalSection (state);

    /* Avoid compiler warnings about unused arguments. */
    (void)port;
    (void)debounce;
    (void)cb;
}

void pd_hal_vconn_ocp_disable(uint8_t port)
{
    PPDSS_REGS_T pd = gl_pdss[port];

    /* Disable OC detection on CC pins. */
    pd->vconn20_ctrl &= ~(PDSS_VCONN20_CTRL_EN_OCP_CC1 | PDSS_VCONN20_CTRL_EN_OCP_CC2);

    /* Disable the filter block associated with CC12 OC detection. */
    pd->intr1_cfg_cc12_ocp_hs = 0;

    /* Disable and clear the CC12 OC changed interrupt. */
    pd->intr1_mask &= ~(PDSS_INTR1_CC1_OCP_CHANGED | PDSS_INTR1_CC2_OCP_CHANGED);
    pd->intr1       = (PDSS_INTR1_CC1_OCP_CHANGED | PDSS_INTR1_CC2_OCP_CHANGED);

    /* Stop the CC12 OC debounce timer if it is running. */
    timer_stop (port, PD_VCONN_OCP_DEBOUNCE_TIMER);

    /* Clear the stored configuration. */
    gl_vconn_ocp_debounce[port] = 0;
    gl_vconn_ocp_cb[port]       = NULL;
    gl_vconn_channel[port]      = CC_CHANNEL_1;

    /* Avoid compiler warnings about unused arguments. */
    (void)port;
}
#endif /* VCONN_OCP_ENABLE */


/* End of file */
